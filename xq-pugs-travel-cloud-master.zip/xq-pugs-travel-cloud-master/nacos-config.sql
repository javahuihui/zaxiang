/*
 Navicat MySQL Data Transfer

 Source Server         : 本地数据库
 Source Server Type    : MySQL
 Source Server Version : 50734
 Source Host           : localhost:3306
 Source Schema         : nacos-config

 Target Server Type    : MySQL
 Target Server Version : 50734
 File Encoding         : 65001

 Date: 30/03/2022 15:43:41
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for config_info
-- ----------------------------
DROP TABLE IF EXISTS `config_info`;
CREATE TABLE `config_info`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `data_id` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL COMMENT 'data_id',
  `group_id` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `content` longtext CHARACTER SET utf8 COLLATE utf8_bin NOT NULL COMMENT 'content',
  `md5` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT 'md5',
  `gmt_create` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0) COMMENT '创建时间',
  `gmt_modified` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0) COMMENT '修改时间',
  `src_user` text CHARACTER SET utf8 COLLATE utf8_bin NULL COMMENT 'source user',
  `src_ip` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT 'source ip',
  `app_name` varchar(128) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `tenant_id` varchar(128) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT '' COMMENT '租户字段',
  `c_desc` varchar(256) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `c_use` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `effect` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `type` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `c_schema` text CHARACTER SET utf8 COLLATE utf8_bin NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `uk_configinfo_datagrouptenant`(`data_id`, `group_id`, `tenant_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 19 CHARACTER SET = utf8 COLLATE = utf8_bin COMMENT = 'config_info' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of config_info
-- ----------------------------
INSERT INTO `config_info` VALUES (4, 'pug-travel-gateway-routers', 'pug-travel-group', '[\n    {\n        \"id\":\"xq-pugs-travel-user-service\",\n        \"order\":0,\n        \"predicates\":[\n            {\n                \"args\":{\n                    \"pattern\":\"/getuser\"\n                },\n                \"name\":\"Path\"\n            }\n        ],\n        \"uri\":\"lb://xq-pugs-travel-user-service\",\n        \"filters\":[\n            {\n                \"name\":\"StripPrefix\",\n                \"args\":{\n                    \"parts\":1\n                }\n            }\n        ]\n    }\n]', '2acb7b844196d17e22940ff8b701c8ae', '2022-03-30 06:36:32', '2022-03-30 07:34:05', 'nacos', '0:0:0:0:0:0:0:1', '', '96677aa2-b5c1-49b7-9074-754580f70893', '', '', '', 'json', '');

-- ----------------------------
-- Table structure for config_info_aggr
-- ----------------------------
DROP TABLE IF EXISTS `config_info_aggr`;
CREATE TABLE `config_info_aggr`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `data_id` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL COMMENT 'data_id',
  `group_id` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL COMMENT 'group_id',
  `datum_id` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL COMMENT 'datum_id',
  `content` longtext CHARACTER SET utf8 COLLATE utf8_bin NOT NULL COMMENT '内容',
  `gmt_modified` datetime(0) NOT NULL COMMENT '修改时间',
  `app_name` varchar(128) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `tenant_id` varchar(128) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT '' COMMENT '租户字段',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `uk_configinfoaggr_datagrouptenantdatum`(`data_id`, `group_id`, `tenant_id`, `datum_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_bin COMMENT = '增加租户字段' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of config_info_aggr
-- ----------------------------

-- ----------------------------
-- Table structure for config_info_beta
-- ----------------------------
DROP TABLE IF EXISTS `config_info_beta`;
CREATE TABLE `config_info_beta`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `data_id` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL COMMENT 'data_id',
  `group_id` varchar(128) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL COMMENT 'group_id',
  `app_name` varchar(128) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT 'app_name',
  `content` longtext CHARACTER SET utf8 COLLATE utf8_bin NOT NULL COMMENT 'content',
  `beta_ips` varchar(1024) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT 'betaIps',
  `md5` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT 'md5',
  `gmt_create` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0) COMMENT '创建时间',
  `gmt_modified` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0) COMMENT '修改时间',
  `src_user` text CHARACTER SET utf8 COLLATE utf8_bin NULL COMMENT 'source user',
  `src_ip` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT 'source ip',
  `tenant_id` varchar(128) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT '' COMMENT '租户字段',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `uk_configinfobeta_datagrouptenant`(`data_id`, `group_id`, `tenant_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_bin COMMENT = 'config_info_beta' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of config_info_beta
-- ----------------------------

-- ----------------------------
-- Table structure for config_info_tag
-- ----------------------------
DROP TABLE IF EXISTS `config_info_tag`;
CREATE TABLE `config_info_tag`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `data_id` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL COMMENT 'data_id',
  `group_id` varchar(128) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL COMMENT 'group_id',
  `tenant_id` varchar(128) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT '' COMMENT 'tenant_id',
  `tag_id` varchar(128) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL COMMENT 'tag_id',
  `app_name` varchar(128) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT 'app_name',
  `content` longtext CHARACTER SET utf8 COLLATE utf8_bin NOT NULL COMMENT 'content',
  `md5` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT 'md5',
  `gmt_create` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0) COMMENT '创建时间',
  `gmt_modified` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0) COMMENT '修改时间',
  `src_user` text CHARACTER SET utf8 COLLATE utf8_bin NULL COMMENT 'source user',
  `src_ip` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT 'source ip',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `uk_configinfotag_datagrouptenanttag`(`data_id`, `group_id`, `tenant_id`, `tag_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_bin COMMENT = 'config_info_tag' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of config_info_tag
-- ----------------------------

-- ----------------------------
-- Table structure for config_tags_relation
-- ----------------------------
DROP TABLE IF EXISTS `config_tags_relation`;
CREATE TABLE `config_tags_relation`  (
  `id` bigint(20) NOT NULL COMMENT 'id',
  `tag_name` varchar(128) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL COMMENT 'tag_name',
  `tag_type` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT 'tag_type',
  `data_id` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL COMMENT 'data_id',
  `group_id` varchar(128) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL COMMENT 'group_id',
  `tenant_id` varchar(128) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT '' COMMENT 'tenant_id',
  `nid` bigint(20) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`nid`) USING BTREE,
  UNIQUE INDEX `uk_configtagrelation_configidtag`(`id`, `tag_name`, `tag_type`) USING BTREE,
  INDEX `idx_tenant_id`(`tenant_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_bin COMMENT = 'config_tag_relation' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of config_tags_relation
-- ----------------------------

-- ----------------------------
-- Table structure for group_capacity
-- ----------------------------
DROP TABLE IF EXISTS `group_capacity`;
CREATE TABLE `group_capacity`  (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `group_id` varchar(128) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '' COMMENT 'Group ID，空字符表示整个集群',
  `quota` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT '配额，0表示使用默认值',
  `usage` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT '使用量',
  `max_size` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT '单个配置大小上限，单位为字节，0表示使用默认值',
  `max_aggr_count` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT '聚合子配置最大个数，，0表示使用默认值',
  `max_aggr_size` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT '单个聚合数据的子配置大小上限，单位为字节，0表示使用默认值',
  `max_history_count` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT '最大变更历史数量',
  `gmt_create` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0) COMMENT '创建时间',
  `gmt_modified` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0) COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `uk_group_id`(`group_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_bin COMMENT = '集群、各Group容量信息表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of group_capacity
-- ----------------------------

-- ----------------------------
-- Table structure for his_config_info
-- ----------------------------
DROP TABLE IF EXISTS `his_config_info`;
CREATE TABLE `his_config_info`  (
  `id` bigint(64) UNSIGNED NOT NULL,
  `nid` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `data_id` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `group_id` varchar(128) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `app_name` varchar(128) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT 'app_name',
  `content` longtext CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `md5` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `gmt_create` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0),
  `gmt_modified` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0),
  `src_user` text CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `src_ip` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `op_type` char(10) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `tenant_id` varchar(128) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT '' COMMENT '租户字段',
  PRIMARY KEY (`nid`) USING BTREE,
  INDEX `idx_gmt_create`(`gmt_create`) USING BTREE,
  INDEX `idx_gmt_modified`(`gmt_modified`) USING BTREE,
  INDEX `idx_did`(`data_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 22 CHARACTER SET = utf8 COLLATE = utf8_bin COMMENT = '多租户改造' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of his_config_info
-- ----------------------------
INSERT INTO `his_config_info` VALUES (0, 1, 'pug-travels-gateway-router', 'pug-travels-group', '', '[{\r\n    \r\n}]', '57a8e9b6c5431cea13bc2a0c8d9b5e39', '2022-03-30 12:00:46', '2022-03-30 04:00:47', NULL, '0:0:0:0:0:0:0:1', 'I', '');
INSERT INTO `his_config_info` VALUES (0, 2, 'pug-travel-gateway-routers', 'pug-travel_group', '', '[\r\n    {\r\n        \"id\":\"user-service\",\r\n        \"order\":0,\r\n        \"predicates\":[\r\n            {\r\n                \"args\":{\r\n                    \"pattern\":\"/getuser\"\r\n                },\r\n                \"name\":\"Path\"\r\n            }\r\n        ],\r\n        \"uri\":\"lb://xq-pugs-travel-user-service\",\r\n        \"filters\":[\r\n            {\r\n                \"name\":\"HeaderToken\"\r\n            },\r\n            {\r\n                \"name\":\"StripPrefix\",\r\n                \"args\":{\r\n                    \"parts\":\"1\"\r\n                }\r\n            }\r\n        ]\r\n    }\r\n]', 'bdaeee1aec7ef909e10a580d1a42d2bd', '2022-03-30 12:09:09', '2022-03-30 04:09:10', NULL, '0:0:0:0:0:0:0:1', 'I', '');
INSERT INTO `his_config_info` VALUES (0, 3, 'pug-travel-gateway-routers', 'pug-travel-group', '', '[\r\n    {\r\n        \"id\":\"user-service\",\r\n        \"order\":0,\r\n        \"predicates\":[\r\n            {\r\n                \"args\":{\r\n                    \"pattern\":\"/getuser\"\r\n                },\r\n                \"name\":\"Path\"\r\n            }\r\n        ],\r\n        \"uri\":\"lb://xq-pugs-travel-user-service\",\r\n        \"filters\":[\r\n            {\r\n                \"name\":\"HeaderToken\"\r\n            },\r\n            {\r\n                \"name\":\"StripPrefix\",\r\n                \"args\":{\r\n                    \"parts\":\"1\"\r\n                }\r\n            }\r\n        ]\r\n    }\r\n]', 'bdaeee1aec7ef909e10a580d1a42d2bd', '2022-03-30 12:11:51', '2022-03-30 04:11:51', NULL, '0:0:0:0:0:0:0:1', 'I', '');
INSERT INTO `his_config_info` VALUES (1, 4, 'pug-travels-gateway-router', 'pug-travels-group', '', '[{\r\n    \r\n}]', '57a8e9b6c5431cea13bc2a0c8d9b5e39', '2022-03-30 12:12:13', '2022-03-30 04:12:14', NULL, '0:0:0:0:0:0:0:1', 'D', '');
INSERT INTO `his_config_info` VALUES (2, 5, 'pug-travel-gateway-routers', 'pug-travel_group', '', '[\r\n    {\r\n        \"id\":\"user-service\",\r\n        \"order\":0,\r\n        \"predicates\":[\r\n            {\r\n                \"args\":{\r\n                    \"pattern\":\"/getuser\"\r\n                },\r\n                \"name\":\"Path\"\r\n            }\r\n        ],\r\n        \"uri\":\"lb://xq-pugs-travel-user-service\",\r\n        \"filters\":[\r\n            {\r\n                \"name\":\"HeaderToken\"\r\n            },\r\n            {\r\n                \"name\":\"StripPrefix\",\r\n                \"args\":{\r\n                    \"parts\":\"1\"\r\n                }\r\n            }\r\n        ]\r\n    }\r\n]', 'bdaeee1aec7ef909e10a580d1a42d2bd', '2022-03-30 12:12:28', '2022-03-30 04:12:28', NULL, '0:0:0:0:0:0:0:1', 'D', '');
INSERT INTO `his_config_info` VALUES (0, 6, 'pug-travel-gateway-routers', 'pug-travel-group', '', '[\r\n    {\r\n        \"id\":\"user-service\",\r\n        \"order\":0,\r\n        \"predicates\":[\r\n            {\r\n                \"args\":{\r\n                    \"pattern\":\"/getuser\"\r\n                },\r\n                \"name\":\"Path\"\r\n            }\r\n        ],\r\n        \"uri\":\"lb://xq-pugs-travel-user-service\",\r\n        \"filters\":[\r\n            {\r\n                \"name\":\"HeaderToken\"\r\n            },\r\n            {\r\n                \"name\":\"StripPrefix\",\r\n                \"args\":{\r\n                    \"parts\":\"1\"\r\n                }\r\n            }\r\n        ]\r\n    }\r\n]', 'bdaeee1aec7ef909e10a580d1a42d2bd', '2022-03-30 14:36:31', '2022-03-30 06:36:32', NULL, '0:0:0:0:0:0:0:1', 'I', '96677aa2-b5c1-49b7-9074-754580f70893');
INSERT INTO `his_config_info` VALUES (3, 7, 'pug-travel-gateway-routers', 'pug-travel-group', '', '[\r\n    {\r\n        \"id\":\"user-service\",\r\n        \"order\":0,\r\n        \"predicates\":[\r\n            {\r\n                \"args\":{\r\n                    \"pattern\":\"/getuser\"\r\n                },\r\n                \"name\":\"Path\"\r\n            }\r\n        ],\r\n        \"uri\":\"lb://xq-pugs-travel-user-service\",\r\n        \"filters\":[\r\n            {\r\n                \"name\":\"HeaderToken\"\r\n            },\r\n            {\r\n                \"name\":\"StripPrefix\",\r\n                \"args\":{\r\n                    \"parts\":\"1\"\r\n                }\r\n            }\r\n        ]\r\n    }\r\n]', 'bdaeee1aec7ef909e10a580d1a42d2bd', '2022-03-30 14:36:40', '2022-03-30 06:36:40', NULL, '0:0:0:0:0:0:0:1', 'D', '');
INSERT INTO `his_config_info` VALUES (4, 8, 'pug-travel-gateway-routers', 'pug-travel-group', '', '[\r\n    {\r\n        \"id\":\"user-service\",\r\n        \"order\":0,\r\n        \"predicates\":[\r\n            {\r\n                \"args\":{\r\n                    \"pattern\":\"/getuser\"\r\n                },\r\n                \"name\":\"Path\"\r\n            }\r\n        ],\r\n        \"uri\":\"lb://xq-pugs-travel-user-service\",\r\n        \"filters\":[\r\n            {\r\n                \"name\":\"HeaderToken\"\r\n            },\r\n            {\r\n                \"name\":\"StripPrefix\",\r\n                \"args\":{\r\n                    \"parts\":\"1\"\r\n                }\r\n            }\r\n        ]\r\n    }\r\n]', 'bdaeee1aec7ef909e10a580d1a42d2bd', '2022-03-30 14:40:44', '2022-03-30 06:40:44', 'nacos', '0:0:0:0:0:0:0:1', 'U', '96677aa2-b5c1-49b7-9074-754580f70893');
INSERT INTO `his_config_info` VALUES (4, 9, 'pug-travel-gateway-routers', 'pug-travel-group', '', '[\n    {\n        \"id\":\"user-service\",\n        \"order\":0,\n        \"predicates\":[\n            {\n                \"args\":{\n                    \"pattern\":\"/getuser\"\n                },\n                \"name\":\"Path\"\n            }\n        ],\n        \"uri\":\"lb://xq-pugs-travel-user-service\",\n        \"filters\":[\n            {\n                \"name\":\"StripPrefix\",\n                \"args\":{\n                    \"parts\":\"1\"\n                }\n            }\n        ]\n    }\n]', '96f110dc5ca7211c26fb818f0432828f', '2022-03-30 14:43:29', '2022-03-30 06:43:29', 'nacos', '0:0:0:0:0:0:0:1', 'U', '96677aa2-b5c1-49b7-9074-754580f70893');
INSERT INTO `his_config_info` VALUES (4, 10, 'pug-travel-gateway-routers', 'pug-travel-group', '', '[\n    {\n        \"id\":\"pug-user-service\",\n        \"order\":0,\n        \"predicates\":[\n            {\n                \"args\":{\n                    \"pattern\":\"/getuser\"\n                },\n                \"name\":\"Path\"\n            }\n        ],\n        \"uri\":\"lb://xq-pugs-travel-user-service\",\n        \"filters\":[\n            {\n                \"name\":\"StripPrefix\",\n                \"args\":{\n                    \"parts\":\"1\"\n                }\n            }\n        ]\n    }\n]', 'bfcd72268d7e26a5db9202444eb431d5', '2022-03-30 14:44:16', '2022-03-30 06:44:16', 'nacos', '0:0:0:0:0:0:0:1', 'U', '96677aa2-b5c1-49b7-9074-754580f70893');
INSERT INTO `his_config_info` VALUES (4, 11, 'pug-travel-gateway-routers', 'pug-travel-group', '', '[\n    {\n        \"id\":\"cpug-user-service\",\n        \"order\":0,\n        \"predicates\":[\n            {\n                \"args\":{\n                    \"pattern\":\"/getuser\"\n                },\n                \"name\":\"Path\"\n            }\n        ],\n        \"uri\":\"lb://xq-pugs-travel-user-service\",\n        \"filters\":[\n            {\n                \"name\":\"StripPrefix\",\n                \"args\":{\n                    \"parts\":\"1\"\n                }\n            }\n        ]\n    }\n]', '6c6c57ce802760de7008cb757098c742', '2022-03-30 14:44:55', '2022-03-30 06:44:55', 'nacos', '0:0:0:0:0:0:0:1', 'U', '96677aa2-b5c1-49b7-9074-754580f70893');
INSERT INTO `his_config_info` VALUES (4, 12, 'pug-travel-gateway-routers', 'pug-travel-group', '', '[\n    {\n        \"id\":\"cpug-user-service\",\n        \"order\":0,\n        \"predicates\":[\n            {\n                \"args\":{\n                    \"pattern\":\"/getuser\"\n                },\n                \"name\":\"Path\"\n            }\n        ],\n        \"uri\":\"lb://xq-pugs-travel-user-service\",\n        \"filters\":[\n            {\n                \"name\":\"StripPrefix\",\n                \"args\":{\n                    \"parts\":\"1\"\n                }\n            }\n        ]\n    }\n]', '6c6c57ce802760de7008cb757098c742', '2022-03-30 14:45:08', '2022-03-30 06:45:08', 'nacos', '0:0:0:0:0:0:0:1', 'U', '96677aa2-b5c1-49b7-9074-754580f70893');
INSERT INTO `his_config_info` VALUES (4, 13, 'pug-travel-gateway-routers', 'pug-travel-group', '', '[\n    {\n        \"id\":\"pug-user-service\",\n        \"order\":0,\n        \"predicates\":[\n            {\n                \"args\":{\n                    \"pattern\":\"/getuser\"\n                },\n                \"name\":\"Path\"\n            }\n        ],\n        \"uri\":\"lb://xq-pugs-travel-user-service\",\n        \"filters\":[\n            {\n                \"name\":\"StripPrefix\",\n                \"args\":{\n                    \"parts\":\"1\"\n                }\n            }\n        ]\n    }\n]', 'bfcd72268d7e26a5db9202444eb431d5', '2022-03-30 14:47:17', '2022-03-30 06:47:18', 'nacos', '0:0:0:0:0:0:0:1', 'U', '96677aa2-b5c1-49b7-9074-754580f70893');
INSERT INTO `his_config_info` VALUES (4, 14, 'pug-travel-gateway-routers', 'pug-travel-group', '', '[\n    {\n        \"id\":\"xq-pugs-travel-user-service\",\n        \"order\":0,\n        \"predicates\":[\n            {\n                \"args\":{\n                    \"pattern\":\"/getuser\"\n                },\n                \"name\":\"Path\"\n            }\n        ],\n        \"uri\":\"lb://xq-pugs-travel-user-service\",\n        \"filters\":[\n            {\n                \"name\":\"StripPrefix\",\n                \"args\":{\n                    \"parts\":\"1\"\n                }\n            }\n        ]\n    }\n]', 'c88d6d27c3986acf41813893263ec97b', '2022-03-30 14:49:09', '2022-03-30 06:49:10', 'nacos', '0:0:0:0:0:0:0:1', 'U', '96677aa2-b5c1-49b7-9074-754580f70893');
INSERT INTO `his_config_info` VALUES (4, 15, 'pug-travel-gateway-routers', 'pug-travel-group', '', '[\n    {\n        \"id\":\"xq-pugs-travel-user-servicexxxx\",\n        \"order\":0,\n        \"predicates\":[\n            {\n                \"args\":{\n                    \"pattern\":\"/getuser\"\n                },\n                \"name\":\"Path\"\n            }\n        ],\n        \"uri\":\"lb://xq-pugs-travel-user-service\",\n        \"filters\":[\n            {\n                \"name\":\"StripPrefix\",\n                \"args\":{\n                    \"parts\":\"1\"\n                }\n            }\n        ]\n    }\n]', 'bed45e3f99fb8d558d8f38e8515ecd89', '2022-03-30 14:49:54', '2022-03-30 06:49:55', 'nacos', '0:0:0:0:0:0:0:1', 'U', '96677aa2-b5c1-49b7-9074-754580f70893');
INSERT INTO `his_config_info` VALUES (4, 16, 'pug-travel-gateway-routers', 'pug-travel-group', '', '[\n    {\n        \"id\":\"xq-pugs-travel-user-service\",\n        \"order\":0,\n        \"predicates\":[\n            {\n                \"args\":{\n                    \"pattern\":\"/getuser\"\n                },\n                \"name\":\"Path\"\n            }\n        ],\n        \"uri\":\"lb://xq-pugs-travel-user-service\",\n        \"filters\":[\n            {\n                \"name\":\"StripPrefix\",\n                \"args\":{\n                    \"parts\":\"1\"\n                }\n            }\n        ]\n    }\n]', 'c88d6d27c3986acf41813893263ec97b', '2022-03-30 14:51:30', '2022-03-30 06:51:31', 'nacos', '0:0:0:0:0:0:0:1', 'U', '96677aa2-b5c1-49b7-9074-754580f70893');
INSERT INTO `his_config_info` VALUES (4, 17, 'pug-travel-gateway-routers', 'pug-travel-group', '', '[\n    {\n        \"id\":\"xq-pugs-travel-user-service22222\",\n        \"order\":0,\n        \"predicates\":[\n            {\n                \"args\":{\n                    \"pattern\":\"/getuser\"\n                },\n                \"name\":\"Path\"\n            }\n        ],\n        \"uri\":\"lb://xq-pugs-travel-user-service\",\n        \"filters\":[\n            {\n                \"name\":\"StripPrefix\",\n                \"args\":{\n                    \"parts\":\"1\"\n                }\n            }\n        ]\n    }\n]', '221e97bb95a441fdc6c96b079c58269c', '2022-03-30 14:54:07', '2022-03-30 06:54:08', 'nacos', '0:0:0:0:0:0:0:1', 'U', '96677aa2-b5c1-49b7-9074-754580f70893');
INSERT INTO `his_config_info` VALUES (4, 18, 'pug-travel-gateway-routers', 'pug-travel-group', '', '[\n    {\n        \"id\":\"xq-pugs-travel-user-service\",\n        \"order\":0,\n        \"predicates\":[\n            {\n                \"args\":{\n                    \"pattern\":\"/getuser\"\n                },\n                \"name\":\"Path\"\n            }\n        ],\n        \"uri\":\"lb://xq-pugs-travel-user-service\",\n        \"filters\":[\n            {\n                \"name\":\"StripPrefix\",\n                \"args\":{\n                    \"parts\":\"1\"\n                }\n            }\n        ]\n    }\n]', 'c88d6d27c3986acf41813893263ec97b', '2022-03-30 15:24:01', '2022-03-30 07:24:01', 'nacos', '0:0:0:0:0:0:0:1', 'U', '96677aa2-b5c1-49b7-9074-754580f70893');
INSERT INTO `his_config_info` VALUES (4, 19, 'pug-travel-gateway-routers', 'pug-travel-group', '', '[\n    {\n        \"id\":\"xq-pugs-travel-user-service\",\n        \"order\":0,\n        \"predicates\":[\n            {\n                \"args\":{\n                    \"pattern\":\"/getuser\"\n                },\n                \"name\":\"Path\"\n            }\n        ],\n        \"uri\":\"lb://xq-pugs-travel-user-service\",\n        \"filters\":[\n            {\n                \"name\":\"PrefixPath\",\n                \"args\":{\n                    \"prefix\":\"/app\"\n                }\n            }\n        ]\n    }\n]', 'ef2c04d409b5ef199c02652004043065', '2022-03-30 15:25:07', '2022-03-30 07:25:07', 'nacos', '0:0:0:0:0:0:0:1', 'U', '96677aa2-b5c1-49b7-9074-754580f70893');
INSERT INTO `his_config_info` VALUES (4, 20, 'pug-travel-gateway-routers', 'pug-travel-group', '', '[\n    {\n        \"id\":\"xq-pugs-travel-user-service\",\n        \"order\":0,\n        \"predicates\":[\n            {\n                \"args\":{\n                    \"pattern\":\"/getuser\"\n                },\n                \"name\":\"Path\"\n            }\n        ],\n        \"uri\":\"lb://xq-pugs-travel-user-service\",\n        \"filters\":[\n            {\n                \"name\":\"PrefixPath\",\n                \"args\":{\n                    \"prefix\":\"/app\"\n                }\n            }\n        ]\n    }\n]', 'ef2c04d409b5ef199c02652004043065', '2022-03-30 15:29:02', '2022-03-30 07:29:03', 'nacos', '0:0:0:0:0:0:0:1', 'U', '96677aa2-b5c1-49b7-9074-754580f70893');
INSERT INTO `his_config_info` VALUES (4, 21, 'pug-travel-gateway-routers', 'pug-travel-group', '', '[\n    {\n        \"id\":\"xq-pugs-travel-user-service\",\n        \"order\":0,\n        \"predicates\":[\n            {\n                \"args\":{\n                    \"pattern\":\"/getuser\"\n                },\n                \"name\":\"Path\"\n            }\n        ],\n        \"uri\":\"lb://xq-pugs-travel-user-service\",\n        \"filters\":[\n            {\n                \"name\":\"StripPrefix\",\n                \"args\":{\n                    \"parts\":1\n                }\n            }\n        ]\n    }\n]', '2acb7b844196d17e22940ff8b701c8ae', '2022-03-30 15:34:04', '2022-03-30 07:34:05', 'nacos', '0:0:0:0:0:0:0:1', 'U', '96677aa2-b5c1-49b7-9074-754580f70893');

-- ----------------------------
-- Table structure for permissions
-- ----------------------------
DROP TABLE IF EXISTS `permissions`;
CREATE TABLE `permissions`  (
  `role` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `resource` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `action` varchar(8) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  UNIQUE INDEX `uk_role_permission`(`role`, `resource`, `action`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of permissions
-- ----------------------------

-- ----------------------------
-- Table structure for roles
-- ----------------------------
DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles`  (
  `username` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `role` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  UNIQUE INDEX `idx_user_role`(`username`, `role`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of roles
-- ----------------------------
INSERT INTO `roles` VALUES ('nacos', 'ROLE_ADMIN');

-- ----------------------------
-- Table structure for tenant_capacity
-- ----------------------------
DROP TABLE IF EXISTS `tenant_capacity`;
CREATE TABLE `tenant_capacity`  (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `tenant_id` varchar(128) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '' COMMENT 'Tenant ID',
  `quota` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT '配额，0表示使用默认值',
  `usage` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT '使用量',
  `max_size` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT '单个配置大小上限，单位为字节，0表示使用默认值',
  `max_aggr_count` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT '聚合子配置最大个数',
  `max_aggr_size` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT '单个聚合数据的子配置大小上限，单位为字节，0表示使用默认值',
  `max_history_count` int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT '最大变更历史数量',
  `gmt_create` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0) COMMENT '创建时间',
  `gmt_modified` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0) COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `uk_tenant_id`(`tenant_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_bin COMMENT = '租户容量信息表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of tenant_capacity
-- ----------------------------

-- ----------------------------
-- Table structure for tenant_info
-- ----------------------------
DROP TABLE IF EXISTS `tenant_info`;
CREATE TABLE `tenant_info`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `kp` varchar(128) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL COMMENT 'kp',
  `tenant_id` varchar(128) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT '' COMMENT 'tenant_id',
  `tenant_name` varchar(128) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT '' COMMENT 'tenant_name',
  `tenant_desc` varchar(256) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT 'tenant_desc',
  `create_source` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL COMMENT 'create_source',
  `gmt_create` bigint(20) NOT NULL COMMENT '创建时间',
  `gmt_modified` bigint(20) NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `uk_tenant_info_kptenantid`(`kp`, `tenant_id`) USING BTREE,
  INDEX `idx_tenant_id`(`tenant_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8 COLLATE = utf8_bin COMMENT = 'tenant_info' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of tenant_info
-- ----------------------------
INSERT INTO `tenant_info` VALUES (1, '1', '96677aa2-b5c1-49b7-9074-754580f70893', 'pug-travel-cloud-ns', 'pug-travel-cloud-ns', 'nacos', 1648520682616, 1648520682616);

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users`  (
  `username` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `password` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL,
  PRIMARY KEY (`username`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of users
-- ----------------------------
INSERT INTO `users` VALUES ('nacos', '$2a$10$EuWPZHzz32dJN7jexM34MOeYirDdFAZm2kuWj7VEOJhhZkDrxfvUu', 1);

SET FOREIGN_KEY_CHECKS = 1;
