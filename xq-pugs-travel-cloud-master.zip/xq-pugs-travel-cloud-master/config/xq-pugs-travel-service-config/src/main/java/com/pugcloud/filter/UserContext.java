package com.pugcloud.filter;


import com.pugcloud.vo.LoginUserInfo;

/**
 * @author 飞哥yykk
 * 更多学习关注飞哥B站
 * 地址是：https://space.bilibili.com/490711252
 * @title: UserThrealLocal
 * @projectName ksd-user-course-center
 * @description: TODO
 * @date 2021/9/2721:51
 */
public class UserContext {

    // 本地线程缓存: ThreadLocal 底层就是 Map
    private static ThreadLocal<LoginUserInfo> userThreadLocal = new ThreadLocal<LoginUserInfo>();

    public static void put(LoginUserInfo user) {
        userThreadLocal.set(user);
    }

    public static LoginUserInfo get() {
        return userThreadLocal.get();
    }

    public static void remove() {
        userThreadLocal.remove();
    }

}
