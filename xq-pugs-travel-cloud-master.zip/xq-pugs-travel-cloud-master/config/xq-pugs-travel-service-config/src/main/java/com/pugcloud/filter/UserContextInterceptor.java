package com.pugcloud.filter;


import com.pugcloud.anno.LoginCheck;
import com.pugcloud.constant.CommonConstant;
import com.pugcloud.result.ex.KsdBusinessException;
import com.pugcloud.util.PugTokenParser;
import com.pugcloud.vo.LoginUserInfo;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author 飞哥yykk
 * 更多学习关注飞哥B站
 * 地址是：https://space.bilibili.com/490711252
 * @title: UserThrealLocal 用户信息统一登录拦截
 * @projectName ksd-user-course-center
 * @description: TODO
 * @date 2021/9/2721:51
 */
@Slf4j
@Component
public class UserContextInterceptor implements HandlerInterceptor {
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        // 部分请求不需要带有身份信息, 即白名单
        if (checkWhiteListUrl(request.getRequestURI())) {
            return true;
        }

        if (handler instanceof HandlerMethod) {
            HandlerMethod handlerMethod = (HandlerMethod) handler;
            // 这里是一个测试童虎
            LoginUserInfo loginUserInfo = new LoginUserInfo();
            loginUserInfo.setId(10000000L);
            loginUserInfo.setUsername("yykktest");
            UserContext.put(loginUserInfo);
            // 让方法的优先级更高
            // 获取方法上面是否存在LoginCheck注解，如果存在并值是false.当然默认值也是false
            LoginCheck methodAnnotation = handlerMethod.getMethodAnnotation(LoginCheck.class);
            // methodAnnotation!=null 代表你加了注解,如果没加就不进入，就说明验证
            // !methodAnnotation.value() 加了如果是false，说明不需要验证了，就直接返回
            // 一句话：在开发中你要么不要加，要么加上去就使用默认值
            if (methodAnnotation!=null && !methodAnnotation.value()) {
                return true;
            }

            // 然后就是类的优先级
            Class<?> beanType = handlerMethod.getBeanType();
            LoginCheck annotation = beanType.getAnnotation(LoginCheck.class);
            if (annotation!=null && !annotation.value()) {
                return true;
            }
        }

        //1:先尝试从header中获取token
        String token = request.getHeader(CommonConstant.JWT_USER_INFO_KEY);
        LoginUserInfo loginUserInfo = null;
        try {
            // 2: 根据token解析用户信息
            loginUserInfo = PugTokenParser.parseUserInfoFromToken(token);
        } catch (Exception ex) {
            log.error("parse token fail,user info error : 【{}】", ex.getMessage(), ex);
        }

        // 这里其实理论上是不存在的，考虑到代码的完整性
        if (null == loginUserInfo) {
            throw new KsdBusinessException(602, "用户信息没有获取到，需重新登录");
        }

        log.info("user parse success uri is :【{}】", request.getRequestURI());
        // 3：同时编写本地缓存到副本中
        UserContext.put(loginUserInfo);

        return true;
    }

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {
        if (null != UserContext.get()) {
            UserContext.remove();
        }
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
        if (null != UserContext.get()) {
            UserContext.remove();
        }
    }

    /**
     * <h2>校验是否是白名单接口</h2>
     * swagger2 接口
     * */
    private boolean checkWhiteListUrl(String url) {
        return StringUtils.containsAny(
                url,
                "springfox", "swagger", "v2",
                "webjars", "doc.html"
        );
    }
}
