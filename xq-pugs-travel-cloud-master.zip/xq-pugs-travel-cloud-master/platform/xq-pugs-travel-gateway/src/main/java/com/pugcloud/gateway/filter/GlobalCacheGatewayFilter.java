package com.pugcloud.gateway.filter;

import com.pugcloud.gateway.constanst.GatewayConstants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.core.Ordered;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.core.io.buffer.DataBufferUtils;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpRequestDecorator;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/**
 * @author 飞哥
 * @Title: 学相伴出品
 * @Description: 飞哥B站地址：https://space.bilibili.com/490711252
 * 记得关注和三连哦！
 * @Description: 我们有一个学习网站：https://www.kuangstudy.com
 * @date 2022/3/30$ 15:35$
 */
@Slf4j
@Component
public class GlobalCacheGatewayFilter implements GlobalFilter, Ordered, GatewayConstants {

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {
        // 判断是不是登录和注册的URL地址
        boolean isLoginOrRegister = exchange.getRequest().getURI().getPath().contains(LOGIN_URI) ||
                exchange.getRequest().getURI().getPath().contains(REGISTER_URI);
        // 如果不是就继续往下执行
        if (null == exchange.getRequest().getHeaders().getContentType() || !isLoginOrRegister) {
            return chain.filter(exchange);
        }

        // DataBufferUtils.join 拿到请求中的数据 -- DataBuffer
        return DataBufferUtils.join(exchange.getRequest().getBody()).flatMap(dataBuffer -> {
            // 确保数据缓存区不被释放，必须要DataBufferUtils.retain
            DataBufferUtils.retain(dataBuffer);
            // defer,just都是去创建数据源，得到当前数据的副本
            Flux<DataBuffer> cacheFlux = Flux.defer(() -> Flux.just(dataBuffer.slice(0, dataBuffer.readableByteCount())));
            // 重新包装ServletHttpRequest,重写getBody方法，能够返回请求数据
            ServerHttpRequest serverHttpRequest = new ServerHttpRequestDecorator(exchange.getRequest()) {
                @Override
                public Flux<DataBuffer> getBody() {
                    return cacheFlux;
                }
            };
            //将包装后的ServletRequest向下继续传递
            return chain.filter(exchange.mutate().request(serverHttpRequest).build());
        });
    }

    @Override
    public int getOrder() {
        return HIGHEST_PRECEDENCE+1;
    }

}
