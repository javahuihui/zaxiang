package com.pugcloud.gateway.predicate;

import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;

/**
 * @author 飞哥
 * @Title: 学相伴出品
 * @Description: 飞哥B站地址：https://space.bilibili.com/490711252
 * 记得关注和三连哦！
 * @Description: 我们有一个学习网站：https://www.kuangstudy.com
 * @date 2022/3/30$ 11:12$
 */
public class PredicateTest {

    public static void main(String[] args) {
        List<String> testList = Arrays.asList("nacos", "gateway", "ribbon", "feign", "hystrix");
        System.out.println("==============默认规则===============");
        // 1: 默认规则
        Predicate<String> predicate = s -> s.length() > 5;
        testList.stream().filter(predicate).forEach(System.out::println);
        System.out.println("==============and规则===============");
        // 2: and规则
        Predicate<String> predicate1 = s -> s.length() > 5;
        Predicate<String> predicate2 = s -> s.startsWith("gate");
        testList.stream().filter(predicate1.and(predicate2)).forEach(System.out::println);
        System.out.println("==============or规则===============");
        // 3: or规则
        Predicate<String> predicate3 = s -> s.length() > 5;
        Predicate<String> predicate4 = s -> s.startsWith("nac");
        testList.stream().filter(predicate3.or(predicate4)).forEach(System.out::println);
        System.out.println("==============negate 取反 取非===============");
        // 4: negate 取反 取非
        Predicate<String> predicate5 = s -> s.length() > 5;
        testList.stream().filter(predicate5.negate()).forEach(System.out::println);
        System.out.println("==============isEqual 判断是否非空===============");
        // 5: isEquals 类似于eqauls方法，但是区别在于它会先判断对象是否为null，不为null在使用equals方法
        Predicate<String> predicate6 = s -> Predicate.isEqual("gateway").test(s);
        testList.stream().filter(predicate6).forEach(System.out::println);
    }
}
