package com.pugcloud.gateway.filter.factory;

import com.pugcloud.gateway.filter.HeaderTokenGatewayFilter;
import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.factory.AbstractGatewayFilterFactory;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;

/**
 * @author 飞哥
 * @Title: 学相伴出品
 * @Description: 飞哥B站地址：https://space.bilibili.com/490711252
 * 记得关注和三连哦！
 * @Description: 我们有一个学习网站：https://www.kuangstudy.com
 * @date 2022/3/30 16:18
 */
@Component
public class HeaderTokenGatewayFilterFactory extends AbstractGatewayFilterFactory<HeaderTokenGatewayFilterFactory.Config> {

    public static final String PREFIX_KEY = "prefix";

    public HeaderTokenGatewayFilterFactory() {
        super(HeaderTokenGatewayFilterFactory.Config.class);
    }

    public List<String> shortcutFieldOrder() {
        return Arrays.asList("prefix");
    }

    @Override
    public GatewayFilter apply(Config config) {
        return new HeaderTokenGatewayFilter(config);
    }

    public static class Config {
        private String prefix;

        public Config() {
        }

        public String getPrefix() {
            return this.prefix;
        }

        public void setPrefix(String prefix) {
            this.prefix = prefix;
        }
    }
}
