package com.pugcloud.gateway.filter;

import com.pugcloud.gateway.filter.factory.HeaderTokenGatewayFilterFactory;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.core.Ordered;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

/**
 * @author 飞哥
 * @Title: 学相伴出品
 * @Description: 飞哥B站地址：https://space.bilibili.com/490711252
 * 记得关注和三连哦！
 * @Description: 我们有一个学习网站：https://www.kuangstudy.com
 * @date 2022/3/30$ 15:35$
 */
@Slf4j
public class HeaderTokenGatewayFilter implements GatewayFilter, Ordered {

    private HeaderTokenGatewayFilterFactory.Config config;

    public HeaderTokenGatewayFilter(HeaderTokenGatewayFilterFactory.Config config) {
        this.config = config;
    }

    /**
     * 过滤执行
     *
     * @param exchange
     * @param chain
     * @return
     */
    @Override
    public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {
        String url = exchange.getRequest().getPath().pathWithinApplication().value();
        log.info("请求URL:" + url + "，前缀是：" + this.config.getPrefix());
        log.info("method:" + exchange.getRequest().getMethod());
        String authorization = exchange.getRequest().getHeaders().getFirst("pug-cloud-loginuser_info");
        if (StringUtils.isBlank(authorization)) {
            log.info("*****头部验证不通过，请在头部输入Authorization");
            //终止请求，直接回应
            exchange.getResponse().setStatusCode(HttpStatus.NOT_ACCEPTABLE);
            return exchange.getResponse().setComplete();
        }

        return chain.filter(exchange);
    }

    //    值越小，优先级越高
    //    int HIGHEST_PRECEDENCE = -2147483648;
    //    int LOWEST_PRECEDENCE = 2147483647;
    @Override
    public int getOrder() {
        return HIGHEST_PRECEDENCE + 2;
    }
}
