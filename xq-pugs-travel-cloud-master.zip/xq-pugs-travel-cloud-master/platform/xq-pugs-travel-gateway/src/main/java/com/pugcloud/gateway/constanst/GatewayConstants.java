package com.pugcloud.gateway.constanst;

/**
 * @author 飞哥
 * @Title: 学相伴出品
 * @Description: 飞哥B站地址：https://space.bilibili.com/490711252
 * 记得关注和三连哦！
 * @Description: 我们有一个学习网站：https://www.kuangstudy.com
 * @date 2022/3/30 17:25
 */
public interface GatewayConstants {

    /*定义登录的URI*/
    String LOGIN_URI = "/auth/login";

    /*定义注册的URI*/
    String REGISTER_URI = "/auth/register";

    /*定义授权中心的登录URI*/
    String AUTH_CENTER_LOGIN_URI = "http://%s:%s/authority/token";

    /*定义授权中心的注册URI*/
    String AUTH_CENTER_REGISTER_URI = "http://%s:%s/authority/register";
}
