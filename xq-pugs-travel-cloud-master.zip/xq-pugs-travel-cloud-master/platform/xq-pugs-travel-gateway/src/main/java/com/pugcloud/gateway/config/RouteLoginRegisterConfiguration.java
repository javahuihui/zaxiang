package com.pugcloud.gateway.config;

import com.pugcloud.gateway.constanst.GatewayConstants;
import org.springframework.cloud.gateway.route.Route;
import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.Buildable;
import org.springframework.cloud.gateway.route.builder.PredicateSpec;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.function.Function;

/**
 * @author 飞哥
 * @Title: 学相伴出品
 * @Description: 飞哥B站地址：https://space.bilibili.com/490711252
 * 记得关注和三连哦！
 * @Description: 我们有一个学习网站：https://www.kuangstudy.com
 * @date 2022/3/30$ 20:45$
 */
@Configuration
public class RouteLoginRegisterConfiguration {


    @Bean
    public RouteLocator loginRegisterRouteLocator(RouteLocatorBuilder routeLocatorBuilder){

        // 手动定义gateway的登录和注册的转发配置
        return routeLocatorBuilder.routes()
                .route("xq-pugs-travel-authority-center",
                        new Function<PredicateSpec, Buildable<Route>>() {
                    @Override
                    public Buildable<Route> apply(PredicateSpec predicateSpec) {
                          return predicateSpec
                                  // 登录的转发
                                  .path("/api"+ GatewayConstants.LOGIN_URI,"/api"+GatewayConstants.REGISTER_URI)
                                  // 网关服务转发
                                  .uri("http://localhost:9000");
                    }
                }).build();
    }

}
