package com.pugcloud.gateway.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * @author 飞哥
 * @Title: 学相伴出品
 * @Description: 飞哥B站地址：https://space.bilibili.com/490711252
 * 记得关注和三连哦！
 * @Description: 我们有一个学习网站：https://www.kuangstudy.com
 * @date 2022/3/30$ 12:39$
 */
@Component
public class NacosGatewayConfig {

    /* nacos 服务器地址*/
    public static String NACOS_SERVER_ADDR;
    /* nacos 命名空间*/
    public static String NACOS_SERVER_NAMESPACE;
    /* nacos 配置中心dataid*/
    public static String NACOS_ROUTE_DATA_ID;
    /* nacos 配置中心groupid*/
    public static String NACOS_ROUTE_GROUP;
    /**
     * 默认超时时间
     */
    public static int DEFAULT_TIMEOUT = 3000;


    @Value("${spring.cloud.nacos.discovery.server-addr}")
    public  void setNacosServerAddr(String nacosServerAddr) {
        NACOS_SERVER_ADDR = nacosServerAddr;
    }

    @Value("${spring.cloud.nacos.discovery.namespace}")
    public  void setNacosServerNamespace(String nacosServerNamespace) {
        NACOS_SERVER_NAMESPACE = nacosServerNamespace;
    }

    @Value("${nacos.gateway.route.config.data-id}")
    public  void setNacosRouteDataId(String nacosRouteDataId) {
        NACOS_ROUTE_DATA_ID = nacosRouteDataId;
    }

    @Value("${nacos.gateway.route.config.group}")
    public  void setNacosRouteGroup(String nacosRouteGroup) {
        NACOS_ROUTE_GROUP = nacosRouteGroup;
    }



}
