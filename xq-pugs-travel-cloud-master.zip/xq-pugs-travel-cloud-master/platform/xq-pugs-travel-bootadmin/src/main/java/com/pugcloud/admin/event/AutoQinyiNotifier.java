package com.pugcloud.admin.event;

import de.codecentric.boot.admin.server.domain.entities.Instance;
import de.codecentric.boot.admin.server.domain.entities.InstanceRepository;
import de.codecentric.boot.admin.server.domain.events.InstanceEvent;
import de.codecentric.boot.admin.server.domain.events.InstanceStatusChangedEvent;
import de.codecentric.boot.admin.server.notify.AbstractEventNotifier;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

/**
 * @author 飞哥
 * @Title: 学相伴出品
 * @Description: 飞哥B站地址：https://space.bilibili.com/490711252
 * 记得关注和三连哦！
 * @Description: 我们有一个学习网站：https://www.kuangstudy.com
 * @date 2022/3/29$ 14:48$
 */
@Component
@Slf4j
public class AutoQinyiNotifier extends AbstractEventNotifier {

    protected AutoQinyiNotifier(InstanceRepository repository) {
        super(repository);
    }

    // 实现对事件的通知
    @Override
    protected Mono<Void> doNotify(InstanceEvent event, Instance instance) {
        return Mono.fromRunnable(()->{
            if(event instanceof InstanceStatusChangedEvent){
                InstanceStatusChangedEvent e = (InstanceStatusChangedEvent)event;
                log.info("实列的状态发生了改变：【{}】,【{}】,【{}】",
                        instance.getRegistration().getName(),
                        event.getInstance(),
                        e.getStatusInfo().getStatus()
                );
            }else{
                log.info("实列信息是：【{}】,【{}】,【{}】",
                        instance.getRegistration().getName(),
                        event.getInstance(),
                        event.getType()
                );
            }
        });
    }
}
