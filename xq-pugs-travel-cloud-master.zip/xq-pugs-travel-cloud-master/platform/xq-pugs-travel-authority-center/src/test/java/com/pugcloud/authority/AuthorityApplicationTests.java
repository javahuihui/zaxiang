package com.pugcloud.authority;

import cn.hutool.json.JSONUtil;
import com.pugcloud.authority.dao.PugUserDao;
import com.pugcloud.authority.entity.PugUser;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * @author 飞哥
 * @Title: 学相伴出品
 * @Description: 飞哥B站地址：https://space.bilibili.com/490711252
 * 记得关注和三连哦！
 * @Description: 我们有一个学习网站：https://www.kuangstudy.com
 * @date 2022/3/29$ 15:32$
 */
@SpringBootTest
public class AuthorityApplicationTests {

    @Autowired
    private PugUserDao pugUserDao;

    @Test
    public void contextLoad(){
        PugUser pugUser = new PugUser();
        pugUser.setUsername("yykk");
        pugUser.setPassword("123456");
        PugUser pugUser1 = pugUserDao.save(pugUser);
        System.out.println(JSONUtil.toJsonStr(pugUser1));
    }
}
