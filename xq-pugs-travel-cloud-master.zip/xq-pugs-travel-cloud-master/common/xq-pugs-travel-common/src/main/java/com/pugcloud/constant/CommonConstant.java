package com.pugcloud.constant;

/**
 * <h1>通用模块常量定义</h1>
 * */
public final class CommonConstant {

    /** RSA 公钥 */
    public static final String PUBLIC_KEY = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAqsKB6tvYP11lYLYekTvWI6WW1gmyxh8NlZ+YrX1DB08U/KvsQnguKmG4/mv34OW+kqgl11dCpVQeu7QzgHkbTg4Rj4tXtzAIyoEhf6ec040DDziIrXbGebnrN4fewhqA9x0S9hw1uaJvLj17SiNYSMkTTq3DZoQAi1M0tiDoHcsAsOmTiulnig9SVtLI6/l6ezTam8jlMxYpMRByyYPXbGDU7iUKSCypmR1ORte9uT9/umFdnlCzdHjFmW1daZ5L0d+t0ZtCpJWFUvX3xYP15rrP/ju2mv8Aa/+ss+mzdnFWTu0Ef13hZNNsAkb+fsC8MfKMhPMVC2oYOcw8dTbY9wIDAQAB";

    /** JWT 中存储用户信息的 key */
    public static final String JWT_USER_INFO_KEY = "pug-cloud-loginuser_info";

    /** 授权中心的 service-id */
    public static final String AUTHORITY_CENTER_SERVICE_ID = "xq-pugs-travel-authority-center";
}
