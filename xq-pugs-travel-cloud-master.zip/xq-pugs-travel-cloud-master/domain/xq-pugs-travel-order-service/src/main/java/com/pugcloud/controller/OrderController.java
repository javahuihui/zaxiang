package com.pugcloud.controller;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.cloud.client.loadbalancer.LoadBalancerClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

/**
 * @author 飞哥
 * @Title: 学相伴出品
 * @Description: 飞哥B站地址：https://space.bilibili.com/490711252
 * 记得关注和三连哦！
 * @Description: 我们有一个学习网站：https://www.kuangstudy.com
 * @date 2022/3/29$ 11:20$
 */
@RestController
@Slf4j
public class OrderController {

    @Autowired
    private DiscoveryClient discoveryClient;
    @Autowired
    private LoadBalancerClient loadBalancerClient;
    @Autowired
    private RestTemplate restTemplate;

    @GetMapping("/makeorder")
    public String makeorder(){
        //List<ServiceInstance> instances = discoveryClient.getInstances("xq-pugs-travel-user-service");
        ServiceInstance choose = loadBalancerClient.choose("xq-pugs-travel-user-service");
        return restTemplate.getForObject("http://"+choose.getHost()+":"+choose.getPort()+"/getuser",String.class);
    }
}
