package com.pugcloud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

/**
 * @author 飞哥
 * @Title: 学相伴出品
 * @Description: 飞哥B站地址：https://space.bilibili.com/490711252
 * 记得关注和三连哦！
 * @Description: 我们有一个学习网站：https://www.kuangstudy.com
 * @date 2022/3/29$ 11:02$
 */
@SpringBootApplication
@EnableDiscoveryClient
@EnableJpaAuditing
public class PugUserServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(PugUserServiceApplication.class);
    }
}
