package com.pugcloud.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.sleuth.Tracer;
import org.springframework.stereotype.Service;

/**
 * @author 飞哥
 * @Title: 学相伴出品
 * @Description: 飞哥B站地址：https://space.bilibili.com/490711252
 * 记得关注和三连哦！
 * @Description: 我们有一个学习网站：https://www.kuangstudy.com
 * @date 2022/3/31$ 11:05$
 */
@Slf4j
@Service
public class SleuthTraceInfoService {

    @Autowired
    private  Tracer tracer;


    public void logCurrentTraceInfo(){
        log.info("sleuth trace id：【{}】",tracer.currentSpan().context().traceId());
        log.info("sleuth span id：【{}】",tracer.currentSpan().context().spanId());
    }
}
