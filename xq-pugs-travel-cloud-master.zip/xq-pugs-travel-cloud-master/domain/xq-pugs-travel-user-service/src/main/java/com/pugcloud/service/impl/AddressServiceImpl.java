package com.pugcloud.service.impl;

import com.alibaba.fastjson.JSON;
import com.pugcloud.account.AddressInfo;
import com.pugcloud.common.TableId;
import com.pugcloud.dao.PugAddressDao;
import com.pugcloud.entity.PugAddress;
import com.pugcloud.filter.UserContext;
import com.pugcloud.service.IAddressService;
import com.pugcloud.vo.LoginUserInfo;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

/**
 * <h1>用户地址相关服务接口实现</h1>
 * */
@Slf4j
@Service
@Transactional(rollbackFor = Exception.class)
public class AddressServiceImpl implements IAddressService {

    private final PugAddressDao addressDao;

    public AddressServiceImpl(PugAddressDao addressDao) {
        this.addressDao = addressDao;
    }

    /**
     * <h2>存储多个地址信息</h2>
     * */
    @Override
    public TableId createAddressInfo(AddressInfo addressInfo) {

        // 不能直接从参数中获取用户的 id 信息
        LoginUserInfo loginUserInfo = UserContext.get();

        // 将传递的参数转换成实体对象
        List<PugAddress> pugAddresses = addressInfo.getAddressItems().stream()
                .map(a -> PugAddress.to(loginUserInfo.getId(), a))
                .collect(Collectors.toList());

        // 保存到数据表并把返回记录的 id 给调用方
        List<PugAddress> savedRecords = addressDao.saveAll(pugAddresses);
        List<Long> ids = savedRecords.stream().map(PugAddress::getId).collect(Collectors.toList());
        log.info("create address info: [{}], [{}]", loginUserInfo.getId(),
                JSON.toJSONString(ids));

        return new TableId(ids.stream().map(TableId.Id::new).collect(Collectors.toList()));
    }

    @Override
    public AddressInfo getCurrentAddressInfo() {

        LoginUserInfo loginUserInfo = UserContext.get();

        // 根据 userId 查询到用户的地址信息, 再实现转换
        List<PugAddress> pugAddresses = addressDao.findAllByUserId(
                loginUserInfo.getId()
        );
        List<AddressInfo.AddressItem> addressItems = pugAddresses.stream()
                .map(PugAddress::toAddressItem)
                .collect(Collectors.toList());

        return new AddressInfo(loginUserInfo.getId(), addressItems);
    }

    @Override
    public AddressInfo getAddressInfoById(Long id) {

        PugAddress pugAddress = addressDao.findById(id).orElse(null);
        if (null == pugAddress) {
            throw new RuntimeException("address is not exist");
        }

        return new AddressInfo(
                pugAddress.getUserId(),
                Collections.singletonList(pugAddress.toAddressItem())
        );
    }

    @Override
    public AddressInfo getAddressInfoByTableId(TableId tableId) {

        List<Long> ids = tableId.getIds().stream()
                .map(TableId.Id::getId).collect(Collectors.toList());
        log.info("get address info by table id: [{}]", JSON.toJSONString(ids));

        List<PugAddress> pugAddresses = addressDao.findAllById(ids);
        if (CollectionUtils.isEmpty(pugAddresses)) {
            return new AddressInfo(-1L, Collections.emptyList());
        }

        List<AddressInfo.AddressItem> addressItems = pugAddresses.stream()
                .map(PugAddress::toAddressItem)
                .collect(Collectors.toList());

        return new AddressInfo(
                pugAddresses.get(0).getUserId(), addressItems
        );
    }
}
