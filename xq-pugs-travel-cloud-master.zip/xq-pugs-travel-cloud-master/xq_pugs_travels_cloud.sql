/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 50733
Source Host           : localhost:3306
Source Database       : xq_pugs_travels_cloud

Target Server Type    : MYSQL
Target Server Version : 50733
File Encoding         : 65001

Date: 2022-03-31 17:35:28
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for pug_address
-- ----------------------------
DROP TABLE IF EXISTS `pug_address`;
CREATE TABLE `pug_address` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `user_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '用户 id',
  `username` varchar(64) NOT NULL DEFAULT '' COMMENT '用户名',
  `phone` varchar(64) NOT NULL DEFAULT '' COMMENT '电话号码',
  `province` varchar(64) NOT NULL DEFAULT '' COMMENT '省',
  `city` varchar(64) NOT NULL DEFAULT '' COMMENT '市',
  `address_detail` varchar(256) NOT NULL DEFAULT '' COMMENT '详细地址',
  `create_time` datetime NOT NULL DEFAULT '0000-01-01 00:00:00' COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT '0000-01-01 00:00:00' COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COMMENT='用户地址表';

-- ----------------------------
-- Records of pug_address
-- ----------------------------
INSERT INTO `pug_address` VALUES ('10', '10000000', 'yykk', '15074816437', '湖南', '长沙', '长沙', '2022-03-31 17:34:08', '2022-03-31 17:34:08');

-- ----------------------------
-- Table structure for pug_balance
-- ----------------------------
DROP TABLE IF EXISTS `pug_balance`;
CREATE TABLE `pug_balance` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `user_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '用户 id',
  `balance` bigint(20) NOT NULL DEFAULT '0' COMMENT '账户余额',
  `create_time` datetime NOT NULL DEFAULT '0000-01-01 00:00:00' COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT '0000-01-01 00:00:00' COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id_key` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COMMENT='用户账户余额表';

-- ----------------------------
-- Records of pug_balance
-- ----------------------------

-- ----------------------------
-- Table structure for pug_goods
-- ----------------------------
DROP TABLE IF EXISTS `pug_goods`;
CREATE TABLE `pug_goods` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `goods_category` varchar(64) NOT NULL DEFAULT '' COMMENT '商品类别',
  `brand_category` varchar(64) NOT NULL DEFAULT '' COMMENT '品牌分类',
  `goods_name` varchar(64) NOT NULL DEFAULT '' COMMENT '商品名称',
  `goods_pic` varchar(256) NOT NULL DEFAULT '' COMMENT '商品图片',
  `goods_description` varchar(512) NOT NULL DEFAULT '' COMMENT '商品描述信息',
  `goods_status` int(11) NOT NULL DEFAULT '0' COMMENT '商品状态',
  `price` int(11) NOT NULL DEFAULT '0' COMMENT '商品价格',
  `supply` bigint(20) NOT NULL DEFAULT '0' COMMENT '总供应量',
  `inventory` bigint(20) NOT NULL DEFAULT '0' COMMENT '库存',
  `goods_property` varchar(1024) NOT NULL DEFAULT '' COMMENT '商品属性',
  `create_time` datetime NOT NULL DEFAULT '0000-01-01 00:00:00' COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT '0000-01-01 00:00:00' COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `goods_category_brand_name` (`goods_category`,`brand_category`,`goods_name`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COMMENT='商品表';

-- ----------------------------
-- Records of pug_goods
-- ----------------------------

-- ----------------------------
-- Table structure for pug_logistics
-- ----------------------------
DROP TABLE IF EXISTS `pug_logistics`;
CREATE TABLE `pug_logistics` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `user_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '用户 id',
  `order_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '订单 id',
  `address_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '用户地址记录 id',
  `extra_info` varchar(512) NOT NULL COMMENT '备注信息(json 存储)',
  `create_time` datetime NOT NULL DEFAULT '0000-01-01 00:00:00' COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT '0000-01-01 00:00:00' COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COMMENT='物流表';

-- ----------------------------
-- Records of pug_logistics
-- ----------------------------

-- ----------------------------
-- Table structure for pug_order
-- ----------------------------
DROP TABLE IF EXISTS `pug_order`;
CREATE TABLE `pug_order` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `user_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '用户 id',
  `address_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '用户地址记录 id',
  `order_detail` text NOT NULL COMMENT '订单详情(json 存储, goodsId, count)',
  `create_time` datetime NOT NULL DEFAULT '0000-01-01 00:00:00' COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT '0000-01-01 00:00:00' COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COMMENT='用户订单表';

-- ----------------------------
-- Records of pug_order
-- ----------------------------

-- ----------------------------
-- Table structure for pug_undo_log
-- ----------------------------
DROP TABLE IF EXISTS `pug_undo_log`;
CREATE TABLE `pug_undo_log` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `branch_id` bigint(20) NOT NULL,
  `xid` varchar(100) NOT NULL,
  `context` varchar(128) NOT NULL,
  `rollback_info` longblob NOT NULL,
  `log_status` int(11) NOT NULL,
  `log_created` datetime NOT NULL,
  `log_modified` datetime NOT NULL,
  `ext` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_undo_log` (`xid`,`branch_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of pug_undo_log
-- ----------------------------

-- ----------------------------
-- Table structure for pug_user
-- ----------------------------
DROP TABLE IF EXISTS `pug_user`;
CREATE TABLE `pug_user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `username` varchar(64) NOT NULL DEFAULT '' COMMENT '用户名',
  `password` varchar(256) NOT NULL DEFAULT '' COMMENT 'MD5 加密之后的密码',
  `extra_info` varchar(1024) NOT NULL DEFAULT '' COMMENT '额外的信息',
  `create_time` datetime NOT NULL DEFAULT '0000-01-01 00:00:00' COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT '0000-01-01 00:00:00' COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `username` (`username`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='用户表';

-- ----------------------------
-- Records of pug_user
-- ----------------------------
INSERT INTO `pug_user` VALUES ('10000000', 'yykk', '123456', '{}', '2022-03-29 15:48:06', '2022-03-29 15:48:06');
