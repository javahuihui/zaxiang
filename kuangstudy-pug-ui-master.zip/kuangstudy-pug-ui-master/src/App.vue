<template>
  <div class="ksd-container-box">
    <keep-alive>
      <router-view/>
    </keep-alive>
  </div>

</template>

<script>

export default {
  name: 'App',
  components: {
  }
}
</script>

<style>
@import '~@/assets/css/app.css';
@import '~@/assets/css/xqui.css';
@import '~@/assets/css/animate.css';
@import '~@/assets/fonts/iconfont.css';

</style>
