
// 导入状态管理vuex
import {createStore} from "vuex"
// 持久划管理信息
import VuexPersistence from 'vuex-persist'
// 1: 登录的状态管理
import login from './module/login'
// 2: 菜单状态管理
import menu from './module/menu'
// 3: 状态管理的消息数量
import sysmsg from './module/sysmsg'

import defaultSettings from '@/settings'

// 本地缓存vuex管理信息
const vuexLocal = new VuexPersistence({
  key: defaultSettings.cacheSuffix + "vuex",
  storage: window.sessionStorage
})


// 创建状态管
const store = createStore({
  strict: true,
  modules: {
    login,
    sysmsg,
    menu
  },
  plugins: [vuexLocal.plugin]
})

// 导出
export default store;
