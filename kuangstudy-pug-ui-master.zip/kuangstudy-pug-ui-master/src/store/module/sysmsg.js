export default {
  namespaced: true,
  // 1: 定义状态管理
  state() {
    return {
      syscount: 0
    }
  },
  // 2: 唯一能够改变状态管理的方法的定义的位置
  mutations: {
    changeMsg(state) {
      state.syscount++;
    }
  },
  // 3: 执行异步处理的函数。它不能直接改变state,只能通过提交commit的mutations的方法改变状态数据
  actions: {},

  // 4: 对状态数据的加工，处理，聚合（求最大值，最小值，平局值，统计，平均值，过滤，分组等）
  // 好处：可以减少外面逻辑判断和处理
  getters: {
      scount(state){
        return state.syscount;
      }
  }
}
