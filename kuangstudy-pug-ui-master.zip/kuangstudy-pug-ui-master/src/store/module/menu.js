const defaultSettings = require('@/settings.js')
import pug from "@/plugins/PugMessage";

export default {
  namespaced: true,
  state() {
    return {
      menus: [],
    }
  },
  mutations: {
    // 添加菜单
    addMenu(state, payload) {
      // 1： 根据你路径查找是否在数组，中
      var index = state.menus.findIndex(s => s.path == payload.path);
      // 2: 如果不在index = -1 ，追加到数组中
      if (index == -1) {
        state.menus.map(menu=>menu.active = false);
        // 3 :添加进去即可
        state.menus.push(payload);
        // 4: 打开的最大数量 超过defaultSettings.menucount = 10个
        const mlen = state.menus.length;
        if(mlen > defaultSettings.menucount){
          // 5: 数组首位弹出 pop() 末尾弹出 shift() 首位弹出
          state.menus.shift();
        }
      }
    },

    // 关闭菜单
    closeMenu(state, index) {
      var active = state.menus[index].active;
      if(!active) {
        state.menus.splice(index, 1);
      }else{
        pug.warn("关闭未选中的节点");
      }
    },

    // 清除菜单
    clearMenu(state) {
      state.menus = [];
    }
  },
  actions: {},
  getters: {
    menuLen(state){
      return state.menus.length;
    }
  }
}
