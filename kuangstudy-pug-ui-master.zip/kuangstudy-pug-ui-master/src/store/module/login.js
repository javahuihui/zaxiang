import request from "@/utils/request";
import cache from "@/utils/cache";


export default {
  namespaced: true,
  state() {
    return {
      user: {},
    }
  },
  mutations: {
    // 同步状态管理
    toggleUser(state, res) {
      state.user = {...res}
    },

    // 清楚状态管理
    clearUser(state) {
      state.user = {}
    }
  },
  actions: {

    async logout(context) {
      // 发起异步请求,服务器段会token打入黑名单中
      const res = await request.post("/auth/logout");
      // 如果执行成功，把本地的session缓存和状态全部清楚
      console.log(typeof res)
      if (res.status == 200) {

        // 清楚本地缓存
        cache.session.remove("token");
        cache.session.remove("nickname");
        cache.session.remove("userId");
        cache.session.remove("vuex");
        // 清楚状态管理
        context.commit("clearUser");
        // 清楚状态管理的菜单。跨模块清除
        context.commit('menu/clearMenu', null, {root: true});
        // 退出执行逻辑
        return Promise.resolve(true);
      }
    },

    // 登录逻辑
    async logined({commit}, logininfo) {
      try {
        // 1: 异步执行. res就是服务器请求的信息
        const res = await request.post("/auth/login/pwd", logininfo);
        // 2：如果请求成功就是200
        if (res.status == 200) {
          // 3: 获取服务器段返回的数据信息
          const {token, userId, nickname} = res.data;
          // 4: 把服务器段信息放入到session中
          cache.session.set("token", token);
          cache.session.set("nickname", nickname);
          cache.session.set("userId", userId);
          // 状态管理
          commit("toggleUser", res.data);
          // 为什么返回承诺promise,
          return Promise.resolve(res.data);
        } else {
          return Promise.reject(res);
        }
      } catch (err) {
        alert("服务器忙...");
      }
    }
  },

  getters: {
    isLogin: state => {
      return state.user.userId;
    },
    rolename: state => {
      return state.user.roleList.map(role => role.name).join(",")
    },
    permissons:state=>{
      return state.user.permissionList.map(per=>({id:per.id,name:per.name,code:per.code,url:per.url}));
    }
  }
}
