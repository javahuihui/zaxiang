<template>
    <div v-if="isshow">
      <slot></slot>
    </div>
</template>

<script>
import {createNamespacedHelpers} from 'vuex'
const {mapGetters} = createNamespacedHelpers('login')

export default {
  name: "PugPermission",
  props:{
    url:{
      type:String
    }
  },
  data() {
    return {}
  },

  computed: {
    ...mapGetters(['permissons']),
    isshow () {
      var count = this.permissons.filter(p=>(p.url.indexOf(this.url)!=-1)).length;
      return count > 0;
    }
  },
  created() {

  },

  methods: {}

}
</script>

<style scoped>

</style>
