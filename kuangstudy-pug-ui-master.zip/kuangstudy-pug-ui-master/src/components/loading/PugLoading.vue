<template>
  <div class="pug-loadingbox" v-if="showtype<=2">
    <div class="spinner3">
      <div class="rect1"></div>
      <div class="rect2"></div>
      <div class="rect3"></div>
      <div class="rect4"></div>
      <div class="rect5"></div>
    </div>
    <div class="load_title" v-if="showtext">{{ showtext[showtype - 1] }}</div>
  </div>
</template>

<script>
export default {
  name: "PugLoading",
  props: {
    showtype: {
      type: Number,
      default: 1
    },
    showtext: {
      type: Array,
      default: ["美好的事情即将发生，请耐心等待", "数据加载中", "数据加载完毕"]
    }
  },
  data() {
    return {}
  },

  created() {

  },
  methods: {}

}
</script>

<style scoped>

.spinner3 {
  margin: 0px auto 20px;
  width: 50px;
  height: 60px;
  text-align: center;
  font-size: 10px;
}

.spinner3 > div {
  background-color: #67CF22;
  height: 100%;
  width: 6px;
  display: inline-block;

  -webkit-animation: stretchdelay 1.2s infinite ease-in-out;
  animation: stretchdelay 1.2s infinite ease-in-out;
}

.spinner3 .rect2 {
  -webkit-animation-delay: -1.1s;
  animation-delay: -1.1s;
}

.spinner3 .rect3 {
  -webkit-animation-delay: -1.0s;
  animation-delay: -1.0s;
}

.spinner3 .rect4 {
  -webkit-animation-delay: -0.9s;
  animation-delay: -0.9s;
}

.spinner3 .rect5 {
  -webkit-animation-delay: -0.8s;
  animation-delay: -0.8s;
}

@-webkit-keyframes stretchdelay {
  0%, 40%, 100% {
    -webkit-transform: scaleY(0.4)
  }
  20% {
    -webkit-transform: scaleY(1.0)
  }
}

@keyframes stretchdelay {
  0%, 40%, 100% {
    transform: scaleY(0.4);
    -webkit-transform: scaleY(0.4);
  }
  20% {
    transform: scaleY(1.0);
    -webkit-transform: scaleY(1.0);
  }
}

.load_title {
  font-size: 14px;
  text-align: center
}

@keyframes loading {
  0% {
    background-position: -400px 0
  }

  100% {
    background-position: 400px 0
  }
}
</style>
