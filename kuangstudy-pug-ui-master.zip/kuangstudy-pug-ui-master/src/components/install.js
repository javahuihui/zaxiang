import {
  PugLoading,
  PugTree,
  PugCalendar,
  PugInput,
  PugCheckbox,
  PugEditor,
  PugPage,
  PugRadio,
  PugSelect,
  PugPermission,
  PugUpload
} from './index'

// 导出组件
export default {
  install: function (app) {
    app.component('PugRadio', PugRadio)
    app.component('PugSelect', PugSelect)
    app.component('PugInput', PugInput)
    app.component('PugPage', PugPage)
    app.component('PugCheckbox', PugCheckbox)
    app.component('PugUpload', PugUpload)
    app.component('PugCalendar', PugCalendar)
    app.component('PugPermission', PugPermission)
    app.component('PugTree', PugTree)
    app.component('PugLoading', PugLoading)
    app.component('PugEditor', PugEditor)
  }
}
