<template>
  <div class="pug-tree">
    <ul class="ksdtreeul">
      <li @click.stop='expand(item)' v-for="(item,index) in list" :key="index">
        <div class='ksd-libox' :title='item.title'>
          <a href='javascript:void(0);' class='titc'>
            <span v-if="item.childrens && item.childrens.length > 0" class="pr5">
              <i class="iconfont icon-zhankai1 fz16" v-if="item.isexpand==1"></i>
              <i class="iconfont icon-zhankai fz16" v-else></i>
            </span>
            <span :class="[item.islast==1?'fw':'']">{{
                (index + 1 < 10 ? '0' + (index + 1) : (index + 1))
              }}、{{ item.title }}</span>
            <span v-if="item.childrens && item.childrens.length > 0">({{ item.childrens.length }})</span>
          </a>
          <span style='font-size:12px;'>
          <span v-if='item.mark==1' style='color: green;font-weight: bold'>【已完结】</span>
          <span v-else style='color:red;'>【未开始】</span>
          <span v-if='item.isonline==1' style='color:red;'>【直播中】</span>
          <span v-if='item.islast==1' style='color:red;font-weight: bold'>【最后更新】</span></span>
        </div>
        <pug-tree v-show='item.isexpand == 1' @event="addNode" v-if="item.childrens" :list='item.childrens'></pug-tree>
      </li>
    </ul>
  </div>
</template>

<script>
export default {
  props: {
    list: Array
  },
  name: "PugTree",
  data() {
    return {}
  },
  methods: {
    expand: function (obj) {
      obj.isexpand = obj.isexpand == 1 ? 2 :1;
    },
    addNode: function (item) {
      console.log(item);
    },
    editNode: function (item) {
      console.log(item);
    },
    delNode: function (item, index) {
      console.log(item, index)
    },
    lookNode: function (item) {
      console.log(item)
    }
  }
}
</script>

<style scoped>



.pug-tree ul.ksdtreeul  ul.ksdtreeul {
  margin-left: 15px;
  border-left: 1px dotted #c0c4cc;
}


.pug-tree ul.ksdtreeul li {
  line-height: 32px;
  padding-left: 18px;
}

.pug-tree ul.ksdtreeul li ul {
  margin-left: 30px;
}

.pug-tree a {
  font-size: 14px;
  margin-left: 7px;
  color: #636363;
}

.pug-tree a, .pug-tree span {
  vertical-align: top;
  color: #636363;
}

.pug-tree ul.ksdtreeul .ksd-libox a.titc {
  text-overflow: ellipsis;
  display: inline-block;
  overflow: hidden;
  white-space: nowrap;
  max-width: 360px
}

.pug-tree ul.ksdtreeul .ksd-libox:hover a.titc {
  text-overflow: ellipsis;
  display: inline-block;
  overflow: hidden;
  white-space: nowrap;
}

.red ul {
  border-left-color: #eca6b4;
}

</style>
