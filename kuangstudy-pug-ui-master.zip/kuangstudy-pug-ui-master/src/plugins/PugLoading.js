export default {
    install: (app) => {
        // 挂对象
        app.config.globalProperties.$loading = (open) => {
            if(!open) {
                var loadom = document.createElement("div");
                loadom.className = "pug-loading-box";
                loadom.innerHTML = "<div class=\"loadingThree\">\n" +
                    "    <span></span>\n" +
                    "    <span></span>\n" +
                    "    <span></span>\n" +
                    "    <span></span>\n" +
                    "    <span></span>\n" +
                    "</div>";
                document.body.appendChild(loadom);
            }else if(open == 'remove'){
                var element = document.querySelector(".pug-loading-box");
                document.body.removeChild(element);
            }
        }
    }
}