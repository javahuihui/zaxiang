var pug = {
  error(msg,time = 3) {
    this.message(msg, time, "cuowu1", "#fff")
  },

  success(msg,time= 3) {
    this.message(msg, time, "zhengque", "#fff")
  },

  warn(msg,time= 3) {
    this.message(msg, time , "jinggao", "#333")
  },

  message(msg, time = 3, icon = 'zhengque', textcolor = '#fff') {
    let loadom = document.createElement("div");
    loadom.className = "pug-message-box pug-message-" + icon + " animated fadeInDown";
    loadom.innerHTML = "<div class=\"pug-message-boxtext\">\n" +
      " <i class='iconfont icon-" + icon + "'  style='color:" + textcolor + "'></i><span class='pl6' style='color:" + textcolor + "'>" + msg + "</span>\n" +
      "</div>";

    loadom.onclick = function () {
      this.className = "pug-message-box pug-message-"+icon+" animated fadeOutUp";
      if (this.stimer) clearTimeout(this.stimer);
      this.stimer = setTimeout(() => {
        document.body.removeChild(this)
        clearTimeout(this.stimer)
      }, 1000)
    },

    document.body.appendChild(loadom)

    if (loadom.stimer) clearTimeout(loadom.stimer);
    loadom.stimer = setTimeout(() => {
      loadom.onclick();
      clearTimeout(loadom.stimer)
    }, 1000 * time);

  }
}


export default pug;
