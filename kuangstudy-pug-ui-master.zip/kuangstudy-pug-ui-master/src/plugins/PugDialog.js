var pugDialog = {
  alert(title, content, options = {}) {
    return this.dialog(title, content, options)
  },

  confirm(title, content, options = {}) {
    options.showclose = true;
    return this.dialog(title, content, options)
  },

  iframe(title, content, options = {}) {
    return this.dialog(title, content, options)
  },

  html(title, content, options = {}) {
    return this.dialog(title, content, options)
  },

  prompt(title, content, options = {}) {
    return this.dialog(title, content, options)
  },

  timeout(title, content, options = {}) {
    return this.dialog(title, content, options)
  },

  dialog(title, content, options = {time: 0, showclose: false}) {
    return new Promise((resolve, reject) => {
      // 创建弹出层
      let loadom = document.createElement("div");
      var html = ` <div role="document" class="pug-modal pug-modal-confirm pug-modal-confirm-confirm" style="width: 372px; transform-origin: 1048px 383px;">
       <div class="pug-modal-content">
        <div class="pug-modal-body">
         <div class="pug-modal-confirm-body-wrapper">
          <div class="pug-modal-confirm-body">
           <span role="img" aria-label="exclamation-circle" class="anticon anticon-exclamation-circle">
            <svg viewbox="64 64 896 896" focusable="false" data-icon="exclamation-circle" width="1em" height="1em" fill="currentColor" aria-hidden="true">
             <path d="M512 64C264.6 64 64 264.6 64 512s200.6 448 448 448 448-200.6 448-448S759.4 64 512 64zm0 820c-205.4 0-372-166.6-372-372s166.6-372 372-372 372 166.6 372 372-166.6 372-372 372z"></path>
             <path d="M464 688a48 48 0 1096 0 48 48 0 10-96 0zm24-112h48c4.4 0 8-3.6 8-8V296c0-4.4-3.6-8-8-8h-48c-4.4 0-8 3.6-8 8v272c0 4.4 3.6 8 8 8z"></path>
            </svg></span>
           <span class="pug-modal-confirm-title">${title}</span>
           <div class="pug-modal-confirm-content">${content}</div>
          </div>
          <div class="pug-modal-confirm-btns"><button type="button" class="pug-btn pug-close-event"><span>${options.closeText || '取 消'}</span></button> <button type="button" class="pug-btn pug-sure-event pug-btn-primary"><span>${options.sureText || '确 认'}</span><span class="pug-modal-time pl2"></span></button></div>
         </div>
        </div>
       </div>
       <div tabindex="0" aria-hidden="true" style="width: 0px; height: 0px; overflow: hidden; outline: none;"></div>
      </div>`;
      loadom.className = "pug-modal-wrap animated fadeInDown";
      loadom.innerHTML = html;
      // 创建遮罩层
      let maskdom = document.createElement("div");
      maskdom.className = "pug-modal-mask";
      document.body.appendChild(maskdom)
      document.body.appendChild(loadom)


      if (!options.showclose) {
        var closedom = loadom.querySelector(".pug-close-event");
        closedom.style.display = "none";
      }

      loadom.querySelector(".pug-close-event").onclick = function () {
        loadom.className = "pug-modal-wrap animated fadeOutUp";
        if (loadom.stimer) clearTimeout(loadom.stimer);
        document.body.removeChild(maskdom)
        reject(false);
        loadom.stimer = setTimeout(() => {
          document.body.removeChild(loadom)
          clearTimeout(loadom.stimer)
        }, 1000)
      };

      loadom.querySelector(".pug-sure-event").onclick = function () {
        loadom.className = "pug-modal-wrap animated fadeOutUp";
        if (loadom.stimer) clearTimeout(loadom.stimer);
        document.body.removeChild(maskdom)
        resolve(true);
        loadom.stimer = setTimeout(() => {
          document.body.removeChild(loadom)
          clearTimeout(loadom.stimer)
        }, 1000)
      };

      if (options.time > 0) {
        if (loadom.stimer) clearTimeout(loadom.stimer);
        loadom.stimer = setTimeout(() => {
          loadom.querySelector(".pug-close-event").onclick();
          clearTimeout(loadom.stimer)
        }, 1000 * options.time);

        if (loadom.cstimer) clearTimeout(loadom.cstimer);
        loadom.cstimer = setInterval(() => {
          if (options.time <= 1) {
            clearTimeout(loadom.cstimer);
            loadom.querySelector(".pug-modal-time").innerHTML = "1s";
            return;
          }
          loadom.querySelector(".pug-modal-time").innerHTML = options.time + "s";
          options.time--;
        }, 1000)

      }
    });
  }
}


export default pugDialog;
