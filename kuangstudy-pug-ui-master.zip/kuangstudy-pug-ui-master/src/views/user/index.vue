<template>
  <div>我是用户中心</div>
</template>

<script>
// import xxx from '@/xxx/xxxx';
export default {
  name: "index",
  data() {
    return {}
  },

  created() {

  },
  methods: {}

}
</script>

<style scoped>

</style>
