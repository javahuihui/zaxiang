<template>
  <h1>我是消息列表</h1>
  <div>
    <button @click="changeMsg">添加消息</button>
  </div>
</template>

<script>

// 第二种方案:mapMu
//import {mapMutations} from 'vuex'

// 第三种方案
import {createNamespacedHelpers} from 'vuex'
const {mapMutations} = createNamespacedHelpers("sysmsg");

export default {
  name: "index.vue",
  data() {
    return {}
  },

  created() {

  },
  methods: {
    ...mapMutations({'changeMsg': "changeMsg"}),
    //...mapMutations({'changeMsg':'sysmsg/changeMsg','login':'login/toLogin'})
    //...mapMutations('sysmsg',{'changeMsg':'changeMsg'})
    //...mapMutations('sysmsg',["changeMsg"])

    // addmsg() {
    //    // 第一种方式 mutations的方式是通过：commit
    //   this.$store.commit("sysmsg/changeMsg");
    // }
  }

}
</script>

<style scoped>

</style>
