<template>
  <main class="pug-pro-basicLayout-content pug-pro-basicLayout-has-header">
    <div class="pug-pro-page-container">
      <div class="pug-pro-page-container-warp">
        <div class="pug-page-header has-breadcrumb">
          <div class="pug-page-header-heading">
            <div class="pug-page-header-heading-left"><span class="pug-page-header-heading-title"
                                                            title="高级表单">高级表单</span></div>
          </div>
          <div class="pug-page-header-content">
            <div class="pug-pro-page-container-detail">
              <div class="pug-pro-page-container-main">
                <div class="pug-pro-page-container-row">
                  <div class="pug-pro-page-container-content">高级表单常见于一次性输入和提交大批量数据的场景。</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div id="div1">
      </div>
    </div>
  </main>

</template>

<script>

import E from "wangeditor"

export default {
  data() {
    return {}
  },
  mounted() {
    const editor = new E("#div1")

    // 设置编辑区域高度为 500px
    editor.config.height = window.innerHeight - 200;
    editor.create()
  },
  methods: {}
}
</script>
