<template>
  <main class="pug-pro-basicLayout-content pug-pro-basicLayout-has-header">
    <form autocomplete="off" class="pug-form pug-form-vertical pug-form-hide-required-mark">
      <div class="pug-pro-page-container">
        <div class="pug-pro-page-container-warp">
          <div class="pug-page-header has-breadcrumb">
            <div class="pug-page-header-heading">
              <div class="pug-page-header-heading-left"><span class="pug-page-header-heading-title" title="高级表单">高级表单</span></div>
            </div>
            <div class="pug-page-header-content">
              <div class="pug-pro-page-container-detail">
                <div class="pug-pro-page-container-main">
                  <div class="pug-pro-page-container-row">
                    <div class="pug-pro-page-container-content">高级表单常见于一次性输入和提交大批量数据的场景。</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="pug-pro-grid-content">
          <div class="pug-pro-grid-content-children">
            <div class="pug-pro-layout-watermark-wrapper" style="position: relative;">
              <div class="pug-pro-page-container-children-content">
                <div class="pug-card card___1dsH6">
                  <div class="pug-card-head">
                    <div class="pug-card-head-wrapper">
                      <div class="pug-card-head-title">仓库管理</div>
                    </div>
                  </div>
                  <div class="pug-card-body">
                    <div class="pug-row" style="margin-left: -8px; margin-right: -8px; row-gap: 0px;">
                      <div class="pug-col pug-col-sm-24 pug-col-md-12 pug-col-lg-6"
                           style="padding-left: 8px; padding-right: 8px;">
                        <div class="pug-row pug-form-item" style="row-gap: 0px;">
                          <div class="pug-col pug-form-item-label"><label for="name" class="pug-form-item-required"
                                                                          title="仓库名">仓库名</label></div>
                          <div class="pug-col pug-form-item-control">
                            <div class="pug-form-item-control-input">
                              <div class="pug-form-item-control-input-content"><span
                                class="pug-input-affix-wrapper"><input placeholder="请输入仓库名称" id="name" type="text"
                                                                       class="pug-input" value=""></span>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="pug-col pug-col-sm-24 pug-col-md-12 pug-col-lg-8 pug-col-xl-6 pug-col-xl-offset-2"
                           style="padding-left: 8px; padding-right: 8px;">
                        <div class="pug-row pug-form-item" style="row-gap: 0px;">
                          <div class="pug-col pug-form-item-label"><label for="url" class="pug-form-item-required"
                                                                          title="仓库域名">仓库域名</label></div>
                          <div class="pug-col pug-form-item-control">
                            <div class="pug-form-item-control-input">
                              <div class="pug-form-item-control-input-content"><span class="pug-input-group-wrapper"
                                                                                     style="width: 100%;"><span
                                class="pug-input-wrapper pug-input-group"><span
                                class="pug-input-group-addon">http://</span><span class="pug-input-affix-wrapper"><input
                                placeholder="请输入" id="url" type="text" class="pug-input" value=""></span><span
                                class="pug-input-group-addon">.com</span></span></span></div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="pug-col pug-col-sm-24 pug-col-md-24 pug-col-lg-10 pug-col-xl-8 pug-col-xl-offset-2"
                           style="padding-left: 8px; padding-right: 8px;">
                        <div class="pug-row pug-form-item" style="row-gap: 0px;">
                          <div class="pug-col pug-form-item-label"><label for="owner" class="pug-form-item-required"
                                                                          title="仓库管理员">仓库管理员</label></div>
                          <div class="pug-col pug-form-item-control">
                            <div class="pug-form-item-control-input">
                              <div class="pug-form-item-control-input-content">
                                <div
                                  class="pug-select pug-pro-filed-search-select pug-select-single pug-select-allow-clear pug-select-show-arrow"
                                  style="min-width: 100px;">
                                  <div class="pug-select-selector"><span class="pug-select-selection-search"><input
                                    id="owner" autocomplete="off" type="search"
                                    class="pug-select-selection-search-input" role="combobox" aria-haspopup="listbox"
                                    aria-owns="owner_list" aria-autocomplete="list" aria-controls="owner_list"
                                    aria-activedescendant="owner_list_0" readonly="" unselectable="on" value=""
                                    style="opacity: 0;"></span><span
                                    class="pug-select-selection-placeholder">请选择管理员</span></div>
                                  <span class="pug-select-arrow" unselectable="on" aria-hidden="true"
                                        style="user-select: none;"><span role="img" aria-label="down"
                                                                         class="anticon anticon-down pug-select-suffix"><svg
                                    viewBox="64 64 896 896" focusable="false" data-icon="down" width="1em" height="1em"
                                    fill="currentColor" aria-hidden="true"><path
                                    d="M884 256h-75c-5.1 0-9.9 2.5-12.9 6.6L512 654.2 227.9 262.6c-3-4.1-7.8-6.6-12.9-6.6h-75c-6.5 0-10.3 7.4-6.5 12.7l352.6 486.1c12.8 17.6 39 17.6 51.7 0l352.6-486.1c3.9-5.3.1-12.7-6.4-12.7z"></path></svg></span></span>
                                </div>
                                <div class="pug-select-dropdown pug-select-dropdown-placement-bottomLeft  pug-select-dropdown-hidden" style="min-width: 548px; width: 548px; left: 0px; top: 32px;"><div><div role="listbox" id="approver_list" style="height: 0px; width: 0px; overflow: hidden;"><div aria-label="付晓晓" role="option" id="approver_list_0" aria-selected="false">xiao</div><div aria-label="周毛毛" role="option" id="approver_list_1" aria-selected="false">mao</div></div><div class="rc-virtual-list" style="position: relative;"><div class="rc-virtual-list-holder" style="max-height: 256px; overflow-y: hidden; overflow-anchor: none;"><div><div class="rc-virtual-list-holder-inner" style="display: flex; flex-direction: column;"><div label="付晓晓" data-item="[object Object]" aria-selected="false" class="pug-select-item pug-select-item-option pug-pro-filed-search-select-option  pug-select-item-option-active" title="付晓晓"><div class="pug-select-item-option-content">付晓晓</div><span class="pug-select-item-option-state" unselectable="on" aria-hidden="true" style="user-select: none;"></span></div><div label="周毛毛" data-item="[object Object]" aria-selected="false" class="pug-select-item pug-select-item-option pug-pro-filed-search-select-option " title="周毛毛"><div class="pug-select-item-option-content">周毛毛</div><span class="pug-select-item-option-state" unselectable="on" aria-hidden="true" style="user-select: none;"></span></div></div></div></div><div class="rc-virtual-list-scrollbar" style="width: 8px; top: 0px; bottom: 0px; right: 0px; position: absolute; display: none;"><div class="rc-virtual-list-scrollbar-thumb" style="width: 100%; height: 128px; top: 0px; left: 0px; position: absolute; background: rgba(0, 0, 0, 0.5); border-radius: 99px; cursor: pointer; user-select: none;"></div></div></div></div></div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="pug-row" style="margin-left: -8px; margin-right: -8px; row-gap: 0px;">
                      <div class="pug-col pug-col-sm-24 pug-col-md-12 pug-col-lg-6"
                           style="padding-left: 8px; padding-right: 8px;">
                        <div class="pug-row pug-form-item" style="row-gap: 0px;">
                          <div class="pug-col pug-form-item-label"><label for="approver" class="pug-form-item-required"
                                                                          title="审批人">审批人</label></div>
                          <div class="pug-col pug-form-item-control">
                            <div class="pug-form-item-control-input">
                              <div class="pug-form-item-control-input-content">
                                <div
                                  class="pug-select pug-pro-filed-search-select pug-select-single pug-select-allow-clear pug-select-show-arrow"
                                  style="min-width: 100px;">
                                  <div class="pug-select-selector"><span class="pug-select-selection-search"><input
                                    id="approver" autocomplete="off" type="search"
                                    class="pug-select-selection-search-input" role="combobox" aria-haspopup="listbox"
                                    aria-owns="approver_list" aria-autocomplete="list" aria-controls="approver_list"
                                    aria-activedescendant="approver_list_0" readonly="" unselectable="on" value=""
                                    style="opacity: 0;" aria-expanded="false"></span><span
                                    class="pug-select-selection-placeholder">请选择管理员</span></div>
                                  <span class="pug-select-arrow" unselectable="on" aria-hidden="true"
                                        style="user-select: none;"><span role="img" aria-label="down"
                                                                         class="anticon anticon-down pug-select-suffix"><svg
                                    viewBox="64 64 896 896" focusable="false" data-icon="down" width="1em" height="1em"
                                    fill="currentColor" aria-hidden="true"><path
                                    d="M884 256h-75c-5.1 0-9.9 2.5-12.9 6.6L512 654.2 227.9 262.6c-3-4.1-7.8-6.6-12.9-6.6h-75c-6.5 0-10.3 7.4-6.5 12.7l352.6 486.1c12.8 17.6 39 17.6 51.7 0l352.6-486.1c3.9-5.3.1-12.7-6.4-12.7z"></path></svg></span></span>
                                </div>

                                <div class="pug-select-dropdown pug-select-dropdown-placement-bottomLeft  pug-select-dropdown-hidden" style="min-width: 548px; width: 548px; left: 0px; top: 32px;"><div><div role="listbox" id="approver_list" style="height: 0px; width: 0px; overflow: hidden;"><div aria-label="付晓晓" role="option" id="approver_list_0" aria-selected="false">xiao</div><div aria-label="周毛毛" role="option" id="approver_list_1" aria-selected="false">mao</div></div><div class="rc-virtual-list" style="position: relative;"><div class="rc-virtual-list-holder" style="max-height: 256px; overflow-y: hidden; overflow-anchor: none;"><div><div class="rc-virtual-list-holder-inner" style="display: flex; flex-direction: column;"><div label="付晓晓" data-item="[object Object]" aria-selected="false" class="pug-select-item pug-select-item-option pug-pro-filed-search-select-option  pug-select-item-option-active" title="付晓晓"><div class="pug-select-item-option-content">付晓晓</div><span class="pug-select-item-option-state" unselectable="on" aria-hidden="true" style="user-select: none;"></span></div><div label="周毛毛" data-item="[object Object]" aria-selected="false" class="pug-select-item pug-select-item-option pug-pro-filed-search-select-option " title="周毛毛"><div class="pug-select-item-option-content">周毛毛</div><span class="pug-select-item-option-state" unselectable="on" aria-hidden="true" style="user-select: none;"></span></div></div></div></div><div class="rc-virtual-list-scrollbar" style="width: 8px; top: 0px; bottom: 0px; right: 0px; position: absolute; display: none;"><div class="rc-virtual-list-scrollbar-thumb" style="width: 100%; height: 128px; top: 0px; left: 0px; position: absolute; background: rgba(0, 0, 0, 0.5); border-radius: 99px; cursor: pointer; user-select: none;"></div></div></div></div></div>

                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="pug-col pug-col-sm-24 pug-col-md-12 pug-col-lg-8 pug-col-xl-6 pug-col-xl-offset-2"
                           style="padding-left: 8px; padding-right: 8px;">
                        <div class="pug-row pug-form-item" style="row-gap: 0px;">
                          <div class="pug-col pug-form-item-label"><label for="dateRange" class="pug-form-item-required"
                                                                          title="生效日期">生效日期</label></div>
                          <div class="pug-col pug-form-item-control">
                            <div class="pug-form-item-control-input">
                              <div class="pug-form-item-control-input-content">
                                <div class="pug-picker pug-picker-range" style="width: 100%;">
                                  <div class="pug-picker-input"><input id="dateRange" readonly="" placeholder="请选择"
                                                                       size="12" autocomplete="off" value=""></div>
                                  <div class="pug-picker-range-separator"><span aria-label="to"
                                                                                class="pug-picker-separator"><span
                                    role="img" aria-label="swap-right" class="anticon anticon-swap-right"><svg
                                    viewBox="0 0 1024 1024" focusable="false" data-icon="swap-right" width="1em"
                                    height="1em" fill="currentColor" aria-hidden="true"><path
                                    d="M873.1 596.2l-164-208A32 32 0 00684 376h-64.8c-6.7 0-10.4 7.7-6.3 13l144.3 183H152c-4.4 0-8 3.6-8 8v60c0 4.4 3.6 8 8 8h695.9c26.8 0 41.7-30.8 25.2-51.8z"></path></svg></span></span>
                                  </div>
                                  <div class="pug-picker-input pug-picker-input-active"><input placeholder="请选择"
                                                                                               size="12"
                                                                                               autocomplete="off"
                                                                                               value=""></div>
                                  <div class="pug-picker-active-bar"
                                       style="left: 269px; width: 237px; position: absolute;"></div>
                                  <span class="pug-picker-suffix"><span role="img" aria-label="calendar"
                                                                        class="anticon anticon-calendar"><svg
                                    viewBox="64 64 896 896" focusable="false" data-icon="calendar" width="1em"
                                    height="1em" fill="currentColor" aria-hidden="true"><path
                                    d="M880 184H712v-64c0-4.4-3.6-8-8-8h-56c-4.4 0-8 3.6-8 8v64H384v-64c0-4.4-3.6-8-8-8h-56c-4.4 0-8 3.6-8 8v64H144c-17.7 0-32 14.3-32 32v664c0 17.7 14.3 32 32 32h736c17.7 0 32-14.3 32-32V216c0-17.7-14.3-32-32-32zm-40 656H184V460h656v380zM184 392V256h128v48c0 4.4 3.6 8 8 8h56c4.4 0 8-3.6 8-8v-48h256v48c0 4.4 3.6 8 8 8h56c4.4 0 8-3.6 8-8v-48h128v136H184z"></path></svg></span></span>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="pug-col pug-col-sm-24 pug-col-md-24 pug-col-lg-10 pug-col-xl-8 pug-col-xl-offset-2"
                           style="padding-left: 8px; padding-right: 8px;">
                        <div class="pug-row pug-form-item" style="row-gap: 0px;">
                          <div class="pug-col pug-form-item-label"><label for="type" class="pug-form-item-required"
                                                                          title="仓库类型">仓库类型</label></div>
                          <div class="pug-col pug-form-item-control">
                            <div class="pug-form-item-control-input">
                              <div class="pug-form-item-control-input-content">
                                <div
                                  class="pug-select pug-pro-filed-search-select pug-select-single pug-select-allow-clear pug-select-show-arrow"
                                  style="min-width: 100px;">
                                  <div class="pug-select-selector"><span class="pug-select-selection-search"><input
                                    id="type" autocomplete="off" type="search" class="pug-select-selection-search-input"
                                    role="combobox" aria-haspopup="listbox" aria-owns="type_list"
                                    aria-autocomplete="list" aria-controls="type_list"
                                    aria-activedescendant="type_list_0" readonly="" unselectable="on" value=""
                                    style="opacity: 0;"></span><span
                                    class="pug-select-selection-placeholder">请选择仓库类型</span></div>
                                  <span class="pug-select-arrow" unselectable="on" aria-hidden="true"
                                        style="user-select: none;"><span role="img" aria-label="down"
                                                                         class="anticon anticon-down pug-select-suffix"><svg
                                    viewBox="64 64 896 896" focusable="false" data-icon="down" width="1em" height="1em"
                                    fill="currentColor" aria-hidden="true"><path
                                    d="M884 256h-75c-5.1 0-9.9 2.5-12.9 6.6L512 654.2 227.9 262.6c-3-4.1-7.8-6.6-12.9-6.6h-75c-6.5 0-10.3 7.4-6.5 12.7l352.6 486.1c12.8 17.6 39 17.6 51.7 0l352.6-486.1c3.9-5.3.1-12.7-6.4-12.7z"></path></svg></span></span>
                                </div>
                                <div class="pug-select-dropdown pug-select-dropdown-placement-bottomLeft  pug-select-dropdown-hidden" style="min-width: 548px; width: 548px; left: 0px; top: 32px;"><div><div role="listbox" id="approver_list" style="height: 0px; width: 0px; overflow: hidden;"><div aria-label="付晓晓" role="option" id="approver_list_0" aria-selected="false">xiao</div><div aria-label="周毛毛" role="option" id="approver_list_1" aria-selected="false">mao</div></div><div class="rc-virtual-list" style="position: relative;"><div class="rc-virtual-list-holder" style="max-height: 256px; overflow-y: hidden; overflow-anchor: none;"><div><div class="rc-virtual-list-holder-inner" style="display: flex; flex-direction: column;"><div label="付晓晓" data-item="[object Object]" aria-selected="false" class="pug-select-item pug-select-item-option pug-pro-filed-search-select-option  pug-select-item-option-active" title="付晓晓"><div class="pug-select-item-option-content">付晓晓</div><span class="pug-select-item-option-state" unselectable="on" aria-hidden="true" style="user-select: none;"></span></div><div label="周毛毛" data-item="[object Object]" aria-selected="false" class="pug-select-item pug-select-item-option pug-pro-filed-search-select-option " title="周毛毛"><div class="pug-select-item-option-content">周毛毛</div><span class="pug-select-item-option-state" unselectable="on" aria-hidden="true" style="user-select: none;"></span></div></div></div></div><div class="rc-virtual-list-scrollbar" style="width: 8px; top: 0px; bottom: 0px; right: 0px; position: absolute; display: none;"><div class="rc-virtual-list-scrollbar-thumb" style="width: 100%; height: 128px; top: 0px; left: 0px; position: absolute; background: rgba(0, 0, 0, 0.5); border-radius: 99px; cursor: pointer; user-select: none;"></div></div></div></div></div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="pug-card card___1dsH6">
                  <div class="pug-card-head">
                    <div class="pug-card-head-wrapper">
                      <div class="pug-card-head-title">任务管理</div>
                    </div>
                  </div>
                  <div class="pug-card-body">
                    <div class="pug-row" style="margin-left: -8px; margin-right: -8px; row-gap: 0px;">
                      <div class="pug-col pug-col-sm-24 pug-col-md-12 pug-col-lg-6"
                           style="padding-left: 8px; padding-right: 8px;">
                        <div class="pug-row pug-form-item" style="row-gap: 0px;">
                          <div class="pug-col pug-form-item-label"><label for="name2" class="pug-form-item-required"
                                                                          title="任务名">任务名</label></div>
                          <div class="pug-col pug-form-item-control">
                            <div class="pug-form-item-control-input">
                              <div class="pug-form-item-control-input-content"><span
                                class="pug-input-affix-wrapper"><input placeholder="请输入" id="name2" type="text"
                                                                       class="pug-input" value=""></span>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="pug-col pug-col-sm-24 pug-col-md-12 pug-col-lg-8 pug-col-xl-6 pug-col-xl-offset-2"
                           style="padding-left: 8px; padding-right: 8px;">
                        <div class="pug-row pug-form-item" style="row-gap: 0px;">
                          <div class="pug-col pug-form-item-label"><label for="url2" class="pug-form-item-required"
                                                                          title="任务描述">任务描述</label></div>
                          <div class="pug-col pug-form-item-control">
                            <div class="pug-form-item-control-input">
                              <div class="pug-form-item-control-input-content"><span
                                class="pug-input-affix-wrapper"><input placeholder="请输入" id="url2" type="text"
                                                                       class="pug-input" value=""></span>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="pug-col pug-col-sm-24 pug-col-md-24 pug-col-lg-10 pug-col-xl-8 pug-col-xl-offset-2"
                           style="padding-left: 8px; padding-right: 8px;">
                        <div class="pug-row pug-form-item" style="row-gap: 0px;">
                          <div class="pug-col pug-form-item-label"><label for="owner2" class="pug-form-item-required"
                                                                          title="执行人">执行人</label></div>
                          <div class="pug-col pug-form-item-control">
                            <div class="pug-form-item-control-input">
                              <div class="pug-form-item-control-input-content">
                                <div
                                  class="pug-select pug-pro-filed-search-select pug-select-single pug-select-allow-clear pug-select-show-arrow"
                                  style="min-width: 100px;">
                                  <div class="pug-select-selector"><span class="pug-select-selection-search"><input
                                    id="owner2" autocomplete="off" type="search"
                                    class="pug-select-selection-search-input" role="combobox" aria-haspopup="listbox"
                                    aria-owns="owner2_list" aria-autocomplete="list" aria-controls="owner2_list"
                                    aria-activedescendant="owner2_list_0" readonly="" unselectable="on" value=""
                                    style="opacity: 0;"></span><span class="pug-select-selection-placeholder">请选择</span>
                                  </div>
                                  <span class="pug-select-arrow" unselectable="on" aria-hidden="true"
                                        style="user-select: none;"><span role="img" aria-label="down"
                                                                         class="anticon anticon-down pug-select-suffix"><svg
                                    viewBox="64 64 896 896" focusable="false" data-icon="down" width="1em" height="1em"
                                    fill="currentColor" aria-hidden="true"><path
                                    d="M884 256h-75c-5.1 0-9.9 2.5-12.9 6.6L512 654.2 227.9 262.6c-3-4.1-7.8-6.6-12.9-6.6h-75c-6.5 0-10.3 7.4-6.5 12.7l352.6 486.1c12.8 17.6 39 17.6 51.7 0l352.6-486.1c3.9-5.3.1-12.7-6.4-12.7z"></path></svg></span></span>
                                </div>
                                <div class="pug-select-dropdown pug-select-dropdown-placement-bottomLeft" style="min-width: 548px; width: 548px; left: 0px; top: 32px;"><div><div role="listbox" id="approver_list" style="height: 0px; width: 0px; overflow: hidden;"><div aria-label="付晓晓" role="option" id="approver_list_0" aria-selected="false">xiao</div><div aria-label="周毛毛" role="option" id="approver_list_1" aria-selected="false">mao</div></div><div class="rc-virtual-list" style="position: relative;"><div class="rc-virtual-list-holder" style="max-height: 256px; overflow-y: hidden; overflow-anchor: none;"><div><div class="rc-virtual-list-holder-inner" style="display: flex; flex-direction: column;"><div label="付晓晓" data-item="[object Object]" aria-selected="false" class="pug-select-item pug-select-item-option pug-pro-filed-search-select-option  pug-select-item-option-active" title="付晓晓"><div class="pug-select-item-option-content">付晓晓</div><span class="pug-select-item-option-state" unselectable="on" aria-hidden="true" style="user-select: none;"></span></div><div label="周毛毛" data-item="[object Object]" aria-selected="false" class="pug-select-item pug-select-item-option pug-pro-filed-search-select-option " title="周毛毛"><div class="pug-select-item-option-content">周毛毛</div><span class="pug-select-item-option-state" unselectable="on" aria-hidden="true" style="user-select: none;"></span></div></div></div></div><div class="rc-virtual-list-scrollbar" style="width: 8px; top: 0px; bottom: 0px; right: 0px; position: absolute; display: none;"><div class="rc-virtual-list-scrollbar-thumb" style="width: 100%; height: 128px; top: 0px; left: 0px; position: absolute; background: rgba(0, 0, 0, 0.5); border-radius: 99px; cursor: pointer; user-select: none;"></div></div></div></div></div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="pug-row" style="margin-left: -8px; margin-right: -8px; row-gap: 0px;">
                      <div class="pug-col pug-col-sm-24 pug-col-md-12 pug-col-lg-6"
                           style="padding-left: 8px; padding-right: 8px;">
                        <div class="pug-row pug-form-item" style="row-gap: 0px;">
                          <div class="pug-col pug-form-item-label"><label for="approver2" class="pug-form-item-required"
                                                                          title="责任人">责任人</label></div>
                          <div class="pug-col pug-form-item-control">
                            <div class="pug-form-item-control-input">
                              <div class="pug-form-item-control-input-content">
                                <div
                                  class="pug-select pug-pro-filed-search-select pug-select-single pug-select-allow-clear pug-select-show-arrow"
                                  style="min-width: 100px;">
                                  <div class="pug-select-selector"><span class="pug-select-selection-search"><input
                                    id="approver2" autocomplete="off" type="search"
                                    class="pug-select-selection-search-input" role="combobox" aria-haspopup="listbox"
                                    aria-owns="approver2_list" aria-autocomplete="list" aria-controls="approver2_list" readonly="" unselectable="on" value=""
                                    style="opacity: 0;"></span><span
                                    class="pug-select-selection-placeholder">请选择审批员</span></div>
                                  <span class="pug-select-arrow" unselectable="on" aria-hidden="true"
                                        style="user-select: none;"><span role="img" aria-label="down"
                                                                         class="anticon anticon-down pug-select-suffix"><svg
                                    viewBox="64 64 896 896" focusable="false" data-icon="down" width="1em" height="1em"
                                    fill="currentColor" aria-hidden="true"><path
                                    d="M884 256h-75c-5.1 0-9.9 2.5-12.9 6.6L512 654.2 227.9 262.6c-3-4.1-7.8-6.6-12.9-6.6h-75c-6.5 0-10.3 7.4-6.5 12.7l352.6 486.1c12.8 17.6 39 17.6 51.7 0l352.6-486.1c3.9-5.3.1-12.7-6.4-12.7z"></path></svg></span></span>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="pug-col pug-col-sm-24 pug-col-md-12 pug-col-lg-8 pug-col-xl-6 pug-col-xl-offset-2"
                           style="padding-left: 8px; padding-right: 8px;">
                        <div class="pug-row pug-form-item" style="row-gap: 0px;">
                          <div class="pug-col pug-form-item-label"><label for="dateRange2"
                                                                          class="pug-form-item-required" title="生效日期">生效日期</label>
                          </div>
                          <div class="pug-col pug-form-item-control">
                            <div class="pug-form-item-control-input">
                              <div class="pug-form-item-control-input-content">
                                <div class="pug-picker" style="width: 100%;">
                                  <div class="pug-picker-input"><input id="dateRange2" readonly="" placeholder="提醒时间"
                                                                       title="" size="10" autocomplete="off"
                                                                       value=""><span class="pug-picker-suffix"><span
                                    role="img" aria-label="clock-circle" class="anticon anticon-clock-circle"><svg
                                    viewBox="64 64 896 896" focusable="false" data-icon="clock-circle" width="1em"
                                    height="1em" fill="currentColor" aria-hidden="true"><path
                                    d="M512 64C264.6 64 64 264.6 64 512s200.6 448 448 448 448-200.6 448-448S759.4 64 512 64zm0 820c-205.4 0-372-166.6-372-372s166.6-372 372-372 372 166.6 372 372-166.6 372-372 372z"></path><path
                                    d="M686.7 638.6L544.1 535.5V288c0-4.4-3.6-8-8-8H488c-4.4 0-8 3.6-8 8v275.4c0 2.6 1.2 5 3.3 6.5l165.4 120.6c3.6 2.6 8.6 1.8 11.2-1.7l28.6-39c2.6-3.7 1.8-8.7-1.8-11.2z"></path></svg></span></span>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="pug-col pug-col-sm-24 pug-col-md-24 pug-col-lg-10 pug-col-xl-8 pug-col-xl-offset-2"
                           style="padding-left: 8px; padding-right: 8px;">
                        <div class="pug-row pug-form-item" style="row-gap: 0px;">
                          <div class="pug-col pug-form-item-label"><label for="type2" class="pug-form-item-required"
                                                                          title="任务类型">任务类型</label></div>
                          <div class="pug-col pug-form-item-control">
                            <div class="pug-form-item-control-input">
                              <div class="pug-form-item-control-input-content">
                                <div
                                  class="pug-select pug-pro-filed-search-select pug-select-single pug-select-allow-clear pug-select-show-arrow"
                                  style="min-width: 100px;">
                                  <div class="pug-select-selector"><span class="pug-select-selection-search"><input
                                    id="type2" autocomplete="off" type="search"
                                    class="pug-select-selection-search-input" role="combobox" aria-haspopup="listbox"
                                    aria-owns="type2_list" aria-autocomplete="list" aria-controls="type2_list"
                                    readonly="" unselectable="on" value=""
                                    style="opacity: 0;"></span><span
                                    class="pug-select-selection-placeholder">请选择仓库类型</span></div>
                                  <span class="pug-select-arrow" unselectable="on" aria-hidden="true"
                                        style="user-select: none;"><span role="img" aria-label="down"
                                                                         class="anticon anticon-down pug-select-suffix"><svg
                                    viewBox="64 64 896 896" focusable="false" data-icon="down" width="1em" height="1em"
                                    fill="currentColor" aria-hidden="true"><path
                                    d="M884 256h-75c-5.1 0-9.9 2.5-12.9 6.6L512 654.2 227.9 262.6c-3-4.1-7.8-6.6-12.9-6.6h-75c-6.5 0-10.3 7.4-6.5 12.7l352.6 486.1c12.8 17.6 39 17.6 51.7 0l352.6-486.1c3.9-5.3.1-12.7-6.4-12.7z"></path></svg></span></span>
                                </div>
                                <div class="pug-select-dropdown pug-select-dropdown-placement-bottomLeft  pug-select-dropdown-hidden" style="min-width: 548px; width: 548px; left: 0px; top: 32px;"><div><div role="listbox" id="approver_list" style="height: 0px; width: 0px; overflow: hidden;"><div aria-label="付晓晓" role="option" id="approver_list_0" aria-selected="false">xiao</div><div aria-label="周毛毛" role="option" id="approver_list_1" aria-selected="false">mao</div></div><div class="rc-virtual-list" style="position: relative;"><div class="rc-virtual-list-holder" style="max-height: 256px; overflow-y: hidden; overflow-anchor: none;"><div><div class="rc-virtual-list-holder-inner" style="display: flex; flex-direction: column;"><div label="付晓晓" data-item="[object Object]" aria-selected="false" class="pug-select-item pug-select-item-option pug-pro-filed-search-select-option  pug-select-item-option-active" title="付晓晓"><div class="pug-select-item-option-content">付晓晓</div><span class="pug-select-item-option-state" unselectable="on" aria-hidden="true" style="user-select: none;"></span></div><div label="周毛毛" data-item="[object Object]" aria-selected="false" class="pug-select-item pug-select-item-option pug-pro-filed-search-select-option " title="周毛毛"><div class="pug-select-item-option-content">周毛毛</div><span class="pug-select-item-option-state" unselectable="on" aria-hidden="true" style="user-select: none;"></span></div></div></div></div><div class="rc-virtual-list-scrollbar" style="width: 8px; top: 0px; bottom: 0px; right: 0px; position: absolute; display: none;"><div class="rc-virtual-list-scrollbar-thumb" style="width: 100%; height: 128px; top: 0px; left: 0px; position: absolute; background: rgba(0, 0, 0, 0.5); border-radius: 99px; cursor: pointer; user-select: none;"></div></div></div></div></div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="pug-card">
                  <div class="pug-card-head">
                    <div class="pug-card-head-wrapper">
                      <div class="pug-card-head-title">成员管理</div>
                    </div>
                  </div>
                  <div class="pug-card-body">
                    <div class="pug-row pug-form-item" style="row-gap: 0px;">
                      <div class="pug-col pug-form-item-control">
                        <div class="pug-form-item-control-input">
                          <div class="pug-form-item-control-input-content">
                            <div class="pug-pro-table">
                              <div class="pug-card">
                                <div class="pug-card-body" style="padding-top: 0px;">
                                  <div class="pug-table-wrapper">
                                    <div class="pug-spin-nested-loading">
                                      <div class="pug-spin-container">
                                        <div class="pug-table pug-table-middle pug-table-layout-fixed" id="members">
                                          <div class="pug-table-container">
                                            <div class="pug-table-content">
                                              <table style="table-layout: fixed;">
                                                <colgroup>
                                                  <col style="width: 20%;">
                                                  <col style="width: 20%;">
                                                  <col style="width: 40%;">
                                                </colgroup>
                                                <thead class="pug-table-thead">
                                                <tr>
                                                  <th class="pug-table-cell">成员姓名</th>
                                                  <th class="pug-table-cell">工号</th>
                                                  <th class="pug-table-cell">所属部门</th>
                                                  <th class="pug-table-cell">操作</th>
                                                </tr>
                                                </thead>
                                                <tbody class="pug-table-tbody">
                                                <tr data-row-key="1" class="pug-table-row pug-table-row-level-0">
                                                  <td class="pug-table-cell">
                                                    <div class="pug-row pug-form-item pug-form-item-has-success"
                                                         style="margin: -5px 0px; row-gap: 0px;">
                                                      <div class="pug-col pug-form-item-control">
                                                        <div class="pug-form-item-control-input">
                                                          <div class="pug-form-item-control-input-content"><span
                                                            class="pug-input-affix-wrapper"><input placeholder="请输入"
                                                                                                   type="text"
                                                                                                   class="pug-input"
                                                                                                   value=""></span>
                                                          </div>
                                                        </div>
                                                      </div>
                                                    </div>
                                                  </td>
                                                  <td class="pug-table-cell">
                                                    <div class="pug-row pug-form-item"
                                                         style="margin: -5px 0px; row-gap: 0px;">
                                                      <div class="pug-col pug-form-item-control">
                                                        <div class="pug-form-item-control-input">
                                                          <div class="pug-form-item-control-input-content"><span
                                                            class="pug-input-affix-wrapper"><input placeholder="请输入"
                                                                                                   type="text"
                                                                                                   class="pug-input"
                                                                                                   value="00001"></span>
                                                          </div>
                                                        </div>
                                                      </div>
                                                    </div>
                                                  </td>
                                                  <td class="pug-table-cell">
                                                    <div class="pug-row pug-form-item"
                                                         style="margin: -5px 0px; row-gap: 0px;">
                                                      <div class="pug-col pug-form-item-control">
                                                        <div class="pug-form-item-control-input">
                                                          <div class="pug-form-item-control-input-content"><span
                                                            class="pug-input-affix-wrapper"><input placeholder="请输入"
                                                                                                   type="text"
                                                                                                   class="pug-input"
                                                                                                   value="New York No. 1 Lake Park"></span>
                                                          </div>
                                                        </div>
                                                      </div>
                                                    </div>
                                                  </td>
                                                  <td class="pug-table-cell">
                                                    <div class="pug-space pug-space-horizontal pug-space-align-center"
                                                         style="gap: 8px;">
                                                      <div class="pug-space-item" style=""><a>保存</a></div>
                                                      <div class="pug-space-item" style=""><a>删除</a></div>
                                                      <div class="pug-space-item"><a>取消</a></div>
                                                    </div>
                                                  </td>
                                                </tr>
                                                <tr data-row-key="2" class="pug-table-row pug-table-row-level-0">
                                                  <td class="pug-table-cell">Jim Green</td>
                                                  <td class="pug-table-cell">00002</td>
                                                  <td class="pug-table-cell">London No. 1 Lake Park</td>
                                                  <td class="pug-table-cell">
                                                    <div class="pug-space pug-space-horizontal pug-space-align-center"
                                                         style="gap: 16px;">
                                                      <div class="pug-space-item"><a>编辑</a></div>
                                                    </div>
                                                  </td>
                                                </tr>
                                                <tr data-row-key="3" class="pug-table-row pug-table-row-level-0">
                                                  <td class="pug-table-cell">Joe Black</td>
                                                  <td class="pug-table-cell">00003</td>
                                                  <td class="pug-table-cell">Sidney No. 1 Lake Park</td>
                                                  <td class="pug-table-cell">
                                                    <div class="pug-space pug-space-horizontal pug-space-align-center"
                                                         style="gap: 16px;">
                                                      <div class="pug-space-item"><a>编辑</a></div>
                                                    </div>
                                                  </td>
                                                </tr>
                                                </tbody>
                                              </table>
                                            </div>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                  <button type="button" class="pug-btn pug-btn-dashed"
                                          style="display: block; margin: 10px 0px; width: 100%;"><span role="img"
                                                                                                       aria-label="plus"
                                                                                                       class="anticon anticon-plus"><svg
                                    viewBox="64 64 896 896" focusable="false" data-icon="plus" width="1em" height="1em"
                                    fill="currentColor" aria-hidden="true"><path
                                    d="M482 152h60q8 0 8 8v704q0 8-8 8h-60q-8 0-8-8V160q0-8 8-8z"></path><path
                                    d="M176 474h672q8 0 8 8v60q0 8-8 8H176q-8 0-8-8v-60q0-8 8-8z"></path></svg></span><span>添加一行数据</span>
                                  </button>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div style="height: 48px; margin-top: 24px;"></div>
            </div>
          </div>
        </div>
      </div>
      <div class="pug-pro-footer-bar" style="width: calc(100% - 208px);">
        <div class="pug-pro-footer-bar-left"></div>
        <div class="pug-pro-footer-bar-right">
          <button type="button" class="pug-btn"><span>重 置</span></button>
          <button type="button" class="pug-btn pug-btn-primary"><span>提 交</span></button>
        </div>
      </div>
    </form>
  </main>
</template>

<script>
export default {
  name: "normal",
  data() {
    return {}
  },

  created() {

  },
  methods: {}
}
</script>

<style scoped>



</style>
