<template>
  <main class="pug-pro-basicLayout-content pug-pro-basicLayout-has-header">
    <div class="pug-pro-page-container">
      <div class="pug-pro-page-container-warp">
        <div class="pug-page-header has-breadcrumb">
          <div class="pug-page-header-heading">
            <div class="pug-page-header-heading-left"><span class="pug-page-header-heading-title"
                                                            title="弹出层">弹出层</span></div>
          </div>
          <div class="pug-page-header-content">
            <div class="pug-pro-page-container-detail">
              <div class="pug-pro-page-container-main">
                <div class="pug-pro-page-container-row">
                  <div class="pug-pro-page-container-content">高级表单常见于一次性输入和提交大批量数据的场景。</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="pug-pro-grid-content">
        <div class="pug-pro-grid-content-children">
          <div class="pug-pro-layout-watermark-wrapper" style="position: relative;">
            <div class="pug-pro-page-container-children-content">
              <div class="pug-card card___1dsH6">
                <button class="pug-btn pug-btn-primary" @click.prevent="opensuccess">正确</button>
                <button class="pug-btn pug-btn-loading" @click.prevent="openerror">错误</button>
                <button class="pug-btn pug-btn-dashed" @click.prevent="openwarn">警告</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </main>
</template>

<script>
import PugDialog from '@/plugins/PugDialog'

export default {
  name: "index",
  data() {
    return {}
  },

  created() {

  },
  methods: {
    opensuccess() {
      PugDialog.alert("提示", "这个是一个正确的消息...", {time: 3}).then(() => {
        alert("点击的是确定按钮")
      })
    },
    openerror() {
      PugDialog.confirm("提示", "这个是一个错误的消息...", {sureText: "登录"}).then(() => {
        alert("点击的是确定按钮")
      }).catch(() => {
        alert("点击的是关闭按钮")
      })
    },
    openwarn() {
      PugDialog.iframe("提示", "这个是一个警告的消息...")
    },
  }
}
</script>

<style scoped>

</style>
