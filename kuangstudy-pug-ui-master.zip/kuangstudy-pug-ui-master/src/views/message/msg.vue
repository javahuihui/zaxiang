<template>
  <main class="pug-pro-basicLayout-content pug-pro-basicLayout-has-header">
    <div class="pug-pro-page-container">
      <div class="pug-pro-page-container-warp">
        <div class="pug-page-header has-breadcrumb">
          <div class="pug-page-header-heading">
            <div class="pug-page-header-heading-left"><span class="pug-page-header-heading-title"
                                                            title="消息框">消息框</span></div>
          </div>
          <div class="pug-page-header-content">
            <div class="pug-pro-page-container-detail">
              <div class="pug-pro-page-container-main">
                <div class="pug-pro-page-container-row">
                  <div class="pug-pro-page-container-content">高级表单常见于一次性输入和提交大批量数据的场景。</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="pug-pro-grid-content">
        <div class="pug-pro-grid-content-children">
          <div class="pug-pro-layout-watermark-wrapper" style="position: relative;">
            <div class="pug-pro-page-container-children-content">
              <div class="pug-card card___1dsH6">
                <button class="pug-btn pug-btn-primary" @click.prevent="opensuccess">正确</button>
                <button class="pug-btn pug-btn-loading" @click.prevent="openerror">错误</button>
                <button class="pug-btn pug-btn-dashed" @click.prevent="openwarn">警告</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </main>
</template>

<script>
import pugMsg from '@/plugins/PugMessage'

export default {
  name: "index",
  data() {
    return {}
  },

  created() {

  },
  methods: {
    opensuccess() {
      pugMsg.success("这个是一个正确的消息...", 3)
    },
    openerror() {
      pugMsg.error("这个是一个错误的消息...", 3)
    },
    openwarn() {
      pugMsg.warn("这个是一个警告的消息...", 3)
    },
  }

}
</script>

<style scoped>

</style>
