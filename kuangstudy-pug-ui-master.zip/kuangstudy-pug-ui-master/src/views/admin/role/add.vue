<template>
  <main class="pug-pro-basicLayout-content pug-pro-basicLayout-has-header">
    <div class="pug-pro-page-container">
      <div class="pug-pro-page-container-warp">
        <div class="pug-page-header has-breadcrumb">
          <div class="pug-page-header-heading">
            <div class="pug-page-header-heading-left">
              <span class="pug-page-header-heading-title" title="分步表单">{{ opid ? '修改产品' : "添加产品" }}</span>
              编辑的id是:{{ opid }}
            </div>
          </div>
          <div class="pug-page-header-content">
            <div class="pug-pro-page-container-detail">
              <div class="pug-pro-page-container-main">
                <div class="pug-pro-page-container-row">
                  <div class="pug-pro-page-container-content">
                    角色管理页用于向用户收集或验证信息，分步角色管理常见于数据项较多的表单场景。
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="pug-pro-grid-content">
        <div class="pug-pro-grid-content-children">
          <div class="pug-pro-layout-watermark-wrapper" style="position: relative;">
            <div class="pug-pro-page-container-children-content">
              <div class="pug-card">
                <div class="pug-pro-steps-form-steps-container" style="max-width: 760px;padding: 20px 0">
                  <div class="pug-steps pug-steps-horizontal pug-steps-label-horizontal">
                    <div class="pug-steps-item" @click="next(1)"
                         :class="[currentStep>=1?'pug-steps-item-process pug-steps-item-active':'']">
                      <div class="pug-steps-item-container">
                        <div class="pug-steps-item-tail"></div>
                        <div class="pug-steps-item-icon"><span class="pug-steps-icon">1</span></div>
                        <div class="pug-steps-item-content">
                          <div class="pug-steps-item-title">基本信息</div>
                        </div>
                      </div>
                    </div>
                    <div class="pug-steps-item pug-steps-item-wait" @click="next(2)"
                         :class="[currentStep>=2?'pug-steps-item-process pug-steps-item-active':'']">
                      <div class="pug-steps-item-container">
                        <div class="pug-steps-item-tail"></div>
                        <div class="pug-steps-item-icon"><span class="pug-steps-icon">2</span></div>
                        <div class="pug-steps-item-content">
                          <div class="pug-steps-item-title">明细控制</div>
                        </div>
                      </div>
                    </div>
                    <div class="pug-steps-item pug-steps-item-wait" @click="next(3)"
                         :class="[currentStep>=3?'pug-steps-item-process pug-steps-item-active':'']">
                      <div class="pug-steps-item-container">
                        <div class="pug-steps-item-tail"></div>
                        <div class="pug-steps-item-icon"><span class="pug-steps-icon">3</span></div>
                        <div class="pug-steps-item-content">
                          <div class="pug-steps-item-title">价格控制</div>
                        </div>
                      </div>
                    </div>
                    <div class="pug-steps-item pug-steps-item-wait" @click="next(4)"
                         :class="[currentStep>=4?'pug-steps-item-process pug-steps-item-active':'']">
                      <div class="pug-steps-item-container">
                        <div class="pug-steps-item-tail"></div>
                        <div class="pug-steps-item-icon"><span class="pug-steps-icon">4</span></div>
                        <div class="pug-steps-item-content">
                          <div class="pug-steps-item-title">产品描述</div>
                        </div>
                      </div>
                    </div>
                    <div class="pug-steps-item pug-steps-item-wait" @click="next(5)"
                         :class="[currentStep>=5?'pug-steps-item-process pug-steps-item-active':'']">
                      <div class="pug-steps-item-container">
                        <div class="pug-steps-item-tail"></div>
                        <div class="pug-steps-item-icon"><span class="pug-steps-icon">5</span></div>
                        <div class="pug-steps-item-content">
                          <div class="pug-steps-item-title">发布完成</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div v-show="currentStep==1" class="pug-card mt20">
                <div class="pug-card-body">
                  <div class="pug-debug-result">{{role}}</div>
                  <div class="pug-row" style="justify-content: center">

                    <div class="pug-col pug-col-lg-8" style="padding:0 30px;">
                      <div autocomplete="off" class="pug-form pug-form-vertical pug-form-hide-required-mark">
                         <input type="hidden" v-model="role.id" cref="id"/>
                         <div class="pug-row pug-form-item" style="row-gap: 0px;">
                          <div class="pug-col pug-form-item-label">
                             <label class="pug-form-item-required" title="角色名字">角色名字
                                <span class='pug-valid-label'>(*必填)</span>
                             </label>
                          </div>
                          <div class="pug-col pug-form-item-control">
                            <div class="pug-form-item-control-input">
                             <div class="pug-form-item-control-input-content">
                                 <pug-input  placeholder="请输入角色名字" cref="name" maxlen="128"  v-model="role.name" type="text"></pug-input>
                            </div>
                            </div>
                          </div>
                        </div>
                         <div class="pug-row pug-form-item" style="row-gap: 0px;">
                          <div class="pug-col pug-form-item-label">
                             <label class="pug-form-item-required" title="角色代号">角色代号
                             </label>
                          </div>
                          <div class="pug-col pug-form-item-control">
                            <div class="pug-form-item-control-input">
                             <div class="pug-form-item-control-input-content">
                                 <pug-input  placeholder="请输入角色代号" cref="code" maxlen="32"  v-model="role.code" type="text"></pug-input>
                            </div>
                            </div>
                          </div>
                        </div>
                         <div class="pug-row pug-form-item" style="row-gap: 0px;">
                          <div class="pug-col pug-form-item-label">
                             <label class="pug-form-item-required" title="发布状态 1发布中 0未发布">发布状态 1发布中 0未发布
                             </label>
                          </div>
                          <div class="pug-col pug-form-item-control">
                            <div class="pug-form-item-control-input">
                             <div class="pug-form-item-control-input-content">
                              <pug-radio v-model="role.status" cref="status" :items='[{text:"是",value:1},{text:"否",value:0}]' :is-value="false"></pug-radio>
                            </div>
                            </div>
                          </div>
                        </div>
                         <div class="pug-row pug-form-item" style="row-gap: 0px;">
                          <div class="pug-col pug-form-item-label">
                             <label class="pug-form-item-required" title="删除状态 0未删除 1删除">删除状态 0未删除 1删除
                             </label>
                          </div>
                          <div class="pug-col pug-form-item-control">
                            <div class="pug-form-item-control-input">
                             <div class="pug-form-item-control-input-content">
                              <pug-radio v-model="role.isdelete" cref="isdelete" :items='[{text:"不删除",value:0},{text:"删除",value:1}]' :is-value="false"></pug-radio>
                            </div>
                            </div>
                          </div>
                        </div>
                        <!--保存和下一步按钮-->
                        <div class="pug-space pug-space-horizontal pug-space-align-center"
                             style="flex-wrap: wrap; gap: 8px;">
                          <div class="pug-space-item" style="">
                             <router-link to="/role"><button  class="pug-btn pug-btn-primary mr10"><span><i class="iconfont icon-icon_arrow_left pr3 fz13"></i>返回</span></button></router-link>
                             <button type="button" v-if="!role.id" class="pug-btn pug-btn-primary mr3" @click="saveorupdate()"><span><i class="iconfont icon-tianjia pr3"></i>保存</span></button>
                             <button type="button" v-if="role.id" class="pug-btn pug-btn-primary mr3" @click="saveorupdate()"><span><i class="iconfont icon-quanbudingdan pr3"></i>编辑</span></button>
                           </div>
                          <div class="pug-space-item" style="">
                            <button type="button" class="pug-btn" @click="next(2)"><span>下一步</span>
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
             <div v-show="currentStep==2" class="pug-card mt20">
              2
             </div>
             <div v-show="currentStep==3" class="pug-card mt20">
              3
             </div>
             <div v-show="currentStep==4" class="pug-card mt20">
              4
             </div>
             <div v-show="currentStep==5" class="pug-card mt20">
               5
             </div>
         </div>
       </div>
     </div>
   </div>
 </div>
</main>
</template>
<script>
import roleService from '@/services/role'
import pugDialog from "@/plugins/PugDialog";
import pugMessage from "@/plugins/PugMessage";
import {isEmpty,getById,isNotEmpty} from "@/utils/validate";
import cache from "@/utils/cache"
export default {
  name: "RoleAdd.vue",
  components: {},
  data() {
    return {
      opid: "",
      role:{
        id:"", // 主键
        name:"", // 角色名字
        code:"", // 角色代号
        status:1 , // 发布状态 1发布中 0未发布
        isdelete:0  // 删除状态 0未删除 1删除
      },

      currentStep: 1,
      steps: [1, 2, 3]
    }
  },

  created() {
    
    // 根据id角色管理明细
    if(!isEmpty(this.$route.params.id)){
      this.role.id = this.$route.params.id;
      this.opid = this.$route.params.id;
      // 加载明细
      this.getDetail();
    }else{
      if(isNotEmpty(cache.local.get("role_save"))) {
        this.role = cache.local.getJSON("role_save")
      }
    }
  },

   watch:{
      role:{
        deep:true,
        handler(val){
          cache.local.setJSON("role_save",val);
        }
      }
   },

  methods: {

    // 加载明细
    async getDetail(){
      try{
        const res = await  roleService.getRole(this.opid);
        this.role = res.data;
      }catch (err) {
        pugMessage.error("服务器异常,代号：1025");
      }
    },

    // 1: 保存方法
    async saveorupdate() {
        try{
            // 校验
            const vresult = await this.validator();
            if(!vresult){
                return;
            }

            pugDialog.confirm('提示',"你确定进行【"+(this.role.id?'更新':'保存')+"】吗？").then(async ()=>{
                // 执行服务器数据保存角色管理
                const res = await  roleService.saveUpdateRole(this.role);
                if(res.status == 200){
                    if(isEmpty(this.role.id)){
                        // 重置数据
                        this.reset();
                        cache.local.remove("role_save");
                        // 返回列表
                        pugMessage.success("添加成功");
                        this.$router.push("/role/list");
                    }else{
                        cache.local.remove("role_save");
                        // 返回列表
                        pugMessage.success("修改成功");
                        this.$router.push("/role/list");
                    }
                }
            })
        }catch(err){
            pugMessage.error("服务器异常,代号：1025");
        }
    },

    // 2: 校验
    async validator(){

        if(isEmpty(this.role.name)){
           pugMessage.error("请输入角色名字");
           getById('name').focus();
           return false;
        }

        if(isEmpty(this.role.code)){
           pugMessage.error("请输入角色代号");
           getById('code').focus();
           return false;
        }

        if(isEmpty(this.role.status)){
           pugMessage.error("请输入发布状态 1发布中 0未发布");
           getById('status').focus();
           return false;
        }

        if(isEmpty(this.role.isdelete)){
           pugMessage.error("请输入删除状态 0未删除 1删除");
           getById('isdelete').focus();
           return false;
        }

        return true;
    },

    // 3: 步骤分解
    prev(index) {
      this.currentStep = index;
    },

    next(index) {
      this.currentStep = index;
    },

    // 4: 文件上传回调
    uploadSuccess(response) {
      console.log("uploadSuccess:", response)
    },

    // 5: 重置数据
    reset(){
        this.role = {
         citems: [{text:"请选择",value:""}],
         id:"", // 主键
         name:"", // 角色名字
         code:"", // 角色代号
         status:"", // 发布状态 1发布中 0未发布
         isdelete:"" // 删除状态 0未删除 1删除
       }
    },


  }
}
</script>
<style scoped="">
</style>
