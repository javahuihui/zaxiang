<template>

</template>

<script>
// import xxx from '@/xxx/xxxx';
export default {
  name: "index",
  data() {
    return {}
  },

  created() {

  },
  methods: {}

}
</script>

<style scoped>

</style>
