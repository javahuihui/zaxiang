<template>
  <div class="page light">
    <div class="page-main-no2">
      <div class="ksd-xqui-body">
        <div class="xquimini-content-page" style="height: calc(100% - 36px)">
          <div class="xquimini-container xquimini-page-anim">
            <div class="xquimini-main">
              <fieldset class="table-search-fieldset">
                <legend>搜索信息</legend>
                <div style="margin: 10px 10px 10px 10px;clear: both">
                  <form action="" class="xqui-form xqui-form-pane">
                    <div class="xqui-form-item">
                      <div class="xqui-inline"><label class="xqui-form-label">关键词</label>
                        <div class="xqui-input-inline"><input autocomplete="off" class="xqui-input" type="text"
                                                              v-model.lazy.trim="conditionVal"></div>
                      </div>
                      <div class="xqui-inline">
                        <button @click.prevent="findUserList" class="xqui-btn xqui-btn-primary"
                                lay-filter="data-search-btn" lay-submit="" type="submit">搜 索
                        </button>
                        <router-link to="/book/add">
                        <button class="xqui-btn xqui-btn-primary"
                                lay-filter="data-search-btn" lay-submit="" type="submit">添 加
                        </button></router-link>
                      </div>
                      <div style="float: right;font-weight: bold ;font-size: 12px;position: relative;top:10px;"> 一共有{{ total || 0 }}位同学加入了我们!</div>
                    </div>
                  </form>
                </div>
              </fieldset>
              <div class="xqui-form xqui-border-box xqui-table-view" lay-filter="LAY-table-1" lay-id="currentTableId"
                   style=" ">
                <div class="pug-pro-table">
                  <div class="pug-card">
                    <div class="pug-card-body" style="padding-top: 0px;">
                      <div class="pug-table-wrapper">
                        <div class="pug-spin-nested-loading">
                          <div class="pug-spin-container">
                            <div class="pug-table pug-table-middle pug-table-layout-fixed" id="members">
                              <div class="pug-table-container">
                                <div class="pug-table-content">
                                  <table style="table-layout: fixed;">
                                    <colgroup>
                                      <col style="width: 20%;">
                                      <col style="width: 20%;">
                                      <col style="width: 40%;">
                                    </colgroup>
                                    <thead class="pug-table-thead">
                                    <tr>
                                      <th class="pug-table-cell">成员姓名</th>
                                      <th class="pug-table-cell">工号</th>
                                      <th class="pug-table-cell">所属部门</th>
                                      <th class="pug-table-cell">操作</th>
                                    </tr>
                                    </thead>
                                    <tbody class="pug-table-tbody">
                                    <tr data-row-key="1" class="pug-table-row pug-table-row-level-0">
                                      <td class="pug-table-cell">
                                        <div class="pug-row pug-form-item pug-form-item-has-success"
                                             style="margin: -5px 0px; row-gap: 0px;">
                                          <div class="pug-col pug-form-item-control">
                                            <div class="pug-form-item-control-input">
                                              <div class="pug-form-item-control-input-content"><span
                                                class="pug-input-affix-wrapper"><input placeholder="请输入"
                                                                                       type="text"
                                                                                       class="pug-input"
                                                                                       value=""></span>
                                              </div>
                                            </div>
                                          </div>
                                        </div>
                                      </td>
                                      <td class="pug-table-cell">
                                        <div class="pug-row pug-form-item"
                                             style="margin: -5px 0px; row-gap: 0px;">
                                          <div class="pug-col pug-form-item-control">
                                            <div class="pug-form-item-control-input">
                                              <div class="pug-form-item-control-input-content"><span
                                                class="pug-input-affix-wrapper"><input placeholder="请输入"
                                                                                       type="text"
                                                                                       class="pug-input"
                                                                                       value="00001"></span>
                                              </div>
                                            </div>
                                          </div>
                                        </div>
                                      </td>
                                      <td class="pug-table-cell">
                                        <div class="pug-row pug-form-item"
                                             style="margin: -5px 0px; row-gap: 0px;">
                                          <div class="pug-col pug-form-item-control">
                                            <div class="pug-form-item-control-input">
                                              <div class="pug-form-item-control-input-content"><span
                                                class="pug-input-affix-wrapper"><input placeholder="请输入"
                                                                                       type="text"
                                                                                       class="pug-input"
                                                                                       value="New York No. 1 Lake Park"></span>
                                              </div>
                                            </div>
                                          </div>
                                        </div>
                                      </td>
                                      <td class="pug-table-cell">
                                        <div class="pug-space pug-space-horizontal pug-space-align-center"
                                             style="gap: 8px;">
                                          <div class="pug-space-item" style=""><a>保存</a></div>
                                          <div class="pug-space-item" style=""><a>删除</a></div>
                                          <div class="pug-space-item"><a>取消</a></div>
                                        </div>
                                      </td>
                                    </tr>
                                    <tr data-row-key="2" class="pug-table-row pug-table-row-level-0">
                                      <td class="pug-table-cell">Jim Green</td>
                                      <td class="pug-table-cell">00002</td>
                                      <td class="pug-table-cell">London No. 1 Lake Park</td>
                                      <td class="pug-table-cell">
                                        <div class="pug-space pug-space-horizontal pug-space-align-center"
                                             style="gap: 16px;">
                                          <div class="pug-space-item"><a>编辑</a></div>
                                        </div>
                                      </td>
                                    </tr>
                                    <tr data-row-key="3" class="pug-table-row pug-table-row-level-0">
                                      <td class="pug-table-cell">Joe Black</td>
                                      <td class="pug-table-cell">00003</td>
                                      <td class="pug-table-cell">Sidney No. 1 Lake Park</td>
                                      <td class="pug-table-cell">
                                        <div class="pug-space pug-space-horizontal pug-space-align-center"
                                             style="gap: 16px;">
                                          <div class="pug-space-item"><a>编辑</a></div>
                                        </div>
                                      </td>
                                    </tr>
                                    </tbody>
                                  </table>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <button type="button" class="pug-btn pug-btn-dashed"
                              style="display: block; margin: 10px 0px; width: 100%;"><span role="img"
                                                                                           aria-label="plus"
                                                                                           class="anticon anticon-plus"><svg
                        viewBox="64 64 896 896" focusable="false" data-icon="plus" width="1em" height="1em"
                        fill="currentColor" aria-hidden="true"><path
                        d="M482 152h60q8 0 8 8v704q0 8-8 8h-60q-8 0-8-8V160q0-8 8-8z"></path><path
                        d="M176 474h672q8 0 8 8v60q0 8-8 8H176q-8 0-8-8v-60q0-8 8-8z"></path></svg></span><span>添加一行数据</span>
                      </button>
                    </div>
                  </div>
                </div>
                <div class="xqui-table-page">
                  <pug-page
                      :page-index="currentPage"
                      :total="count"
                      :page-size="pageSize"
                      @change="pageChange">
                  </pug-page>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>

import PugPage from '@/components/page/PugPage'

export default {
  name: "Course.vue",
  components: {
    PugPage
  },
  data() {
    return {
      pageSize: 20, //每页显示20条数据
      currentPage: 1, //当前页码
      count: 100, //总记录数
      items: [
        {code:1,name:" 编程到底该如何学习？",nickname:"xxxxx",sex:1},
        {code:2,name:"学习编程之前你要了解的知识！",nickname:"xxxxx",sex:1},
        {code:3,name:"工欲善其事，必先利其器！",nickname:"xxxxx",sex:1},
        {code:4,name:"基础决定你未来的高度！",nickname:"xxxxx",sex:1},
        {code:5,name:"程序的本质就是这些！",nickname:"xxxxx",sex:1},
        {code:6,name:"利用集合高效解决问题！",nickname:"xxxxx",sex:1},
        {code:7,name:"从零开始开发游戏！",nickname:"xxxxx",sex:1},
        {code:8,name:"日常开发必备知识！",nickname:"xxxxx",sex:1},
        {code:9,name:"最简单的数据结构！",nickname:"xxxxx",sex:1},
        {code:10,name:"Java进阶必会技能！",nickname:"xxxxx",sex:1},
      ]
    }
  },
  methods: {
    //获取数据
    getList() {

    },

    //从page组件传递过来的当前page
    pageChange(page) {
      this.currentPage = page
    }
  },
  mounted() {
    //请求第一页数据
    this.getList()
  }
}
</script>

<style scoped>


</style>
