<template>
  <div class="page light">
    <main class=" pug-pro-basicLayout-content pug-pro-basicLayout-has-header">
      <div class="pug-pro-page-container">
        <div class="pug-pro-page-container-warp">
          <div class="pug-page-header has-breadcrumb has-footer">
            <div class="pug-page-header-heading">
              <div class="pug-page-header-heading-left"><span class="pug-page-header-heading-title"
                                                              title="搜索列表（文章）">搜索列表（文章）</span></div>
            </div>
            <div class="pug-page-header-footer">
              <div class="pug-tabs pug-tabs-top pug-pro-page-container-tabs">
                <div role="tablist" class="pug-tabs-nav">
                  <div class="pug-tabs-nav-wrap">
                    <div class="pug-tabs-nav-list" style="transform: translate(0px, 0px);">
                      <div class="pug-tabs-tab pug-tabs-tab-active">
                        <div role="tab" aria-selected="true" class="pug-tabs-tab-btn" tabindex="0"
                             id="rc-tabs-3-tab-articles" aria-controls="rc-tabs-3-panel-articles">文章
                        </div>
                      </div>
                      <div class="pug-tabs-tab">
                        <div role="tab" aria-selected="false" class="pug-tabs-tab-btn" tabindex="0"
                             id="rc-tabs-3-tab-projects" aria-controls="rc-tabs-3-panel-projects">项目
                        </div>
                      </div>
                      <div class="pug-tabs-tab">
                        <div role="tab" aria-selected="false" class="pug-tabs-tab-btn" tabindex="0"
                             id="rc-tabs-3-tab-applications" aria-controls="rc-tabs-3-panel-applications">应用
                        </div>
                      </div>
                      <div class="pug-tabs-ink-bar pug-tabs-ink-bar-animated"
                           style="left: 0px; width: 32px;"></div>
                    </div>
                    <div style="font-weight: bold ;font-size: 12px;position: absolute;right:0;top:10px;"> 共有 {{ total || 0 }} 条记录</div>
                  </div>
                  <div class="pug-tabs-nav-operations pug-tabs-nav-operations-hidden">
                    <button type="button" class="pug-tabs-nav-more" tabindex="-1" aria-hidden="true"
                            aria-haspopup="listbox" aria-controls="rc-tabs-3-more-popup" id="rc-tabs-3-more"
                            aria-expanded="false" style="visibility: hidden; order: 1;"><span role="img"
                                                                                              aria-label="ellipsis"
                                                                                              class="anticon anticon-ellipsis"><svg
                      viewBox="64 64 896 896" focusable="false" data-icon="ellipsis" width="1em"
                      height="1em" fill="currentColor" aria-hidden="true"><path
                      d="M176 511a56 56 0 10112 0 56 56 0 10-112 0zm280 0a56 56 0 10112 0 56 56 0 10-112 0zm280 0a56 56 0 10112 0 56 56 0 10-112 0z"></path></svg></span>
                    </button>
                  </div>
                </div>
                <div class="pug-tabs-content-holder">
                  <div class="pug-tabs-content pug-tabs-content-top">
                    <div role="tabpanel" tabindex="0" aria-hidden="false"
                         class="pug-tabs-tabpane pug-tabs-tabpane-active" id="rc-tabs-3-panel-articles"
                         aria-labelledby="rc-tabs-3-tab-articles"></div>
                    <div role="tabpanel" tabindex="-1" aria-hidden="true" class="pug-tabs-tabpane"
                         id="rc-tabs-3-panel-projects" aria-labelledby="rc-tabs-3-tab-projects"
                         style="display: none;"></div>
                    <div role="tabpanel" tabindex="-1" aria-hidden="true" class="pug-tabs-tabpane"
                         id="rc-tabs-3-panel-applications" aria-labelledby="rc-tabs-3-tab-applications"
                         style="display: none;"></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="pug-pro-grid-content">
          <div class="pug-pro-grid-content-children">
            <div class="pug-pro-layout-watermark-wrapper" style="position: relative;">
              <div class="pug-pro-page-container-children-content">
                <div class="pug-card">
                  <div class="pug-card-body">
                    <form class="pug-form pug-form-inline">
                      <div class="standardFormRow___2SuxW standardFormRowBlock___25ip_"
                           style="padding-bottom: 11px;">
                        <div class="label___2igWv"><span>所属类目</span></div>
                        <div class="content___v8hLk">
                          <div class="pug-row pug-form-item" style="row-gap: 0px;">
                            <div class="pug-col pug-form-item-control">
                              <div class="pug-form-item-control-input">
                                <div class="pug-form-item-control-input-content">
                                  <div class="tagSelect___lC4Pt hasExpandTag___2bftZ"><span
                                    class="pug-tag pug-tag-checkable">全部</span><span
                                    class="pug-tag pug-tag-checkable">类目一</span><span
                                    class="pug-tag pug-tag-checkable">类目二</span><span
                                    class="pug-tag pug-tag-checkable">类目三</span><span
                                    class="pug-tag pug-tag-checkable">类目四</span><span
                                    class="pug-tag pug-tag-checkable">类目五</span><span
                                    class="pug-tag pug-tag-checkable">类目六</span><span
                                    class="pug-tag pug-tag-checkable">类目七</span><span
                                    class="pug-tag pug-tag-checkable">类目八</span><span
                                    class="pug-tag pug-tag-checkable">类目九</span><span
                                    class="pug-tag pug-tag-checkable">类目十</span><span
                                    class="pug-tag pug-tag-checkable">类目十一</span><span
                                    class="pug-tag pug-tag-checkable">类目十二</span>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div
                        class="standardFormRow___2SuxW standardFormRowLast___3ZKmo standardFormRowGrid___TWpoF">
                        <div class="content___v8hLk">
                          <div class="pug-row" style="margin-left: -8px; margin-right: -8px; row-gap: 0px;">
                            <div
                              class="pug-col pug-col-xs-24 pug-col-sm-24 pug-col-md-12 pug-col-lg-10 pug-col-xl-10"
                              style="padding-left: 8px; padding-right: 8px;">
                              <div class="xqui-inline"><label class="xqui-form-label">关键词</label>
                                <div class="xqui-input-inline"><input autocomplete="off" class="xqui-input" type="text"
                                                                      v-model.lazy.trim="conditionVal"></div>
                              </div>
                              <div class="xqui-inline">
                                <button @click.prevent="findUserList" class="xqui-btn xqui-btn-primary"
                                        lay-filter="data-search-btn" lay-submit="" type="submit">搜 索
                                </button>
                                <router-link to="/book/add">
                                  <button class="xqui-btn xqui-btn-primary"
                                          lay-filter="data-search-btn" lay-submit="" type="submit">添 加
                                  </button></router-link>
                              </div>
                            </div>
                            <div
                              class="pug-col pug-col-xs-24 pug-col-sm-24 pug-col-md-12 pug-col-lg-10 pug-col-xl-10"
                              style="padding-left: 8px; padding-right: 8px;">
                              <div class="pug-row pug-form-item" style="row-gap: 0px;">
                                <div class="pug-col pug-form-item-label"><label for="user" class=""
                                                                                title="活跃用户">活跃用户</label>
                                </div>
                                <div
                                  class="pug-col pug-form-item-control pug-col-xs-24 pug-col-sm-24 pug-col-md-12">
                                  <div class="pug-form-item-control-input">
                                    <div class="pug-form-item-control-input-content">
                                      <div class="pug-select pug-select-single pug-select-show-arrow"
                                           style="max-width: 200px; width: 100%;">
                                        <div class="pug-select-selector"><span
                                          class="pug-select-selection-search"><input id="user"
                                                                                     autocomplete="off"
                                                                                     type="search"
                                                                                     class="pug-select-selection-search-input"
                                                                                     role="combobox"
                                                                                     aria-haspopup="listbox"
                                                                                     aria-owns="user_list"
                                                                                     aria-autocomplete="list"
                                                                                     aria-controls="user_list"
                                                                                     aria-activedescendant="user_list_0"
                                                                                     readonly=""
                                                                                     unselectable="on"
                                                                                     value=""
                                                                                     style="opacity: 0;"></span><span
                                          class="pug-select-selection-placeholder">不限</span></div>
                                        <span class="pug-select-arrow" unselectable="on" aria-hidden="true"
                                              style="user-select: none;"><span role="img" aria-label="down"
                                                                               class="anticon anticon-down pug-select-suffix"><svg
                                          viewBox="64 64 896 896" focusable="false" data-icon="down"
                                          width="1em" height="1em" fill="currentColor" aria-hidden="true"><path
                                          d="M884 256h-75c-5.1 0-9.9 2.5-12.9 6.6L512 654.2 227.9 262.6c-3-4.1-7.8-6.6-12.9-6.6h-75c-6.5 0-10.3 7.4-6.5 12.7l352.6 486.1c12.8 17.6 39 17.6 51.7 0l352.6-486.1c3.9-5.3.1-12.7-6.4-12.7z"></path></svg></span></span>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div
                              class="pug-col pug-col-xs-24 pug-col-sm-24 pug-col-md-12 pug-col-lg-10 pug-col-xl-10"
                              style="padding-left: 8px; padding-right: 8px;">
                              <div class="pug-row pug-form-item" style="row-gap: 0px;">
                                <div class="pug-col pug-form-item-label"><label for="rate" class=""
                                                                                title="好评度">好评度</label>
                                </div>
                                <div
                                  class="pug-col pug-form-item-control pug-col-xs-24 pug-col-sm-24 pug-col-md-12">
                                  <div class="pug-form-item-control-input">
                                    <div class="pug-form-item-control-input-content">
                                      <div class="pug-select pug-select-single pug-select-show-arrow"
                                           style="max-width: 200px; width: 100%;">
                                        <div class="pug-select-selector"><span
                                          class="pug-select-selection-search"><input id="rate"
                                                                                     autocomplete="off"
                                                                                     type="search"
                                                                                     class="pug-select-selection-search-input"
                                                                                     role="combobox"
                                                                                     aria-haspopup="listbox"
                                                                                     aria-owns="rate_list"
                                                                                     aria-autocomplete="list"
                                                                                     aria-controls="rate_list"
                                                                                     aria-activedescendant="rate_list_0"
                                                                                     readonly=""
                                                                                     unselectable="on"
                                                                                     value=""
                                                                                     style="opacity: 0;"></span><span
                                          class="pug-select-selection-placeholder">不限</span></div>
                                        <span class="pug-select-arrow" unselectable="on" aria-hidden="true"
                                              style="user-select: none;"><span role="img" aria-label="down"
                                                                               class="anticon anticon-down pug-select-suffix"><svg
                                          viewBox="64 64 896 896" focusable="false" data-icon="down"
                                          width="1em" height="1em" fill="currentColor" aria-hidden="true"><path
                                          d="M884 256h-75c-5.1 0-9.9 2.5-12.9 6.6L512 654.2 227.9 262.6c-3-4.1-7.8-6.6-12.9-6.6h-75c-6.5 0-10.3 7.4-6.5 12.7l352.6 486.1c12.8 17.6 39 17.6 51.7 0l352.6-486.1c3.9-5.3.1-12.7-6.4-12.7z"></path></svg></span></span>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
                <div class="pug-cardx" style="margin-top: 24px;">
                  <div class="pug-card-bodyx" >
                    <div
                      class="pug-list pug-list-vertical pug-list-lg pug-list-split pug-list-something-after-last-item">
                      <div class="pug-spin-nested-loading">
                        <div class="pug-spin-container">
                          <ul class="pug-list-items">
                            <li class="pug-list-item">
                              <div class="pug-list-item-main">
                                <div class="pug-list-item-meta">
                                  <div class="pug-list-item-meta-content"><h4
                                    class="pug-list-item-meta-title"><a class="listItemMetaTitle___2wEk5"
                                                                        href="https://ant.design">Alipay</a>
                                  </h4>
                                    <div class="pug-list-item-meta-description"><span><span class="pug-tag">Ant Design</span><span
                                      class="pug-tag">设计语言</span><span class="pug-tag">蚂蚁金服</span></span>
                                    </div>
                                  </div>
                                </div>
                                <div class="listContent___3B5zt">
                                  <div class="imgbox">
                                    <img src="https://gw.alipayobjects.com/zos/rmsportal/uMfMFlvUuceEyPpotzlq.png" alt="">
                                  </div>
                                  <div class="description___3xHdH">段落示意：蚂蚁金服设计平台
                                    ant.design，用最小的工作量，无缝接入蚂蚁金服生态，提供跨越设计与开发的体验解决方案。蚂蚁金服设计平台
                                    ant.design，用最小的工作量，无缝接入蚂蚁金服生态，提供跨越设计与开发的体验解决方案。

                                  <div class="extra___3DATl"><span
                                    class="pug-avatar pug-avatar-sm pug-avatar-circle pug-avatar-image"><img
                                    src="https://gw.alipayobjects.com/zos/rmsportal/WdGqmHpayyMjiEhcKoVE.png"></span><a
                                    href="https://ant.design">付小小</a> 发布在 <a href="https://ant.design">https://ant.design</a><em>2022-02-09
                                    19:33</em></div>
                                  </div>
                                </div>
                                <ul class="pug-list-item-action">
                                  <li><span><span role="img" aria-label="star" class="anticon anticon-star"
                                                  style="margin-right: 8px;"><svg viewBox="64 64 896 896"
                                                                                  focusable="false"
                                                                                  data-icon="star"
                                                                                  width="1em" height="1em"
                                                                                  fill="currentColor"
                                                                                  aria-hidden="true"><path
                                    d="M908.1 353.1l-253.9-36.9L540.7 86.1c-3.1-6.3-8.2-11.4-14.5-14.5-15.8-7.8-35-1.3-42.9 14.5L369.8 316.2l-253.9 36.9c-7 1-13.4 4.3-18.3 9.3a32.05 32.05 0 00.6 45.3l183.7 179.1-43.4 252.9a31.95 31.95 0 0046.4 33.7L512 754l227.1 119.4c6.2 3.3 13.4 4.4 20.3 3.2 17.4-3 29.1-19.5 26.1-36.9l-43.4-252.9 183.7-179.1c5-4.9 8.3-11.3 9.3-18.3 2.7-17.5-9.5-33.7-27-36.3zM664.8 561.6l36.1 210.3L512 672.7 323.1 772l36.1-210.3-152.8-149L417.6 382 512 190.7 606.4 382l211.2 30.7-152.8 148.9z"></path></svg></span>156</span><em
                                    class="pug-list-item-action-split"></em></li>
                                  <li><span><span role="img" aria-label="like" class="anticon anticon-like"
                                                  style="margin-right: 8px;"><svg viewBox="64 64 896 896"
                                                                                  focusable="false"
                                                                                  data-icon="like"
                                                                                  width="1em" height="1em"
                                                                                  fill="currentColor"
                                                                                  aria-hidden="true"><path
                                    d="M885.9 533.7c16.8-22.2 26.1-49.4 26.1-77.7 0-44.9-25.1-87.4-65.5-111.1a67.67 67.67 0 00-34.3-9.3H572.4l6-122.9c1.4-29.7-9.1-57.9-29.5-79.4A106.62 106.62 0 00471 99.9c-52 0-98 35-111.8 85.1l-85.9 311H144c-17.7 0-32 14.3-32 32v364c0 17.7 14.3 32 32 32h601.3c9.2 0 18.2-1.8 26.5-5.4 47.6-20.3 78.3-66.8 78.3-118.4 0-12.6-1.8-25-5.4-37 16.8-22.2 26.1-49.4 26.1-77.7 0-12.6-1.8-25-5.4-37 16.8-22.2 26.1-49.4 26.1-77.7-.2-12.6-2-25.1-5.6-37.1zM184 852V568h81v284h-81zm636.4-353l-21.9 19 13.9 25.4a56.2 56.2 0 016.9 27.3c0 16.5-7.2 32.2-19.6 43l-21.9 19 13.9 25.4a56.2 56.2 0 016.9 27.3c0 16.5-7.2 32.2-19.6 43l-21.9 19 13.9 25.4a56.2 56.2 0 016.9 27.3c0 22.4-13.2 42.6-33.6 51.8H329V564.8l99.5-360.5a44.1 44.1 0 0142.2-32.3c7.6 0 15.1 2.2 21.1 6.7 9.9 7.4 15.2 18.6 14.6 30.5l-9.6 198.4h314.4C829 418.5 840 436.9 840 456c0 16.5-7.2 32.1-19.6 43z"></path></svg></span>126</span><em
                                    class="pug-list-item-action-split"></em></li>
                                  <li><span><span role="img" aria-label="message"
                                                  class="anticon anticon-message"
                                                  style="margin-right: 8px;"><svg viewBox="64 64 896 896"
                                                                                  focusable="false"
                                                                                  data-icon="message"
                                                                                  width="1em" height="1em"
                                                                                  fill="currentColor"
                                                                                  aria-hidden="true"><path
                                    d="M464 512a48 48 0 1096 0 48 48 0 10-96 0zm200 0a48 48 0 1096 0 48 48 0 10-96 0zm-400 0a48 48 0 1096 0 48 48 0 10-96 0zm661.2-173.6c-22.6-53.7-55-101.9-96.3-143.3a444.35 444.35 0 00-143.3-96.3C630.6 75.7 572.2 64 512 64h-2c-60.6.3-119.3 12.3-174.5 35.9a445.35 445.35 0 00-142 96.5c-40.9 41.3-73 89.3-95.2 142.8-23 55.4-34.6 114.3-34.3 174.9A449.4 449.4 0 00112 714v152a46 46 0 0046 46h152.1A449.4 449.4 0 00510 960h2.1c59.9 0 118-11.6 172.7-34.3a444.48 444.48 0 00142.8-95.2c41.3-40.9 73.8-88.7 96.5-142 23.6-55.2 35.6-113.9 35.9-174.5.3-60.9-11.5-120-34.8-175.6zm-151.1 438C704 845.8 611 884 512 884h-1.7c-60.3-.3-120.2-15.3-173.1-43.5l-8.4-4.5H188V695.2l-4.5-8.4C155.3 633.9 140.3 574 140 513.7c-.4-99.7 37.7-193.3 107.6-263.8 69.8-70.5 163.1-109.5 262.8-109.9h1.7c50 0 98.5 9.7 144.2 28.9 44.6 18.7 84.6 45.6 119 80 34.3 34.3 61.3 74.4 80 119 19.4 46.2 29.1 95.2 28.9 145.8-.6 99.6-39.7 192.9-110.1 262.7z"></path></svg></span>19</span>
                                  </li>
                                </ul>
                              </div>
                            </li>
                            <li class="pug-list-item">
                              <div class="pug-list-item-main">
                                <div class="pug-list-item-meta">
                                  <div class="pug-list-item-meta-content"><h4
                                    class="pug-list-item-meta-title"><a class="listItemMetaTitle___2wEk5"
                                                                        href="https://ant.design">Angular</a>
                                  </h4>
                                    <div class="pug-list-item-meta-description"><span><span class="pug-tag">Ant Design</span><span
                                      class="pug-tag">设计语言</span><span class="pug-tag">蚂蚁金服</span></span>
                                    </div>
                                  </div>
                                </div>
                                <div class="listContent___3B5zt">
                                  <div class="imgbox">
                                    <img src="https://gw.alipayobjects.com/zos/rmsportal/uMfMFlvUuceEyPpotzlq.png" alt="">
                                  </div>
                                  <div class="description___3xHdH">段落示意：蚂蚁金服设计平台
                                    ant.design，用最小的工作量，无缝接入蚂蚁金服生态，提供跨越设计与开发的体验解决方案。蚂蚁金服设计平台
                                    ant.design，用最小的工作量，无缝接入蚂蚁金服生态，提供跨越设计与开发的体验解决方案。

                                    <div class="extra___3DATl"><span
                                      class="pug-avatar pug-avatar-sm pug-avatar-circle pug-avatar-image"><img
                                      src="https://gw.alipayobjects.com/zos/rmsportal/WdGqmHpayyMjiEhcKoVE.png"></span><a
                                      href="https://ant.design">付小小</a> 发布在 <a href="https://ant.design">https://ant.design</a><em>2022-02-09
                                      19:33</em></div>
                                  </div>
                                </div>
                                <ul class="pug-list-item-action">
                                  <li><span><span role="img" aria-label="star" class="anticon anticon-star"
                                                  style="margin-right: 8px;"><svg viewBox="64 64 896 896"
                                                                                  focusable="false"
                                                                                  data-icon="star"
                                                                                  width="1em" height="1em"
                                                                                  fill="currentColor"
                                                                                  aria-hidden="true"><path
                                    d="M908.1 353.1l-253.9-36.9L540.7 86.1c-3.1-6.3-8.2-11.4-14.5-14.5-15.8-7.8-35-1.3-42.9 14.5L369.8 316.2l-253.9 36.9c-7 1-13.4 4.3-18.3 9.3a32.05 32.05 0 00.6 45.3l183.7 179.1-43.4 252.9a31.95 31.95 0 0046.4 33.7L512 754l227.1 119.4c6.2 3.3 13.4 4.4 20.3 3.2 17.4-3 29.1-19.5 26.1-36.9l-43.4-252.9 183.7-179.1c5-4.9 8.3-11.3 9.3-18.3 2.7-17.5-9.5-33.7-27-36.3zM664.8 561.6l36.1 210.3L512 672.7 323.1 772l36.1-210.3-152.8-149L417.6 382 512 190.7 606.4 382l211.2 30.7-152.8 148.9z"></path></svg></span>195</span><em
                                    class="pug-list-item-action-split"></em></li>
                                  <li><span><span role="img" aria-label="like" class="anticon anticon-like"
                                                  style="margin-right: 8px;"><svg viewBox="64 64 896 896"
                                                                                  focusable="false"
                                                                                  data-icon="like"
                                                                                  width="1em" height="1em"
                                                                                  fill="currentColor"
                                                                                  aria-hidden="true"><path
                                    d="M885.9 533.7c16.8-22.2 26.1-49.4 26.1-77.7 0-44.9-25.1-87.4-65.5-111.1a67.67 67.67 0 00-34.3-9.3H572.4l6-122.9c1.4-29.7-9.1-57.9-29.5-79.4A106.62 106.62 0 00471 99.9c-52 0-98 35-111.8 85.1l-85.9 311H144c-17.7 0-32 14.3-32 32v364c0 17.7 14.3 32 32 32h601.3c9.2 0 18.2-1.8 26.5-5.4 47.6-20.3 78.3-66.8 78.3-118.4 0-12.6-1.8-25-5.4-37 16.8-22.2 26.1-49.4 26.1-77.7 0-12.6-1.8-25-5.4-37 16.8-22.2 26.1-49.4 26.1-77.7-.2-12.6-2-25.1-5.6-37.1zM184 852V568h81v284h-81zm636.4-353l-21.9 19 13.9 25.4a56.2 56.2 0 016.9 27.3c0 16.5-7.2 32.2-19.6 43l-21.9 19 13.9 25.4a56.2 56.2 0 016.9 27.3c0 16.5-7.2 32.2-19.6 43l-21.9 19 13.9 25.4a56.2 56.2 0 016.9 27.3c0 22.4-13.2 42.6-33.6 51.8H329V564.8l99.5-360.5a44.1 44.1 0 0142.2-32.3c7.6 0 15.1 2.2 21.1 6.7 9.9 7.4 15.2 18.6 14.6 30.5l-9.6 198.4h314.4C829 418.5 840 436.9 840 456c0 16.5-7.2 32.1-19.6 43z"></path></svg></span>112</span><em
                                    class="pug-list-item-action-split"></em></li>
                                  <li><span><span role="img" aria-label="message"
                                                  class="anticon anticon-message"
                                                  style="margin-right: 8px;"><svg viewBox="64 64 896 896"
                                                                                  focusable="false"
                                                                                  data-icon="message"
                                                                                  width="1em" height="1em"
                                                                                  fill="currentColor"
                                                                                  aria-hidden="true"><path
                                    d="M464 512a48 48 0 1096 0 48 48 0 10-96 0zm200 0a48 48 0 1096 0 48 48 0 10-96 0zm-400 0a48 48 0 1096 0 48 48 0 10-96 0zm661.2-173.6c-22.6-53.7-55-101.9-96.3-143.3a444.35 444.35 0 00-143.3-96.3C630.6 75.7 572.2 64 512 64h-2c-60.6.3-119.3 12.3-174.5 35.9a445.35 445.35 0 00-142 96.5c-40.9 41.3-73 89.3-95.2 142.8-23 55.4-34.6 114.3-34.3 174.9A449.4 449.4 0 00112 714v152a46 46 0 0046 46h152.1A449.4 449.4 0 00510 960h2.1c59.9 0 118-11.6 172.7-34.3a444.48 444.48 0 00142.8-95.2c41.3-40.9 73.8-88.7 96.5-142 23.6-55.2 35.6-113.9 35.9-174.5.3-60.9-11.5-120-34.8-175.6zm-151.1 438C704 845.8 611 884 512 884h-1.7c-60.3-.3-120.2-15.3-173.1-43.5l-8.4-4.5H188V695.2l-4.5-8.4C155.3 633.9 140.3 574 140 513.7c-.4-99.7 37.7-193.3 107.6-263.8 69.8-70.5 163.1-109.5 262.8-109.9h1.7c50 0 98.5 9.7 144.2 28.9 44.6 18.7 84.6 45.6 119 80 34.3 34.3 61.3 74.4 80 119 19.4 46.2 29.1 95.2 28.9 145.8-.6 99.6-39.7 192.9-110.1 262.7z"></path></svg></span>11</span>
                                  </li>
                                </ul>
                              </div>
                            </li>
                            <li class="pug-list-item">
                              <div class="pug-list-item-main">
                                <div class="pug-list-item-meta">
                                  <div class="pug-list-item-meta-content"><h4
                                    class="pug-list-item-meta-title"><a class="listItemMetaTitle___2wEk5"
                                                                        href="https://ant.design">Ant
                                    Design</a></h4>
                                    <div class="pug-list-item-meta-description"><span><span class="pug-tag">Ant Design</span><span
                                      class="pug-tag">设计语言</span><span class="pug-tag">蚂蚁金服</span></span>
                                    </div>
                                  </div>
                                </div>
                                <div class="listContent___3B5zt">
                                  <div class="imgbox">
                                    <img src="https://gw.alipayobjects.com/zos/rmsportal/uMfMFlvUuceEyPpotzlq.png" alt="">
                                  </div>
                                  <div class="description___3xHdH">段落示意：蚂蚁金服设计平台
                                    ant.design，用最小的工作量，无缝接入蚂蚁金服生态，提供跨越设计与开发的体验解决方案。蚂蚁金服设计平台
                                    ant.design，用最小的工作量，无缝接入蚂蚁金服生态，提供跨越设计与开发的体验解决方案。

                                    <div class="extra___3DATl"><span
                                      class="pug-avatar pug-avatar-sm pug-avatar-circle pug-avatar-image"><img
                                      src="https://gw.alipayobjects.com/zos/rmsportal/WdGqmHpayyMjiEhcKoVE.png"></span><a
                                      href="https://ant.design">付小小</a> 发布在 <a href="https://ant.design">https://ant.design</a><em>2022-02-09
                                      19:33</em></div>
                                  </div>
                                </div>
                                <ul class="pug-list-item-action">
                                  <li><span><span role="img" aria-label="star" class="anticon anticon-star"
                                                  style="margin-right: 8px;"><svg viewBox="64 64 896 896"
                                                                                  focusable="false"
                                                                                  data-icon="star"
                                                                                  width="1em" height="1em"
                                                                                  fill="currentColor"
                                                                                  aria-hidden="true"><path
                                    d="M908.1 353.1l-253.9-36.9L540.7 86.1c-3.1-6.3-8.2-11.4-14.5-14.5-15.8-7.8-35-1.3-42.9 14.5L369.8 316.2l-253.9 36.9c-7 1-13.4 4.3-18.3 9.3a32.05 32.05 0 00.6 45.3l183.7 179.1-43.4 252.9a31.95 31.95 0 0046.4 33.7L512 754l227.1 119.4c6.2 3.3 13.4 4.4 20.3 3.2 17.4-3 29.1-19.5 26.1-36.9l-43.4-252.9 183.7-179.1c5-4.9 8.3-11.3 9.3-18.3 2.7-17.5-9.5-33.7-27-36.3zM664.8 561.6l36.1 210.3L512 672.7 323.1 772l36.1-210.3-152.8-149L417.6 382 512 190.7 606.4 382l211.2 30.7-152.8 148.9z"></path></svg></span>162</span><em
                                    class="pug-list-item-action-split"></em></li>
                                  <li><span><span role="img" aria-label="like" class="anticon anticon-like"
                                                  style="margin-right: 8px;"><svg viewBox="64 64 896 896"
                                                                                  focusable="false"
                                                                                  data-icon="like"
                                                                                  width="1em" height="1em"
                                                                                  fill="currentColor"
                                                                                  aria-hidden="true"><path
                                    d="M885.9 533.7c16.8-22.2 26.1-49.4 26.1-77.7 0-44.9-25.1-87.4-65.5-111.1a67.67 67.67 0 00-34.3-9.3H572.4l6-122.9c1.4-29.7-9.1-57.9-29.5-79.4A106.62 106.62 0 00471 99.9c-52 0-98 35-111.8 85.1l-85.9 311H144c-17.7 0-32 14.3-32 32v364c0 17.7 14.3 32 32 32h601.3c9.2 0 18.2-1.8 26.5-5.4 47.6-20.3 78.3-66.8 78.3-118.4 0-12.6-1.8-25-5.4-37 16.8-22.2 26.1-49.4 26.1-77.7 0-12.6-1.8-25-5.4-37 16.8-22.2 26.1-49.4 26.1-77.7-.2-12.6-2-25.1-5.6-37.1zM184 852V568h81v284h-81zm636.4-353l-21.9 19 13.9 25.4a56.2 56.2 0 016.9 27.3c0 16.5-7.2 32.2-19.6 43l-21.9 19 13.9 25.4a56.2 56.2 0 016.9 27.3c0 16.5-7.2 32.2-19.6 43l-21.9 19 13.9 25.4a56.2 56.2 0 016.9 27.3c0 22.4-13.2 42.6-33.6 51.8H329V564.8l99.5-360.5a44.1 44.1 0 0142.2-32.3c7.6 0 15.1 2.2 21.1 6.7 9.9 7.4 15.2 18.6 14.6 30.5l-9.6 198.4h314.4C829 418.5 840 436.9 840 456c0 16.5-7.2 32.1-19.6 43z"></path></svg></span>136</span><em
                                    class="pug-list-item-action-split"></em></li>
                                  <li><span><span role="img" aria-label="message"
                                                  class="anticon anticon-message"
                                                  style="margin-right: 8px;"><svg viewBox="64 64 896 896"
                                                                                  focusable="false"
                                                                                  data-icon="message"
                                                                                  width="1em" height="1em"
                                                                                  fill="currentColor"
                                                                                  aria-hidden="true"><path
                                    d="M464 512a48 48 0 1096 0 48 48 0 10-96 0zm200 0a48 48 0 1096 0 48 48 0 10-96 0zm-400 0a48 48 0 1096 0 48 48 0 10-96 0zm661.2-173.6c-22.6-53.7-55-101.9-96.3-143.3a444.35 444.35 0 00-143.3-96.3C630.6 75.7 572.2 64 512 64h-2c-60.6.3-119.3 12.3-174.5 35.9a445.35 445.35 0 00-142 96.5c-40.9 41.3-73 89.3-95.2 142.8-23 55.4-34.6 114.3-34.3 174.9A449.4 449.4 0 00112 714v152a46 46 0 0046 46h152.1A449.4 449.4 0 00510 960h2.1c59.9 0 118-11.6 172.7-34.3a444.48 444.48 0 00142.8-95.2c41.3-40.9 73.8-88.7 96.5-142 23.6-55.2 35.6-113.9 35.9-174.5.3-60.9-11.5-120-34.8-175.6zm-151.1 438C704 845.8 611 884 512 884h-1.7c-60.3-.3-120.2-15.3-173.1-43.5l-8.4-4.5H188V695.2l-4.5-8.4C155.3 633.9 140.3 574 140 513.7c-.4-99.7 37.7-193.3 107.6-263.8 69.8-70.5 163.1-109.5 262.8-109.9h1.7c50 0 98.5 9.7 144.2 28.9 44.6 18.7 84.6 45.6 119 80 34.3 34.3 61.3 74.4 80 119 19.4 46.2 29.1 95.2 28.9 145.8-.6 99.6-39.7 192.9-110.1 262.7z"></path></svg></span>19</span>
                                  </li>
                                </ul>
                              </div>
                            </li>
                            <li class="pug-list-item">
                              <div class="pug-list-item-main">
                                <div class="pug-list-item-meta">
                                  <div class="pug-list-item-meta-content"><h4
                                    class="pug-list-item-meta-title"><a class="listItemMetaTitle___2wEk5"
                                                                        href="https://ant.design">Ant Design
                                    Pro</a></h4>
                                    <div class="pug-list-item-meta-description"><span><span class="pug-tag">Ant Design</span><span
                                      class="pug-tag">设计语言</span><span class="pug-tag">蚂蚁金服</span></span>
                                    </div>
                                  </div>
                                </div>
                                <div class="listContent___3B5zt">
                                  <div class="imgbox">
                                    <img src="https://gw.alipayobjects.com/zos/rmsportal/uMfMFlvUuceEyPpotzlq.png" alt="">
                                  </div>
                                  <div class="description___3xHdH">段落示意：蚂蚁金服设计平台
                                    ant.design，用最小的工作量，无缝接入蚂蚁金服生态，提供跨越设计与开发的体验解决方案。蚂蚁金服设计平台
                                    ant.design，用最小的工作量，无缝接入蚂蚁金服生态，提供跨越设计与开发的体验解决方案。

                                    <div class="extra___3DATl"><span
                                      class="pug-avatar pug-avatar-sm pug-avatar-circle pug-avatar-image"><img
                                      src="https://gw.alipayobjects.com/zos/rmsportal/WdGqmHpayyMjiEhcKoVE.png"></span><a
                                      href="https://ant.design">付小小</a> 发布在 <a href="https://ant.design">https://ant.design</a><em>2022-02-09
                                      19:33</em></div>
                                  </div>
                                </div>
                                <ul class="pug-list-item-action">
                                  <li><span><span role="img" aria-label="star" class="anticon anticon-star"
                                                  style="margin-right: 8px;"><svg viewBox="64 64 896 896"
                                                                                  focusable="false"
                                                                                  data-icon="star"
                                                                                  width="1em" height="1em"
                                                                                  fill="currentColor"
                                                                                  aria-hidden="true"><path
                                    d="M908.1 353.1l-253.9-36.9L540.7 86.1c-3.1-6.3-8.2-11.4-14.5-14.5-15.8-7.8-35-1.3-42.9 14.5L369.8 316.2l-253.9 36.9c-7 1-13.4 4.3-18.3 9.3a32.05 32.05 0 00.6 45.3l183.7 179.1-43.4 252.9a31.95 31.95 0 0046.4 33.7L512 754l227.1 119.4c6.2 3.3 13.4 4.4 20.3 3.2 17.4-3 29.1-19.5 26.1-36.9l-43.4-252.9 183.7-179.1c5-4.9 8.3-11.3 9.3-18.3 2.7-17.5-9.5-33.7-27-36.3zM664.8 561.6l36.1 210.3L512 672.7 323.1 772l36.1-210.3-152.8-149L417.6 382 512 190.7 606.4 382l211.2 30.7-152.8 148.9z"></path></svg></span>160</span><em
                                    class="pug-list-item-action-split"></em></li>
                                  <li><span><span role="img" aria-label="like" class="anticon anticon-like"
                                                  style="margin-right: 8px;"><svg viewBox="64 64 896 896"
                                                                                  focusable="false"
                                                                                  data-icon="like"
                                                                                  width="1em" height="1em"
                                                                                  fill="currentColor"
                                                                                  aria-hidden="true"><path
                                    d="M885.9 533.7c16.8-22.2 26.1-49.4 26.1-77.7 0-44.9-25.1-87.4-65.5-111.1a67.67 67.67 0 00-34.3-9.3H572.4l6-122.9c1.4-29.7-9.1-57.9-29.5-79.4A106.62 106.62 0 00471 99.9c-52 0-98 35-111.8 85.1l-85.9 311H144c-17.7 0-32 14.3-32 32v364c0 17.7 14.3 32 32 32h601.3c9.2 0 18.2-1.8 26.5-5.4 47.6-20.3 78.3-66.8 78.3-118.4 0-12.6-1.8-25-5.4-37 16.8-22.2 26.1-49.4 26.1-77.7 0-12.6-1.8-25-5.4-37 16.8-22.2 26.1-49.4 26.1-77.7-.2-12.6-2-25.1-5.6-37.1zM184 852V568h81v284h-81zm636.4-353l-21.9 19 13.9 25.4a56.2 56.2 0 016.9 27.3c0 16.5-7.2 32.2-19.6 43l-21.9 19 13.9 25.4a56.2 56.2 0 016.9 27.3c0 16.5-7.2 32.2-19.6 43l-21.9 19 13.9 25.4a56.2 56.2 0 016.9 27.3c0 22.4-13.2 42.6-33.6 51.8H329V564.8l99.5-360.5a44.1 44.1 0 0142.2-32.3c7.6 0 15.1 2.2 21.1 6.7 9.9 7.4 15.2 18.6 14.6 30.5l-9.6 198.4h314.4C829 418.5 840 436.9 840 456c0 16.5-7.2 32.1-19.6 43z"></path></svg></span>194</span><em
                                    class="pug-list-item-action-split"></em></li>
                                  <li><span><span role="img" aria-label="message"
                                                  class="anticon anticon-message"
                                                  style="margin-right: 8px;"><svg viewBox="64 64 896 896"
                                                                                  focusable="false"
                                                                                  data-icon="message"
                                                                                  width="1em" height="1em"
                                                                                  fill="currentColor"
                                                                                  aria-hidden="true"><path
                                    d="M464 512a48 48 0 1096 0 48 48 0 10-96 0zm200 0a48 48 0 1096 0 48 48 0 10-96 0zm-400 0a48 48 0 1096 0 48 48 0 10-96 0zm661.2-173.6c-22.6-53.7-55-101.9-96.3-143.3a444.35 444.35 0 00-143.3-96.3C630.6 75.7 572.2 64 512 64h-2c-60.6.3-119.3 12.3-174.5 35.9a445.35 445.35 0 00-142 96.5c-40.9 41.3-73 89.3-95.2 142.8-23 55.4-34.6 114.3-34.3 174.9A449.4 449.4 0 00112 714v152a46 46 0 0046 46h152.1A449.4 449.4 0 00510 960h2.1c59.9 0 118-11.6 172.7-34.3a444.48 444.48 0 00142.8-95.2c41.3-40.9 73.8-88.7 96.5-142 23.6-55.2 35.6-113.9 35.9-174.5.3-60.9-11.5-120-34.8-175.6zm-151.1 438C704 845.8 611 884 512 884h-1.7c-60.3-.3-120.2-15.3-173.1-43.5l-8.4-4.5H188V695.2l-4.5-8.4C155.3 633.9 140.3 574 140 513.7c-.4-99.7 37.7-193.3 107.6-263.8 69.8-70.5 163.1-109.5 262.8-109.9h1.7c50 0 98.5 9.7 144.2 28.9 44.6 18.7 84.6 45.6 119 80 34.3 34.3 61.3 74.4 80 119 19.4 46.2 29.1 95.2 28.9 145.8-.6 99.6-39.7 192.9-110.1 262.7z"></path></svg></span>14</span>
                                  </li>
                                </ul>
                              </div>
                            </li>
                            <li class="pug-list-item">
                              <div class="pug-list-item-main">
                                <div class="pug-list-item-meta">
                                  <div class="pug-list-item-meta-content"><h4
                                    class="pug-list-item-meta-title"><a class="listItemMetaTitle___2wEk5"
                                                                        href="https://ant.design">Bootstrap</a>
                                  </h4>
                                    <div class="pug-list-item-meta-description"><span><span class="pug-tag">Ant Design</span><span
                                      class="pug-tag">设计语言</span><span class="pug-tag">蚂蚁金服</span></span>
                                    </div>
                                  </div>
                                </div>
                                <div class="listContent___3B5zt">
                                  <div class="imgbox">
                                    <img src="https://gw.alipayobjects.com/zos/rmsportal/uMfMFlvUuceEyPpotzlq.png" alt="">
                                  </div>
                                  <div class="description___3xHdH">段落示意：蚂蚁金服设计平台
                                    ant.design，用最小的工作量，无缝接入蚂蚁金服生态，提供跨越设计与开发的体验解决方案。蚂蚁金服设计平台
                                    ant.design，用最小的工作量，无缝接入蚂蚁金服生态，提供跨越设计与开发的体验解决方案。

                                    <div class="extra___3DATl"><span
                                      class="pug-avatar pug-avatar-sm pug-avatar-circle pug-avatar-image"><img
                                      src="https://gw.alipayobjects.com/zos/rmsportal/WdGqmHpayyMjiEhcKoVE.png"></span><a
                                      href="https://ant.design">付小小</a> 发布在 <a href="https://ant.design">https://ant.design</a><em>2022-02-09
                                      19:33</em></div>
                                  </div>
                                </div>
                                <ul class="pug-list-item-action">
                                  <li><span><span role="img" aria-label="star" class="anticon anticon-star"
                                                  style="margin-right: 8px;"><svg viewBox="64 64 896 896"
                                                                                  focusable="false"
                                                                                  data-icon="star"
                                                                                  width="1em" height="1em"
                                                                                  fill="currentColor"
                                                                                  aria-hidden="true"><path
                                    d="M908.1 353.1l-253.9-36.9L540.7 86.1c-3.1-6.3-8.2-11.4-14.5-14.5-15.8-7.8-35-1.3-42.9 14.5L369.8 316.2l-253.9 36.9c-7 1-13.4 4.3-18.3 9.3a32.05 32.05 0 00.6 45.3l183.7 179.1-43.4 252.9a31.95 31.95 0 0046.4 33.7L512 754l227.1 119.4c6.2 3.3 13.4 4.4 20.3 3.2 17.4-3 29.1-19.5 26.1-36.9l-43.4-252.9 183.7-179.1c5-4.9 8.3-11.3 9.3-18.3 2.7-17.5-9.5-33.7-27-36.3zM664.8 561.6l36.1 210.3L512 672.7 323.1 772l36.1-210.3-152.8-149L417.6 382 512 190.7 606.4 382l211.2 30.7-152.8 148.9z"></path></svg></span>112</span><em
                                    class="pug-list-item-action-split"></em></li>
                                  <li><span><span role="img" aria-label="like" class="anticon anticon-like"
                                                  style="margin-right: 8px;"><svg viewBox="64 64 896 896"
                                                                                  focusable="false"
                                                                                  data-icon="like"
                                                                                  width="1em" height="1em"
                                                                                  fill="currentColor"
                                                                                  aria-hidden="true"><path
                                    d="M885.9 533.7c16.8-22.2 26.1-49.4 26.1-77.7 0-44.9-25.1-87.4-65.5-111.1a67.67 67.67 0 00-34.3-9.3H572.4l6-122.9c1.4-29.7-9.1-57.9-29.5-79.4A106.62 106.62 0 00471 99.9c-52 0-98 35-111.8 85.1l-85.9 311H144c-17.7 0-32 14.3-32 32v364c0 17.7 14.3 32 32 32h601.3c9.2 0 18.2-1.8 26.5-5.4 47.6-20.3 78.3-66.8 78.3-118.4 0-12.6-1.8-25-5.4-37 16.8-22.2 26.1-49.4 26.1-77.7 0-12.6-1.8-25-5.4-37 16.8-22.2 26.1-49.4 26.1-77.7-.2-12.6-2-25.1-5.6-37.1zM184 852V568h81v284h-81zm636.4-353l-21.9 19 13.9 25.4a56.2 56.2 0 016.9 27.3c0 16.5-7.2 32.2-19.6 43l-21.9 19 13.9 25.4a56.2 56.2 0 016.9 27.3c0 16.5-7.2 32.2-19.6 43l-21.9 19 13.9 25.4a56.2 56.2 0 016.9 27.3c0 22.4-13.2 42.6-33.6 51.8H329V564.8l99.5-360.5a44.1 44.1 0 0142.2-32.3c7.6 0 15.1 2.2 21.1 6.7 9.9 7.4 15.2 18.6 14.6 30.5l-9.6 198.4h314.4C829 418.5 840 436.9 840 456c0 16.5-7.2 32.1-19.6 43z"></path></svg></span>145</span><em
                                    class="pug-list-item-action-split"></em></li>
                                  <li><span><span role="img" aria-label="message"
                                                  class="anticon anticon-message"
                                                  style="margin-right: 8px;"><svg viewBox="64 64 896 896"
                                                                                  focusable="false"
                                                                                  data-icon="message"
                                                                                  width="1em" height="1em"
                                                                                  fill="currentColor"
                                                                                  aria-hidden="true"><path
                                    d="M464 512a48 48 0 1096 0 48 48 0 10-96 0zm200 0a48 48 0 1096 0 48 48 0 10-96 0zm-400 0a48 48 0 1096 0 48 48 0 10-96 0zm661.2-173.6c-22.6-53.7-55-101.9-96.3-143.3a444.35 444.35 0 00-143.3-96.3C630.6 75.7 572.2 64 512 64h-2c-60.6.3-119.3 12.3-174.5 35.9a445.35 445.35 0 00-142 96.5c-40.9 41.3-73 89.3-95.2 142.8-23 55.4-34.6 114.3-34.3 174.9A449.4 449.4 0 00112 714v152a46 46 0 0046 46h152.1A449.4 449.4 0 00510 960h2.1c59.9 0 118-11.6 172.7-34.3a444.48 444.48 0 00142.8-95.2c41.3-40.9 73.8-88.7 96.5-142 23.6-55.2 35.6-113.9 35.9-174.5.3-60.9-11.5-120-34.8-175.6zm-151.1 438C704 845.8 611 884 512 884h-1.7c-60.3-.3-120.2-15.3-173.1-43.5l-8.4-4.5H188V695.2l-4.5-8.4C155.3 633.9 140.3 574 140 513.7c-.4-99.7 37.7-193.3 107.6-263.8 69.8-70.5 163.1-109.5 262.8-109.9h1.7c50 0 98.5 9.7 144.2 28.9 44.6 18.7 84.6 45.6 119 80 34.3 34.3 61.3 74.4 80 119 19.4 46.2 29.1 95.2 28.9 145.8-.6 99.6-39.7 192.9-110.1 262.7z"></path></svg></span>18</span>
                                  </li>
                                </ul>
                              </div>
                            </li>
                          </ul>
                        </div>
                      </div>
                      <div style="text-align: center; margin-top: 16px;background: #fff;">
                        <button type="button" class="pug-btn"
                                style="padding-left: 48px; padding-right: 48px;border:none;"><span>加载更多</span></button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
  </div>
</template>

<script>
export default {
  name: "Course.vue",
  components: {
  },
  data() {
    return {
      pageSize: 20, //每页显示20条数据
      currentPage: 1, //当前页码
      count: 100, //总记录数
      items: [
        {code: 1, name: " 编程到底该如何学习？", nickname: "xxxxx", sex: 1},
        {code: 2, name: "学习编程之前你要了解的知识！", nickname: "xxxxx", sex: 1},
        {code: 3, name: "工欲善其事，必先利其器！", nickname: "xxxxx", sex: 1},
        {code: 4, name: "基础决定你未来的高度！", nickname: "xxxxx", sex: 1},
        {code: 5, name: "程序的本质就是这些！", nickname: "xxxxx", sex: 1},
        {code: 6, name: "利用集合高效解决问题！", nickname: "xxxxx", sex: 1},
        {code: 7, name: "从零开始开发游戏！", nickname: "xxxxx", sex: 1},
        {code: 8, name: "日常开发必备知识！", nickname: "xxxxx", sex: 1},
        {code: 9, name: "最简单的数据结构！", nickname: "xxxxx", sex: 1},
        {code: 10, name: "Java进阶必会技能！", nickname: "xxxxx", sex: 1},
      ]
    }
  },
  methods: {
    //获取数据
    getList() {

    },

    //从page组件传递过来的当前page
    pageChange(page) {
      this.currentPage = page
    }
  },
  mounted() {
    //请求第一页数据
    this.getList()
  }
}
</script>

<style scoped>


</style>
