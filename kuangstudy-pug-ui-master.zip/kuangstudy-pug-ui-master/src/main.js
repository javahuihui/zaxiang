import {createApp} from 'vue'
import App from './App.vue'
import router from './router'
import Loading from './plugins/PugLoading'
import store from './store'
// 引入自定义组件。index.js是组件的默认入口
import PugUI from './components/install'

const app = createApp(App);
app.use(router)
app.use(store);//内部插件 install()
app.use(Loading);//内部插件 install()
app.use(PugUI);//内部插件 install()
app.mount('#app');




