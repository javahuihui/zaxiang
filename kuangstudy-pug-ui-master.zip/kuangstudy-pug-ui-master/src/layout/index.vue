<template>
  <app-header></app-header>
  <div class="pug-layout-content">
    <app-nav-menu/>
    <app-main/>
  </div>
</template>

<script>

import {AppMain, AppNavMenu,AppHeader} from './components'

export default {
  name: 'Layout',
  components: {
    AppMain,
    AppHeader,
    AppNavMenu
  },
  created() {

  },
  computed: {},
  methods: {}
}
</script>

<style>

</style>
