<template>
  <aside class="pug-layout-navbar navfixed">
    <ul class="pug-menu">
      <li class="pug-menu-items" v-for="(slide,index) in SilderList" :key="slide.id">
        <div class="pug-menu-submenu-title" @click.stop="expand(index)">
          <router-link :to="slide.path">
            <span class="pug-pro-menu-item ">
              <span class="imgicon"><i :class="['iconfont',slide.icon]"></i></span>
              <span class="put-item-title">{{ slide.meta.title }}</span>
              <span class="pud-icon-expand" v-if="slide.children.length > 0"><i
                :class="['iconfont fz13 fw',slide.expand?'icon-jiantouxia':'icon-jiantoushang']"></i></span>
            </span>
          </router-link>
        </div>
        <ul class="pug-menu-child" v-show="slide.expand">
          <template v-for="cslide in slide.children" :key="cslide.id">
            <li class="pug-menu-items" v-if="cslide.isshow">
              <div class="pug-menu-submenu-ctitle">
                <router-link :to="cslide.path">
                      <span class="pug-pro-menu-item">
                        <span class="imgicon"><i :class="['iconfont',cslide.icon]"></i></span>
                        <span class="put-item-title">{{ cslide.meta.title }}</span>
                      </span>
                </router-link>
              </div>
            </li>
          </template>
        </ul>
      </li>
    </ul>
  </aside>
</template>
<script>

import Silder from "@/router/config/create";
import PugMenu from "@/router/config/pugmenu";
import PugPermission from "@/components/permission/PugPermission";


export default {
  name: "AppNavMenu",
  components: {PugPermission},
  data() {
    return {
      SilderList: [],
      menuList: []
    }
  },

  created() {
    this.menuList = PugMenu.concat((Silder));
    var rootList = this.menuList.filter(s => s.pid === 0);
    rootList.map(s => {
      s.children = this.menuList.filter(c => c.pid == s.id);
      return s;
    })
    this.SilderList = rootList;
  },

  mounted() {
    this.$nextTick(() => {
      var sliderDom = document.getElementsByClassName("pug-layout-navbar")[0];
      var activeDom = sliderDom.getElementsByClassName("active")[0];
      var href = this.getUrlRelativePath(activeDom.href);
      var slider = this.menuList.find(s => href == s.path);
      this.SilderList[slider.indexon].expand = true;
    })
  },

  methods: {

    expand(index) {
      this.SilderList[index].expand = !this.SilderList[index].expand;
    },

    getUrlRelativePath(url) {
      var arrUrl = url.split("//");
      var start = arrUrl[1].indexOf("/");
      var relUrl = arrUrl[1].substring(start);//stop省略，截取从start开始到结尾的所有字符
      if (relUrl.indexOf("?") != -1) {
        relUrl = relUrl.split("?")[0];
      }
      return relUrl;
    },

    tabSelect(index) {
      this.SilderList[index].expand = true;
    }
  }
}
</script>

<style>
.pug-menu {
  box-sizing: border-box;
  font-variant: tabular-nums;
  line-height: 1.5715;
  font-feature-settings: "tnum", "tnum";
  margin: 0;
  padding: 0;
  color: rgba(0, 0, 0, .85);
  font-size: 14px;
  text-align: left;
  outline: none;
  transition: background .3s, width .3s cubic-bezier(.2, 0, 0, 1) 0s;
}


.pug-menu-items {
  padding-bottom: 0.02px;
  transition: border-color .3s cubic-bezier(.645, .045, .355, 1), background .3s cubic-bezier(.645, .045, .355, 1), padding .15s cubic-bezier(.645, .045, .355, 1);
}

.pug-menu-items a {
  display: block;
}

.pug-menu-submenu-title, .pug-menu-submenu-ctitle {
  height: 36px;
  margin-top: 2px;
  margin-bottom: 2px;
  overflow: hidden;
  line-height: 36px;
  text-overflow: ellipsis;
  position: relative;
  display: block;
  padding: 0 20px;
  white-space: nowrap;
  cursor: pointer;
  transition: border-color .3s, background .3s, padding .3s cubic-bezier(.645, .045, .355, 1);
}


.pug-menu-submenu-title:hover,
.pug-menu-submenu-ctitle:hover {
  background: #e6f7ff;
  color: #1890ff;
}

.pug-menu-submenu-title a.active,
.pug-menu-submenu-ctitle a.active {
  color: #1890ff;
}


.pug-menu-submenu-ctitle {
  padding-left: 32px;
}


.pug-pro-menu-item .imgicon .iconfont {
  font-size: 16px;
}

.pug-pro-menu-item .put-item-title {
  margin-left: 10px
}

.pug-pro-menu-item .pud-icon-expand {
  position: absolute;
  top: 50%;
  right: 16px;
  width: 10px;
  color: rgba(0, 0, 0, .85);
  transform: translateY(-50%);
  transition: transform .3s cubic-bezier(.645, .045, .355, 1);
}
</style>
