<template>
  <section class="pug-layout-main">
    <div class="pug-scrollbar__wrap">
      <div class="pug-page-header has-breadcrumb" v-show="false">
        <div class="pug-breadcrumb">
          <span class="pug-breadcrumb-link"><a href="/form">表单页</a></span>
          <span class="pug-breadcrumb-separator">/</span>
          <span class="pug-breadcrumb-link"><a href="/form/basic-form">基础表单</a></span>
        </div>
      </div>
      <app-menu v-if="menushow"></app-menu>
    </div>
    <keep-alive><router-view :key="key"/></keep-alive>
  </section>
</template>
<script>
import AppMenu from '@/layout/components/AppMenu'
import defaultSettings from '@/settings'
export default {
  name: "AppMain",
  computed:{
    menushow(){
      return defaultSettings.menushow;
    },
    key() {
      return this.$route.name !== undefined? this.$route.name + +new Date(): this.$route + +new Date()
    }
  },
  components: {
    AppMenu
  }
}

</script>

<style scoped>

</style>
