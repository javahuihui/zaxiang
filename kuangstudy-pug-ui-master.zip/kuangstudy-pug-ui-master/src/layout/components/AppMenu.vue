<template>
  <div class="pug-scrollbar__view" v-if="menus.length > 0">
      <span class="tags-view-item" v-for="(menu,index) in menus">
          <router-link :to="menu.path">{{ menu.title }} <span v-if="menu.params.id">【{{menu.params.id}}】</span></router-link>
          <span @click.stop="closeMenu(index)" class="pug-icon-close"></span>
      </span>
  </div>
</template>
<script>

import {createNamespacedHelpers} from 'vuex'
const {mapState, mapMutations} = createNamespacedHelpers('menu')

export default {
  name: "AppHeaderMenu",
  components: {},
  computed: {
    ...mapState({
      menus: state => state.menus
    })
  },
  methods: {
    ...mapMutations(['closeMenu'])
  }
}
</script>

<style scoped>

.pug-scrollbar__view {
  white-space: nowrap;
}


.tags-view-item {
  display: inline-block;
  position: relative;
  cursor: pointer;
  height: 26px;
  line-height: 24px;
  max-width: 160px;
  text-overflow: ellipsis;
  overflow: hidden;
  border: 1px solid #d8dce5;
  color: #495060;
  background: #fff;
  padding: 0 22px;
  border-radius: 16px;
  font-size: 12px;
  margin-right: 8px;
  margin-top: 4px;
}

.tags-view-item:first-child {
  margin-left: 15px;
}

.tags-view-item a.active {
  color: #409eff;
  font-weight: 900;
}

.tags-view-item a.active:before {
  content: "";
  background: #fff;
  display: inline-block;
  width: 8px;
  height: 8px;
  border-radius: 50%;
  position: relative;
  margin-right: 2px;
}


.tags-view-item .pug-icon-close {
  width: 16px;
  height: 16px;
  margin-left: 5px;
  vertical-align: 2px;
  border-radius: 50%;
  text-align: center;
  position: absolute;
  top:-1px;
  right:5px;
  -webkit-transition: all .3s cubic-bezier(.645, .045, .355, 1);
  transition: all .3s cubic-bezier(.645, .045, .355, 1);
  -webkit-transform-origin: 100% 50%;
  transform-origin: 100% 50%;
}

.tags-view-item .pug-icon-close:before {
  content: "x";
  -webkit-transform: scale(.8);
  transform: scale(.8);
  display: inline-block;
  vertical-align: -1px;
  margin-left: 3px;
}

.pug-pro-page-container-warp {
  background-color: #fff;
}

.pug-page-header.has-breadcrumb {
  padding-top: 12px;
}

.pug-breadcrumb {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
  font-variant: tabular-nums;
  line-height: 1.2615;
  list-style: none;
  font-feature-settings: "tnum", "tnum";
  color: rgba(0, 0, 0, .45);
  font-size: 14px;
  width: 120px;
  text-overflow: ellipsis;
  overflow: hidden;
  white-space: nowrap;
}

.pug-breadcrumb-separator {
  margin: 0 8px;
  color: rgba(0, 0, 0, .45);
}

.pug-breadcrumb > span:last-child {
  color: rgba(0, 0, 0, .85);
}

.pug-breadcrumb + .pug-page-header-heading {
  margin-top: 8px;
}

.pug-page-header-heading-left {
  display: flex;
  align-items: center;
  margin: 4px 0;
  overflow: hidden;
}

.pug-page-header-heading-title {
  margin-right: 12px;
  margin-bottom: 0;
  color: rgba(0, 0, 0, .85);
  font-weight: 600;
  font-size: 20px;
  line-height: 32px;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}

.pug-page-header-content {
  padding-top: 12px;
}

.pug-pro-page-container-main .pug-pro-page-container-row {
  display: flex;
  width: 100%;
}

</style>
