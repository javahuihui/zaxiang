// 导入自定义的异步请求
import request from '@/utils/request';

/**
 * 产品模块业务
 */
export default {

  // 1: 查询产品搜索并分页
  findProductPage(productVo = {pageNo: 1, pageSize: 10}) {
    return request.post("product/list", productVo);
  },

  // 2: 保存产品
  saveUpdateProduct(product = {}) {
    return request.post("product/saveupdate", product);
  },

  // 3: 根据id删除产品
  delProduct(id) {
    if (!id) {
      return;
    }
    return request.post("product/del/" + id);
  },

  // 4: 批量删除
  delBatchProduct(batchIds) {
    if (!batchIds) {
      return;
    }
    return request.post("product/delBatch", {batchIds});
  },

  // 5: 根据id查询产品明细
  getProduct(id) {
    if (!id) {
      return;
    }
    return request.get("product/get/" + id);
  }

}
