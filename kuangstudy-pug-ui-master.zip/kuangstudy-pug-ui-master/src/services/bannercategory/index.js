import request from '@/utils/request';

/**
 * @author yykk
 * @date: 2022-02-21 15:06:55
 * @desc: 轮播图分类模块业务
 * @version：1.0.0
 */
export default {

  // 1: 查询$搜索&分页轮播图分类
  findBannerCategoryPage(bannercategoryVo = {pageNo: 1, pageSize: 10}) {
    return request.post("bannercategory/list", bannercategoryVo);
  },

  // 2: 查询轮播图分类列表
  findBannerCategoryList() {
    return request.get("bannercategory/load");
  },

  // 3: 保存&修改轮播图分类
  saveUpdateBannerCategory(bannercategory = {}) {
    return request.post("bannercategory/saveupdate", bannercategory);
  },

  // 4: 根据id删除轮播图分类
  delBannerCategory(id) {
    if (!id) {
      return;
    }
    return request.post("bannercategory/delete/" + id);
  },

  // 5: 批量删除轮播图分类
  delBatchBannerCategory(batchIds) {
    if (!batchIds) {
      return;
    }
    return request.post("bannercategory/delBatch", {batchIds});
  },

  // 6: 根据id查询轮播图分类明细
  getBannerCategory(id) {
    if (!id) {
      return;
    }
    return request.get("bannercategory/get/" + id);
  },

  //7 加载树形菜单数据
  loadTree(){
     return request.get("bannercategory/tree");
  },

}
