import request from "@/utils/request";

export default {

  /*
   * 描述：查询产品分类
   * 作者：yykk
   * 参数：
   */
  findProductCategories() {
    return request.get("product/categories");
  },

  /*
    * 描述：保存分类
    * 作者：yykk
    * 参数：
    */
  saveCategory(category = {}) {
    return request.post("/product/savecategory", category);
  }
}
