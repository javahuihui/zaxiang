import request from '@/utils/request';

/**
 * @author yykk
 * @date: 2022-02-21 15:16:27
 * @desc: 权限管理模块业务
 * @version：1.0.0
 */
export default {

  // 1: 查询$搜索&分页权限管理
  findPermissionPage(permissionVo = {pageNo: 1, pageSize: 10}) {
    return request.post("permission/list", permissionVo);
  },

  // 2: 查询权限管理列表
  findPermissionList() {
    return request.get("permission/load");
  },

  // 3: 保存&修改权限管理
  saveUpdatePermission(permission = {}) {
    return request.post("permission/saveupdate", permission);
  },

  // 4: 根据id删除权限管理
  delPermission(id) {
    if (!id) {
      return;
    }
    return request.post("permission/delete/" + id);
  },

  // 5: 批量删除权限管理
  delBatchPermission(batchIds) {
    if (!batchIds) {
      return;
    }
    return request.post("permission/delBatch", {batchIds});
  },

  // 6: 根据id查询权限管理明细
  getPermission(id) {
    if (!id) {
      return;
    }
    return request.get("permission/get/" + id);
  },

  //7 加载树形菜单数据
  loadTree(){
     return request.get("permission/tree");
  },

}
