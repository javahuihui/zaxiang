import request from '@/utils/request';

/**
 * @author yykk
 * @date: 2022-02-21 15:05:53
 * @desc: 轮播图模块业务
 * @version：1.0.0
 */
export default {

  // 1: 查询$搜索&分页轮播图
  findBannerPage(bannerVo = {pageNo: 1, pageSize: 10}) {
    return request.post("banner/list", bannerVo);
  },

  // 2: 查询轮播图列表
  findBannerList() {
    return request.get("banner/load");
  },

  // 3: 保存&修改轮播图
  saveUpdateBanner(banner = {}) {
    return request.post("banner/saveupdate", banner);
  },

  // 4: 根据id删除轮播图
  delBanner(id) {
    if (!id) {
      return;
    }
    return request.post("banner/delete/" + id);
  },

  // 5: 批量删除轮播图
  delBatchBanner(batchIds) {
    if (!batchIds) {
      return;
    }
    return request.post("banner/delBatch", {batchIds});
  },

  // 6: 根据id查询轮播图明细
  getBanner(id) {
    if (!id) {
      return;
    }
    return request.get("banner/get/" + id);
  },


}
