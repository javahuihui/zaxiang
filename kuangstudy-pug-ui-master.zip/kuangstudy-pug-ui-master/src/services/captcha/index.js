import axios from "axios";

export default function captcha() {
  return axios.get("/admin/captcha")
}


