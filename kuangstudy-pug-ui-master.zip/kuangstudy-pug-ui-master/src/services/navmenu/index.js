import request from "@/utils/request";

export  default  {
    /**
     * 加载菜单
     * @returns {Promise<AxiosResponse<any>>}
     */
    loadMenus(){
        return request.get("navmenu/tree");
    }
}
