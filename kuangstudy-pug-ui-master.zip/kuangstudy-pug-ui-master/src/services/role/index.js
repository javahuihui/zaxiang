import request from '@/utils/request';

/**
 * @author yykk
 * @date: 2022-02-21 15:07:39
 * @desc: 角色管理模块业务
 * @version：1.0.0
 */
export default {

  // 1: 查询$搜索&分页角色管理
  findRolePage(roleVo = {pageNo: 1, pageSize: 10}) {
    return request.post("role/list", roleVo);
  },

  // 2: 查询角色管理列表
  findRoleList() {
    return request.get("role/load");
  },

  // 3: 保存&修改角色管理
  saveUpdateRole(role = {}) {
    return request.post("role/saveupdate", role);
  },

  // 4: 根据id删除角色管理
  delRole(id) {
    if (!id) {
      return;
    }
    return request.post("role/delete/" + id);
  },

  // 5: 批量删除角色管理
  delBatchRole(batchIds) {
    if (!batchIds) {
      return;
    }
    return request.post("role/delBatch", {batchIds});
  },

  // 6: 根据id查询角色管理明细
  getRole(id) {
    if (!id) {
      return;
    }
    return request.get("role/get/" + id);
  },


}
