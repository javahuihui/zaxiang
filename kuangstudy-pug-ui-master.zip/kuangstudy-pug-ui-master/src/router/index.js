// 1：定义路由
import {createRouter, createWebHistory} from 'vue-router'
import Root from '@/router/config/menu.js'
import store from '@/store/index.js'
// 2：创建路由
const router = createRouter({
  linkActiveClass: "active",
  history: createWebHistory(process.env.BASE_URL),
  routes: Root
})


router.beforeEach((to) => {
  if (to.matched.length == 0) {
    return {path: "/404"}
  }
})

//4：判断目标路由是否是/login，如果是，则直接返回true
router.beforeEach((to, from) => {
  //判断目标路由是否是/login，如果是，则直接返回true
  if (to.path == '/login' || to.path == '/captcha') {
    return true;
  } else {
    var loginFlag = store.getters["login/isLogin"];
    //否则判断用户是否已经登录，注意这里是字符串判断
    if (loginFlag) {
      // 追加到到菜单
      store.commit("menu/addMenu", {
        title: to.meta.title,
        path: to.path,
        params:to.params,
        active: true
      })
      return true;
    } else {
      //如果用户访问的是受保护的资源，且没有登录，则跳转到登录页面
      //并将当前路由的完整路径作为查询参数传给Login组件，以便登录成功后返回先前的页面
      return {
        path: '/login',
        query: {redirect: from.fullPath}
      }
    }
  }
});


// 设置标题
router.afterEach((to) => {
  document.title = to.meta.title;
})


// 5：导出路由
export default router;
