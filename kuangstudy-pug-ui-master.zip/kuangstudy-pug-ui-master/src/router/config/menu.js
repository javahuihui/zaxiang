import Silder from "@/router/config/create";
import PugMenu from "@/router/config/pugmenu";

// 通用布局相关
const Root = [
  {
    path: '',
    name: "layout",
    meta: {title: '布局'},
    component: () => import('@/layout'),
    redirect: 'index',
    children: PugMenu.concat(Silder)
  },
  {path: '/401', name: "error401", meta: {title: '没有权限'}, component: () => import('@/views/error-page/401')},
  {path: '/404', name: "error404", meta: {title: '错误页面'}, component: () => import('@/views/error-page/404')},
  {path: '/login', name: 'login', meta: {title: '登录'}, component: () => import('@/views/login.vue')},
  {path: '/toIndex', name: "toIndex", redirect: '/index'},
  {path: '/toLogin', name: "toLogin", redirect: '/login'}
]



// 导出菜单配置
export default Root;

