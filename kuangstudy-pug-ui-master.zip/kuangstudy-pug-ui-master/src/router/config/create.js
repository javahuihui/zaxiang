import transferRouter from "@/utils/menu";

const MenuList = [
    transferRouter(7, 0, "轮播图分类管理", "bannercategory", "/bannercategory", import('@/views/admin/bannercategory/index.vue'), "icon-dashboard", 10,true),
    transferRouter(8, 7, "轮播图分类列表", "bannercategorylist", "/bannercategory/list", import('@/views/admin/bannercategory/index.vue'), "", 10,true),
    transferRouter(9, 7, "轮播图分类添加", "bannercategoryadd", "/bannercategory/add", import('@/views/admin/bannercategory/add.vue'), "", 10,true),
    transferRouter(10, 7, "轮播图分类编辑", "bannercategoryedit", "/bannercategory/edit/:id", import('@/views/admin/bannercategory/add.vue'), "", 10,false),
    transferRouter(11, 0, "轮播图管理", "banner", "/banner", import('@/views/admin/banner/index.vue'), "icon-dashboard", 11,true),
    transferRouter(12, 11, "轮播图列表", "bannerlist", "/banner/list", import('@/views/admin/banner/index.vue'), "", 11,true),
    transferRouter(13, 11, "轮播图添加", "banneradd", "/banner/add", import('@/views/admin/banner/add.vue'), "", 11,true),
    transferRouter(14, 11, "轮播图编辑", "banneredit", "/banner/edit/:id", import('@/views/admin/banner/add.vue'), "", 11,false),
    transferRouter(15, 0, "角色管理管理", "role", "/role", import('@/views/admin/role/index.vue'), "icon-dashboard", 12,true),
    transferRouter(16, 15, "角色管理列表", "rolelist", "/role/list", import('@/views/admin/role/index.vue'), "", 12,true),
    transferRouter(17, 15, "角色管理添加", "roleadd", "/role/add", import('@/views/admin/role/add.vue'), "", 12,true),
    transferRouter(18, 15, "角色管理编辑", "roleedit", "/role/edit/:id", import('@/views/admin/role/add.vue'), "", 12,false),
    transferRouter(19, 0, "权限管理管理", "permission", "/permission", import('@/views/admin/permission/index.vue'), "icon-dashboard", 13,true),
    transferRouter(20, 19, "权限管理列表", "permissionlist", "/permission/list", import('@/views/admin/permission/index.vue'), "", 13,true),
    transferRouter(21, 19, "权限管理添加", "permissionadd", "/permission/add", import('@/views/admin/permission/add.vue'), "", 13,true),
    transferRouter(22, 19, "权限管理编辑", "permissionedit", "/permission/edit/:id", import('@/views/admin/permission/add.vue'), "", 13,false),
    transferRouter(100, 0, "产品管理", "product", "/product", import('@/views/admin/product'), "icon-dashboard", 8,true),
    transferRouter(101, 100, "产品列表", "productlist", "/product/list", import('@/views/admin/product/index'), "", 8,true),
    transferRouter(102, 100, "添加产品", "productadd", "/product/add", import('@/views/admin/product/add'), "", 8,false),
    transferRouter(103, 100, "编辑产品", "productedit", "/product/edit/:id", import('@/views/admin/product/add'), "null", 8,false),
    transferRouter(104, 0, "分类管理", "category", "/category", import('@/views/admin/category'), "icon-dashboard", 9,true),
    transferRouter(105, 104, "分类列表", "categorylist", "/category/list", import('@/views/admin/category/index'), "", 9,true)
];

export default MenuList;