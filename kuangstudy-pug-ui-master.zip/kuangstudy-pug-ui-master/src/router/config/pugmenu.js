import transferRouter from "@/utils/menu";
// 左侧菜单栏
const PugMenu = [
  transferRouter(1, 0, "首页", "index", "/index", import('@/views/index'), "icon-dashboard", 0),
  transferRouter(2, 0, "表格", "table", "/table/index", import('@/views/table/search.vue'), "icon-daibanshixiang", 1),
  transferRouter(3, 2, "查询表格", "tablesearch", "/table/search", import('@/views/table/search.vue'), "", 1),
  transferRouter(4, 2, "基础列表", "tablestandard", "/table/standard", import('@/views/table/standard.vue'), "", 1),
  transferRouter(44, 2, "表单表格", "tableform", "/table/form", import('@/views/table/formtable.vue'), "", 1),
  transferRouter(5, 2, "卡片列表", "tablecards", "/table/cards", import('@/views/table/cards.vue'), "", 1),
  transferRouter(6, 2, "项目列表", "tableitems", "/table/items", import('@/views/table/items.vue'), "", 1),
  transferRouter(7, 2, "文章列表", "tablearticle", "/table/article", import('@/views/table/article.vue'), "", 1),
  transferRouter(8, 2, "表格树", "tabletree", "/table/tree", import('@/views/table/tree.vue'), "", 1),
  transferRouter(9, 0, "表单", "formlist", "/form/index", import('@/views/form/normal.vue'), "icon-denglu1", 2),
  transferRouter(10, 9, "基础表单", "formnormal", "/form/normal", import('@/views/form/normal.vue'), "", 2),
  transferRouter(11, 9, "分步表单", "formsort", "/form/sortform", import('@/views/form/sortform.vue'), "", 2),
  transferRouter(37, 9, "栅栏表单", "zhanlanform", "/form/zhanlanform", import('@/views/form/zhanlanform.vue'), "", 2),
  transferRouter(12, 9, "高级表单", "advence", "/form/advence", import('@/views/form/advence.vue'), "", 2),
  transferRouter(15, 9, "富文本", "editor", "/form/editor", import('@/views/form/editor.vue'), "", 2),
  transferRouter(13, 9, "万年历", "time", "/form/time", import('@/views/form/time.vue'), "", 2),
  transferRouter(14, 9, "文件上传", "upload", "/form/upload", import('@/views/form/upload.vue'), "", 2),
  transferRouter(35, 9, "tree", "tree", "/form/tree", import('@/views/form/tree.vue'), "", 2),
  transferRouter(16, 0, "异常页面", "ex", "/404", import('@/views/error-page/404'), "icon-dashboard", 3),
  transferRouter(17, 16, "404", "ex404", "/404", import('@/views/error-page/404'), "", 3),
  transferRouter(18, 16, "401", "ex401", "/401", import('@/views/error-page/401'), "", 3),
  transferRouter(19, 16, "500", "ex500", "/500", import('@/views/error-page/500'), "", 3),
  transferRouter(20, 0, "提示框", "message", "/message", import('@/views/message/msg'), "icon-dashboard", 4),
  transferRouter(21, 20, "消息框", "message", "/message/index", import('@/views/message/msg'), "", 4),
  transferRouter(22, 20, "加载提示", "loading", "/message/loading", import('@/views/message/loading'), "", 4),
  transferRouter(23, 20, "弹出层", "dialog", "/message/dialog", import('@/views/message/dialog'), "", 4),
  transferRouter(24, 0, "个人页面", "userindex", "/user/index", import('@/views/user'), "icon-dashboard", 5),
  transferRouter(25, 24, "个人中心", "usercenter", "/user/center", import('@/views/user'), "", 5),
  transferRouter(26, 24, "个人设置", "usersettings", "/user/settings", import('@/views/user/settings'), "", 5),
  transferRouter(27, 0, "统计报表", "chart", "/chart", import('@/views/chart'), "icon-dashboard", 6),
  transferRouter(28, 27, "chart1", "chart1", "/chart/chart1", import('@/views/chart/chart1'), "", 6),
  transferRouter(29, 27, "chart2", "chart2", "/chart/chart2", import('@/views/chart/chart2'), "", 6),
  transferRouter(30, 27, "chart3", "chart3", "/chart/chart3", import('@/views/chart/chart3'), "", 6),
  transferRouter(31, 0, "系统消息", "sysmsg", "/sysmsg", import('@/views/sysmsg'), "icon-dashboard", 7),
  transferRouter(32, 31, "系统管理", "sysmsglist", "/sysmsg/list", import('@/views/sysmsg'), "icon-dashboard", 7)
];


// 导出菜单配置
export default PugMenu;

