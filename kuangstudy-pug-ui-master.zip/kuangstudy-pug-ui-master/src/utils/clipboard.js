import Vue from 'vue'
import Clipboard from 'clipboard'

// 复制成功
function copySuccess() {
  Vue.prototype.$message({
    message: 'Copy successfully',
    type: 'success',
    duration: 1500
  })
}

// 复制失败
function copyError() {
  Vue.prototype.$message({
    message: 'Copy failed',
    type: 'error'
  })
}

export default function handleClipboard(text, event) {
  return new Promise((resolve, reject) => {
    const clipboard = new Clipboard(event.target, {
      text: () => text
    })

    clipboard.on('success', () => {
      copySuccess()
      resolve()
      clipboard.destroy()
    })

    clipboard.on('error', () => {
      copyError()
      reject()
      clipboard.destroy()
    })

    clipboard.onClick(event)
  })
}
