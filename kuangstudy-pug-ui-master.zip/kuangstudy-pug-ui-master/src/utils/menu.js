// 菜单转换
function transferRouter(id, pid, title, name, path, commponent, icon, indexon, isshow = true, children = []) {
  return {
    id,
    pid,
    name,
    path,
    meta: {title},
    icon,
    expand: false,
    component: () => commponent,
    indexon,
    isshow,
    children
  };
}


export  default  transferRouter;
