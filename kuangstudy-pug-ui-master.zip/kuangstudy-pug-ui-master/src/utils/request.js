// 1: 导入异步处理
import axios from "axios";
import cache from '@/utils/cache'
import pug from '@/plugins/PugMessage'
import router from "@/router";

// 2: 创建axios异步实列对象
const request = axios.create({
  //`baseURL` 将自动加在 `url` 前面，除非 `url` 是一个绝对 URL。
  baseURL: "/admin/v1/",
  // 请求服务器最大时长，如果请求超过这个时间直接终止
  timeout: 10000
});


// 添加请求拦截器
// 在执行axios.get/post 在来进行处理加工
request.interceptors.request.use(function (config) {
  // 获取toekn
  var token = cache.session.get("token");
  if (token) {
    config.headers['Authorization'] = 'Bearer ' + token // 让每个请求携带自定义token 请根据实际情况自行修改
  }

  // get请求映射params参数
  if (config.method === 'get' && config.params) {
    let url = config.url + '?' + transferParams(config.params);
    url = url.slice(0, -1);
    config.params = {};
    config.url = url;
  }

  // 这里处理post逻辑
  if (config.method === 'post' || config.method === 'put') {
    if (!config.data) {
      config.data = {};
    }
  }
  // 在发送请求之前做些什么
  return config;
}, function (error) {
  pug.error("服务离开了地球表面!!!");
  // 对请求错误做些什么
  return Promise.reject(error);
});


// 添加响应拦截器
request.interceptors.response.use(function (response) {
  const res = response.data;
  // 如果token
  if (res.status == '101100610') {
    pug.error("Token已经失效!!!");
    router.push("/toLogin?redirect=" + window.location.pathname);
  } else if (res.status == '101100611') {
    pug.error("Token已经失效!!!");
    router.push("/toLogin?redirect=" + window.location.pathname);
  } else if (res.status == '101100708') {
    pug.error("你没有访问权限!!!");
  } else {
    return typeof res == "string" ? JSON.parse(res) : res;
  }
}, function (error) {
  // ui效果代码略
  const errMsg = error.toString()
  const code = errMsg.substr(errMsg.indexOf('code') + 5)
  if (code === '401') {
    pug.error("服务离开了地球表面!!!");
  } else if (code === '500') {
    pug.error("服务离开了地球表面!!!");
  } else {
    // 对响应错误做点什么
    return Promise.reject(error)
  }
});


// 参数转换
function transferParams(params) {
  let result = ''
  for (const propName of Object.keys(params)) {
    const value = params[propName];
    var part = encodeURIComponent(propName) + "=";
    if (value !== null && typeof (value) !== "undefined") {
      if (typeof value === 'object') {
        for (const key of Object.keys(value)) {
          if (value[key] !== null && typeof (value[key]) !== 'undefined') {
            let params = propName + '[' + key + ']';
            var subPart = encodeURIComponent(params) + "=";
            result += subPart + encodeURIComponent(value[key]) + "&";
          }
        }

      } else {
        result += part + encodeURIComponent(value) + "&";
      }
    }
  }
  return result
}


// 3： 导出
export default request;

