'use strict'

/*读取项目的路径*/
const path = require('path')
const webpack = require('webpack')
// 配置compression-webpack-plugin 插件 用于js 或者css压缩
const CompressionWebpackPlugin = require('compression-webpack-plugin')
// 定义压缩文件类型
const productionGzipExtensions = ['js','css','html']

/*新建一个常量类*/
const defaultSettings = require('./src/settings.js')

function resolve(dir) {
    return path.join(__dirname, dir)
}

const name = defaultSettings.title || 'Pug Admin' // page title

module.exports = {
    publicPath: '/',
    outputDir: 'dist',
    assetsDir: 'static',
    lintOnSave: process.env.NODE_ENV === 'development',
    productionSourceMap: false,
    devServer: {
        open: true,
        host: 'localhost',
        port: 8081,
        // 请求代理
        proxy: {
            '/admin': {
                //这里的地址是后端数据接口的地址
                //target: 'http://120.77.34.190:8081/',
                target: 'http://localhost:8088/',
                //允许跨域
                changeOrigin: true,
                // pathRewrite 路径重写
                // pathRewrite: {
                //     //'^/admin': '/'
                // },
                // 允许ws访问
                ws: true,
                // 允许https访问
                secure: false
            }
        }
    },
    configureWebpack: {
        name: name,
        resolve: {
            alias: {
                '@': resolve('src'),
                '@i': path.resolve(__dirname, './src/assets'),
            }
        },
      plugins: [
        // Ignore all locale files of moment.js
        new webpack.IgnorePlugin({
          resourceRegExp: /^\.\/locale$/,
          contextRegExp: /moment$/
        }),
        // 配置compression-webpack-plugin压缩
        /* 配置参数详解
        提示 compression-webpack-plugin@3.0.0的话asset改为filename
          asset： 目标资源名称。 [file] 会被替换成原始资源。[path] 会被替换成原始资源的路径， [query] 会被替换成查询字符串。默认值是 "[path].gz[query]"。
          algorithm： 可以是 function(buf, callback) 或者字符串。对于字符串来说依照 zlib 的算法(或者 zopfli 的算法)。默认值是 "gzip"。
          test： 所有匹配该正则的资源都会被处理。默认值是全部资源。
          threshold： 只有大小大于该值的资源会被处理。单位是 bytes。默认值是 0。
          minRatio： 只有压缩率小于这个值的资源才会被处理。默认值是 0.8。*/
        // 提示compression-webpack-plugin@3.0.0的话asset改为filename
        new CompressionWebpackPlugin({
          algorithm: 'gzip',
          test: new RegExp('\\.(' + productionGzipExtensions.join('|') + ')$'),
          threshold: 1024,
          minRatio: 0.8
        }),
        new webpack.optimize.LimitChunkCountPlugin({
          maxChunks: 5
        }),
        new webpack.optimize.MinChunkSizePlugin({
          minChunkSize: 10000
        })
      ]
    }
}
